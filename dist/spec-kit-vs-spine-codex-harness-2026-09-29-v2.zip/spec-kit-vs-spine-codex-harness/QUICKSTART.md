# Quickstart — portable scenario harness, no API key

Run these commands in **Bash**, from the unpacked harness. The Codex app's terminal or a normal terminal works. Every recipient uses their own repository access and ChatGPT sign-in. This archive includes no credentials, results, or Spine source checkout.

## 1. Prerequisites and unpacking

Install Git, Bash, Python 3.12, [uv](https://docs.astral.sh/uv/getting-started/installation/), and the [Codex CLI](https://learn.chatgpt.com/docs/codex/cli). The measured environment used Codex CLI 0.157.0 and uv 0.8.0 on macOS. Linux/WSL is not live-tested; native PowerShell is unsupported.

```bash
unzip spec-kit-vs-spine-codex-harness-2026-09-29-v2.zip
cd spec-kit-vs-spine-codex-harness
shasum -a 256 -c SHA256SUMS  # Linux alternative: sha256sum -c SHA256SUMS
uv python install 3.12
mkdir -p "$HOME/code"
git clone https://github.com/synaptixs/spine.git "$HOME/code/spine"
cp env.example .env
# Edit SPINE_REPO in .env if you already have an authorized clone elsewhere.
source .env
```

Recipients need access to this repository, target commit, and Spine tag. If cloning fails, obtain access from the repository owner. This release supports Python create/edit scenarios on the pinned Spine target, **not arbitrary target repositories**. Installation downloads dependencies and spec-kit; model execution requires network access.

Use absolute paths. Give every experiment a new WORK_DIR and RESULTS_DIR. Keep WORK_DIR outside your home directory and the harness. `/tmp` may be cleared on reboot. Credentials belong in their separate CODEX_LOGIN_HOME, never in results or the package.

## 2. Sign in with the team's own account

```bash
umask 077
mkdir -p "$CODEX_LOGIN_HOME"
chmod 700 "$CODEX_LOGIN_HOME"
CODEX_HOME="$CODEX_LOGIN_HOME" codex -c 'cli_auth_credentials_store="file"' login
CODEX_HOME="$CODEX_LOGIN_HOME" codex login status
```

Choose **Sign in with ChatGPT**. On a headless host, use `login --device-auth` if allowed by the organization. Follow managed authentication requirements if they prohibit file storage. Never copy another person's auth cache. [Official authentication guidance](https://learn.chatgpt.com/docs/auth).

The account must support the exact MODEL in `.env`. If another model is required, label it as a separate experiment and verify its published rates in `codex_usage.py`. The harness cannot grant model access. Default subscription mode clears API credential variables.

## 3. Setup and checks — no model calls

```bash
bash setup.sh
uv run --frozen --project "$WORK_DIR/spine-code" python -m unittest -v \
  test_codex_backend test_report_usage test_scenarios
uv run --frozen --project "$WORK_DIR/spine-code" python scenarios.py list
uv run --frozen --project "$WORK_DIR/spine-code" python scenarios.py validate
python3 run_comparison.py --dry-run --models "$MODEL" --passes 1 --parallel 1
```

Setup should end with `== ready`. It creates two pinned detached worktrees and installs locked dependencies. Validation checks selected IDs, required edit targets, held-out syntax, and agreement between the target and Spine catalogs. It does not prove that a custom judge is correct or that the account has model access. Review new judges before spending model capacity.

## 4. Run the one-ticket pilot

The default TICKETS contains `NEW-SEVSUMMARY-1`.

```bash
python3 run_comparison.py --models "$MODEL" --passes 1 --parallel 1 \
  --cap 25 --job-cap 20
```

The runner saves `EXPERIMENT.json` before model execution, including task/judge fingerprints, selected scenarios, versions, and policy. Both workflows run serially in subscription mode. Watch `$RESULTS_DIR/$MODEL/logs/`; a stage's log can remain unchanged while its model process runs.

**Checklist policy:** spec-kit can pause before implementation because reviewer checklist items are unchecked. Inspect its output. If your operator approves proceeding, either use `--approve-checklist` on a **fresh** batch, or recover a saved checklist pause after its original process exits:

```bash
uv run --frozen --project "$WORK_DIR/spine-code" python speckit_codex.py \
  "$MODEL" NEW-SEVSUMMARY-1 1 --cap 20 --resume-checklist --approve-checklist
```

Recovery preserves earlier usage and does not mark reviewer boxes. Both live checklist recovery and a completed 18-run stock study have been exercised. Organizational/app approvals remain in force.

`--cap` is a conservative pass-admission estimate; `--job-cap` checks spec-kit cost between stages. Neither is a hard spending limit. Costs in subscription mode are **API list-price equivalents, not charges**. The default fallback admission reserve is $16 per spec-kit ticket per model plus $1 per Spine pass; larger catalogs can require a larger cap even when observed cost is lower.

## 5. Add different scenarios

Full instructions and schema: **[SCENARIOS.md](SCENARIOS.md)**. The two included examples exercise an edit to an existing module and creation of a new module.

```bash
# Copy the sample catalog and its separate held-out tests.
cp -R examples team-scenarios
# Edit team-scenarios/scenarios.json and team-scenarios/heldout/test_*.py.
# Keep this directory outside WORK_DIR and SPINE_REPO.
```

For a new experiment, edit `.env` to use **fresh** WORK_DIR and RESULTS_DIR and add:

```bash
export SCENARIO_FILE="$PWD/team-scenarios/scenarios.json"
export TICKETS=CUSTOM-EDIT-RANGE-1,CUSTOM-NEW-HISTOGRAM-1
# You may mix built-in and custom IDs in the same comma-separated list.
```

Then reload and validate:

```bash
source .env
bash setup.sh
uv run --frozen --project "$WORK_DIR/spine-code" python scenarios.py list
uv run --frozen --project "$WORK_DIR/spine-code" python scenarios.py validate
python3 run_comparison.py --dry-run --models "$MODEL" --passes 3 --parallel 1
```

After reviewing the catalog, budget, and checklist policy, run:

```bash
python3 run_comparison.py --models "$MODEL" --passes 3 --parallel 1 \
  --cap 200 --job-cap 20 --approve-checklist
```

This two-scenario example schedules **12 ticket-arm runs**, plus six separate intake measurements. In general: scenarios × repeats × workflows × models. Do not edit scenario definitions or tests during a batch. Freeze the catalog with your experiment records; changing either changes its fingerprint.

To use more built-in problems without writing a catalog, leave SCENARIO_FILE unset and choose IDs from `scenarios.py list`. Ten built-ins are exposed: five create and five edit tasks. A six-scenario example is:

```bash
export TICKETS=NEW-SEVSUMMARY-1,NEW-LEDGERMD-1,NEW-DRIFTMD-1,EDIT-STATS-1,EDIT-LEDGER-1,EDIT-BUDGET-1
```

Use fresh directories and repeat setup/validation for that experiment. Three passes across two workflows produce **36 ticket-arm runs**; the fallback reserve is $97 per pass for one model, so choose a suitable admission cap rather than assuming the pilot cap works.

## 6. Report and hand back results

Only after all child processes have exited:

```bash
python3 report_results.py --results "$RESULTS_DIR"
```

Read `summary.md` and `recorded-usage.json`. The report supports arbitrary catalog sizes, matches intake by ticket/pass, and compares scenario means rather than treating repeats as independent problems. It defers inference when planned paired measurements are incomplete. No quality-equivalence claim follows from equal pass counts. The old `summarize.py` is legacy exploratory analysis; use `report_results.py` for new experiments.

Return `EXPERIMENT.json`, your frozen scenario catalog and test hashes, `summary.md`, `recorded-usage.json`, per-run `summary.json` files, intake `pass*.json`, and any failure records. Review source code and task context before sharing raw transcripts or generated code. Never include `.env`, auth.json, CODEX_LOGIN_HOME, or the entire WORK_DIR. Missing exported usage means unknown usage, not zero.

## 7. Failures and interpretation

| Symptom | Action |
|---|---|
| Unknown or duplicate ID | Use `scenarios.py list`; IDs are case-sensitive and must be unique. |
| Custom tests not found / syntax error | Fix paths relative to the catalog and validate again before a fresh run. |
| Target and Spine fingerprints differ | Resolve the task/judge mismatch; do not compare mismatched tasks. |
| Catalog changed during a run | Stop and preserve that experiment; the report rejects mixed fingerprints. |
| Model unavailable, capacity error, quota stop | Preserve failed output. Wait for availability or start a separately labeled experiment on another model. |
| Existing output / JOB_FAILED | Do not overwrite it. Inspect the failure and use fresh experiment directories for a new attempt. |
| Checklist pause | Use the documented approved checklist recovery after the job exits. |
| Repository-count gate failure | Record it separately; it is not the full test suite and does not alone establish functional failure. |
| Missing response records | Treat token accounting as incomplete and check CLI compatibility. |

The batch runner is not a general resume scheduler. `--resume-capacity` is retained for a manually captured, verified capacity checkpoint; it does not create such a checkpoint or provide automatic recovery. The completed study's one-off recovery driver is not shipped. New JSON scenarios and edit-file detection have offline integration checks, not a new paid model benchmark. See METHODOLOGY.md for study-design limits.
