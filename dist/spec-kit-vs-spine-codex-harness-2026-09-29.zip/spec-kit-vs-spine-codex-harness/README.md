# spec-kit vs Spine + PKG — Codex subscription harness

External handover, 2026-09-29. Start with **[QUICKSTART.md](QUICKSTART.md)**.

This harness runs both workflows through the Codex CLI using the recipient's own
ChatGPT sign-in. No OpenAI API key is needed in the default configuration. It can
be launched from a terminal or from a local Codex app project.

The archive contains the harness and instructions, not the Spine repository, model
credentials, installed dependencies, or the author's results. Recipients need access
to the pinned Spine repository and a Codex account with the selected model available.
Repository access must be arranged separately if their Git account cannot clone it.

| Item | Default / tested value |
|---|---|
| Model | `gpt-6-sol`, high reasoning |
| Codex CLI tested | `0.157.0` |
| Python | 3.12 |
| uv tested | 0.8.0 |
| Target commit | `bd16dbb7d2451bfaffa94c02946972050e23a610` |
| Spine implementation | `v3.52.0` (`6c0454bac2dbb539665402d31e57e763db2d206a`) |
| spec-kit | `v1.0.11` |
| Corrected held-out suite | `a6ac7c34`, applied by `heldout_fix.py` |
| Platforms | Tested on macOS; Bash-based Linux/WSL execution is unverified |

## Included

- `setup.sh`, `env.example`: dependencies and isolated worktree setup.
- `run_comparison.py`, `speckit_codex.py`, `spine_pkg.py`, `spine_intake.py`: runners.
- `codex_llm.py`, `codex_usage.py`, `codex_protocol.py`: completion adapter and accounting.
- `summarize.py`: descriptive outcomes and legacy exploratory comparison tables.
- `report_usage.py`: portable token/cost report from exported per-response ledgers.
- `test_codex_backend.py`, `test_report_usage.py`: tests that make no model calls.
- `CODEX_RUN.md`, `METHODOLOGY.md`: implementation details and interpretation limits.
- `MANIFEST.json`, `SHA256SUMS`: package versions and file integrity checks.

The default quickstart exercises one stock ticket. Three stock tickets are supported:
`NEW-SEVSUMMARY-1`, `NEW-LEDGERMD-1`, and `NEW-DRIFTMD-1`.
This is not yet a generic benchmark runner for arbitrary repositories or ticket files.
The earlier proposal for 12 diverse problems requires additional fixtures and graders.

## Status

The subscription adapter completed one Spine pilot with functional and held-out tests
passing and the repository documentation-count check failing. Spec-kit completed planning
and paused before implementation at an unchecked reviewer checklist. End-to-end recovery
past that checklist has not yet been validated in a live model run.

The new adapter changes the model interface and overhead. Results should be identified
as **Codex subscription adapter** results, not pooled with historical direct-API runs.
Dollar figures are API list-price equivalents, not subscription invoices.

The archive also retains the original optional API/Claude runners for reference; that
route is not the validated handover path. No third-party repository or package is vendored.
Use those dependencies under their own access requirements and licenses.
