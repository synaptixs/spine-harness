#!/usr/bin/env python3
"""Run spec-kit and Spine + PKG on the same tickets, models and commit, with a soft budget.

  ./run_comparison.py --dry-run --models claude-sonnet-5 --passes 1        # what would run; no spend
  ./run_comparison.py --models claude-sonnet-5 --passes 3 --cap 60         # the published Claude run
  ./run_comparison.py --models gpt-5.6-sol,gpt-6-astra --passes 2 --cap 150  # the published OpenAI run
  ./run_comparison.py --models gpt-5.6-sol --arms spine --passes 2         # re-measure only Spine

claude-* models drive spec-kit through Claude Code; gpt-* models through the Codex CLI. Each pass
runs every ticket through spec-kit (in parallel) plus Spine + PKG and its intake step. A pass only
starts if the money already spent plus that pass's reserve fits under --cap; the first quota
error writes RESULTS_DIR/QUOTA_STOP and every job stops. Then: ./summarize.py
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import harness_config as C

# Measured cost of one spec-kit run per model (USD), used only to reserve budget before a pass.
SPECKIT_RESERVE = {"claude-sonnet-5": 6.0, "gpt-5.6-sol": 8.0, "gpt-6-astra": 16.0}
SPINE_RESERVE = 1.0  # a whole Spine + PKG pass on one model, all tickets, measured well under this


def spent() -> float:
    total = 0.0
    for p in C.RESULTS_DIR.glob("*/speckit/*/summary.json"):
        total += json.loads(p.read_text())["total"]["cost_usd"]
    for p in C.RESULTS_DIR.glob("*/spine/pass*/*/summary.json"):
        total += json.loads(p.read_text()).get("cost_usd") or 0.0
    for p in C.RESULTS_DIR.glob("*/intake/pass*.json"):
        total += sum(r["cost_usd"] for r in json.loads(p.read_text()))
    return total


def py(script: str, *args: str) -> list[str]:
    return ["uv", "run", "--frozen", "--project", str(C.SPINE_CODE_DIR), "python", str(C.HERE / script), *args]


def run(cmd: list[str], log: Path, dry: bool) -> None:
    if not dry and (C.RESULTS_DIR / "JOB_FAILED").exists():
        raise RuntimeError("Earlier job failed; inspect JOB_FAILED before restarting")
    log.parent.mkdir(parents=True, exist_ok=True)
    if dry:
        subprocess.run([*cmd, "--dry-run"], cwd=C.HERE, check=True)
        return
    with open(log, "w") as f:
        proc = subprocess.run(cmd, cwd=C.HERE, stdout=f, stderr=subprocess.STDOUT)
    text = log.read_text(errors="replace").lower()
    if any(m in text for m in C.QUOTA_MARKERS) and not C.STOP.exists():
        C.STOP.write_text(f"quota error in {log}\n")
    if proc.returncode:
        (C.RESULTS_DIR / "JOB_FAILED").write_text(f"exit {proc.returncode}: {log}\n")
        raise RuntimeError(f"Job failed (exit {proc.returncode}); inspect {log}")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--models", required=True, help="comma-separated, e.g. claude-sonnet-5,gpt-5.6-sol")
    ap.add_argument("--passes", type=int, default=1)
    ap.add_argument("--arms", default="speckit,spine", help="speckit, spine, or both")
    ap.add_argument("--cap", type=float, default=25.0, help="pass admission budget in equivalent USD; may overshoot")
    ap.add_argument("--job-cap", type=float, default=None, help="per spec-kit run cap in USD")
    ap.add_argument("--parallel", type=int, default=3, help="spec-kit runs at once (lower it if you hit rate limits)")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--approve-checklist", action="store_true",
                    help="Operator explicitly approves Codex implementation with unchecked reviewer checklist items")
    a = ap.parse_args()
    models, arms = a.models.split(","), set(a.arms.split(","))
    if C.CODEX_AUTH == "app" and any(not m.startswith("claude") for m in models):
        if "spine" in arms and C.SPINE_BACKEND != "codex" and not os.environ.get("OPENAI_API_KEY"):
            sys.exit("CODEX_AUTH=app signs in spec-kit's Codex runs only. Spine + PKG calls OpenAI's API "
                     "directly and needs OPENAI_API_KEY; without one, run spec-kit alone: --arms speckit")
        if a.parallel > 1:
            # Every run shares one sign-in; one at a time keeps concurrent runs from racing on it.
            print(f"CODEX_AUTH=app: running one job at a time (--parallel {a.parallel} ignored)")
            a.parallel = 1
    C.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    if C.STOP.exists():
        sys.exit(f"{C.STOP} exists ({C.STOP.read_text().strip()}) — fix the quota, delete it, re-run")
    if (C.RESULTS_DIR / "JOB_FAILED").exists() and not a.dry_run:
        sys.exit("JOB_FAILED exists; diagnose it, then select fresh WORK_DIR and RESULTS_DIR")
    for n in range(1, a.passes + 1):
        reserve = sum(SPECKIT_RESERVE.get(m, 16.0) * len(C.TICKETS) for m in models if "speckit" in arms)
        reserve += SPINE_RESERVE * len(models) * ("spine" in arms)
        if not a.dry_run and spent() + reserve > a.cap:
            print(f"cap: pass {n} not started (spent ${spent():.2f}, reserve ${reserve:.2f}, cap ${a.cap:.2f})")
            break
        if C.STOP.exists():
            print(f"quota stop: pass {n} not started")
            break
        jobs = []
        with ThreadPoolExecutor(max_workers=max(1, a.parallel)) as pool:
            for m in models:
                if "speckit" in arms:
                    for key in C.TICKETS:
                        tag = f"{key.lower()}-p{n}"
                        if m.startswith("claude"):
                            cmd = py("speckit_claude.py", key, str(n), "--model", m)
                        else:
                            cmd = py("speckit_codex.py", m, key, str(n))
                            if a.approve_checklist:
                                cmd += ["--approve-checklist"]
                        if a.job_cap:
                            cmd += ["--cap", str(a.job_cap)]
                        jobs.append(pool.submit(run, cmd, C.RESULTS_DIR / m / "logs" / f"speckit-{tag}.log", a.dry_run))
                if "spine" in arms:
                    jobs.append(pool.submit(run, py("spine_pkg.py", m, str(n)),
                                            C.RESULTS_DIR / m / "logs" / f"spine-p{n}.log", a.dry_run))
                    jobs.append(pool.submit(run, py("spine_intake.py", m, str(n)),
                                            C.RESULTS_DIR / m / "logs" / f"intake-p{n}.log", a.dry_run))
            for j in jobs:
                j.result()
        print(f"pass {n} done — spent so far ${spent():.2f}", flush=True)
    print("next: ./summarize.py" if not a.dry_run else "dry run only — nothing was spent")


if __name__ == "__main__":
    main()
