# Quickstart — both arms through Codex, no API key

Run these commands in **Bash**, from the unpacked harness directory. You can use the
Codex app's terminal or a normal terminal; the desktop app is not required. Each team
uses its own ChatGPT login and repository access. No author's credentials are included.

## 1. Prerequisites and repository access

Install Git, Bash, Python 3.12, [uv](https://docs.astral.sh/uv/getting-started/installation/),
and the [Codex CLI](https://learn.chatgpt.com/docs/codex/cli). The tested CLI is 0.157.0;
other versions may change flags or token-log formats. macOS is tested; Linux/WSL is not.
Native PowerShell is not supported by these shell scripts.

```bash
git --version
uv --version
codex --version
uv python install 3.12
mkdir -p "$HOME/code"
git clone https://github.com/synaptixs/spine.git "$HOME/code/spine"
```

If cloning is denied, obtain repository access from the project owner, or use an
authorized local clone containing the required commit and tag. Do not substitute an
unrelated repository: the stock tickets and graders depend on Spine internals.
Setup downloads dependencies and spec-kit; model runs require OpenAI connectivity.

## 2. Unpack and configure

```bash
unzip spec-kit-vs-spine-codex-harness-2026-09-29.zip
cd spec-kit-vs-spine-codex-harness
cp env.example .env
# Edit .env if your Spine checkout is not at $HOME/code/spine.
source .env
```

Use absolute paths. Keep WORK_DIR outside your home directory and use a new
WORK_DIR and RESULTS_DIR for each new experiment. Keep the same CODEX_LOGIN_HOME
to reuse your own harness sign-in. `/tmp` data may disappear on reboot.

## 3. Sign in once to the isolated harness home

```bash
umask 077
mkdir -p "$CODEX_LOGIN_HOME"
chmod 700 "$CODEX_LOGIN_HOME"
CODEX_HOME="$CODEX_LOGIN_HOME" codex -c 'cli_auth_credentials_store="file"' login
CODEX_HOME="$CODEX_LOGIN_HOME" codex login status
```

Choose **Sign in with ChatGPT**. On a headless host, use `login --device-auth` if your
organization permits device login. Follow managed authentication requirements if
they prohibit file storage. These commands target the isolated CODEX_HOME; do not copy
or distribute anyone else's authentication cache. See [official authentication guidance](https://learn.chatgpt.com/docs/auth).

Your account must have access to MODEL from `.env`. The package does not grant access
or bypass subscription limits. If the model is unavailable, select one available to
your team and identify it separately in results. Unknown model prices must be added
from the official pricing page before running; see CODEX_RUN.md.

## 4. Setup, tests, and dry run

```bash
bash setup.sh
uv run --frozen --project "$WORK_DIR/spine-code" python -m unittest -v \
  test_codex_backend test_report_usage
python3 run_comparison.py --dry-run --models "$MODEL" --passes 1 --parallel 1
```

Setup should finish with `== ready`. It creates detached target and Spine worktrees,
installs their locked dependencies, and copies the shared constitution to results.
The tests and dry run make no model requests. They do not verify model entitlement.
Dependencies can take several minutes to install. Missing refs or mismatched existing
trees must be resolved before running.

## 5. Run the one-ticket pilot

```bash
python3 run_comparison.py --models "$MODEL" --passes 1 --parallel 1 \
  --cap 25 --job-cap 20
```

Both arms run serially. Progress is written under `$RESULTS_DIR/$MODEL/logs/`.
Allow time for planning and implementation; no runtime or token-use guarantee is made.
`--cap` checks an estimated reserve before admitting a pass; `--job-cap` checks between
spec-kit steps. **Neither is a hard spending limit.** A step may exceed the budget.
In subscription mode all dollar amounts are API list-price equivalents, not charges.

Spec-kit can pause at its reviewer checklist. That is recorded as an incomplete run.
Read its `07-implement.jsonl`, generated checklist, and summary before deciding.
Only after the operator explicitly approves proceeding with unchecked items, resume:

```bash
uv run --frozen --project "$WORK_DIR/spine-code" python speckit_codex.py \
  "$MODEL" NEW-SEVSUMMARY-1 1 --cap 20 --resume-checklist --approve-checklist
```

This reuses the session, preserves the previous summary, and counts its earlier planning.
It does not mark reviewer checkboxes. Recovery is implemented and locally checked but
has not yet completed a live model pilot. Do not run recovery while the original job
is active. For another ticket/pass, replace the ticket and pass number accordingly.

For a fresh batch, an operator may explicitly authorize the same checklist policy by
adding `--approve-checklist` to run_comparison.py. Without that flag, pauses are preserved.
The default protocol is not an instruction to bypass approvals from the app or organization.

## 6. Produce and hand back results

After all child runs have exited:

```bash
python3 summarize.py
python3 report_usage.py --results "$RESULTS_DIR" > "$RESULTS_DIR/recorded-usage.json"
```

`summary.md` reports outcomes; `recorded-usage.json` counts exported Codex response
ledgers without any personal accounting script. No records means unknown usage, not zero.
Check per-run summaries for `usage_complete`, `aborted`, `paused_for_checklist`,
`reached_code`, `held_out_pass`, and `repo_gate_pass`. Not all fields occur on both arms.
Functional success and repository-check success are separate outcomes.

Before sharing, inspect results for source code and sensitive task context. **Never send
`.env`, CODEX_LOGIN_HOME, auth.json, or the entire WORK_DIR.** For a compact handback,
include summary.md, recorded-usage.json, and the per-run summary.json and intake/pass*.json
files. Raw transcripts and generated code are optional evidence to share through an
appropriate channel after review. Include CLI/uv/Python versions, OS, model, reasoning
effort, ticket list, pass count, and checklist policy in your handback notes.

## 7. More runs and troubleshooting

For the stock three-ticket experiment, change `.env` to fresh WORK_DIR/RESULTS_DIR,
set TICKETS to the three IDs in env.example, source it, and rerun setup. Then:

```bash
python3 run_comparison.py --models "$MODEL" --passes 3 --parallel 1 \
  --cap 200 --job-cap 20
```

This schedules **18 ticket-arm runs**, with intake measured separately. It is still
only three small problems on one repository; see METHODOLOGY.md before claiming significance.
The adapter is not a ready-made implementation of the proposed 12-problem study.

| Symptom | Action |
|---|---|
| `NOT signed in` | Repeat login using the same CODEX_LOGIN_HOME; confirm ChatGPT mode. |
| Model unavailable | Check team entitlement; do not silently replace the model in a comparison. |
| `cap: pass ... not started` | The conservative reserve exceeds the remaining soft budget; inspect it before adjusting. |
| `QUOTA_STOP` | Stop, inspect the log, and wait for/reset the account limit as appropriate. Preserve the failed run. |
| `JOB_FAILED` / existing worktree | Inspect logs; select fresh WORK_DIR and RESULTS_DIR for a restart, then rerun setup. |
| Checklist pause | Follow the explicit approval and saved-session recovery procedure above. |
| Missing response ledger | Treat accounting as incomplete; check Codex CLI compatibility. |
| Network denied by Codex app | Use the app's normal permission flow; the harness does not override it. |
| Repository count gate fails | Record the failure separately; do not silently repair the generated benchmark output. |

The batch runner is not a general checkpoint/resume scheduler. Only the specific
checklist recovery is supported. Preserve interrupted output rather than rerunning
over existing trees. Generated code and tests run locally; use a dedicated development
environment appropriate for executing that code.
