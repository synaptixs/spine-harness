# Experiment scope and reporting

The bundled experiment supports three small new-module tickets on one pinned Spine
repository. Repeating them estimates run-to-run variation; it does not create additional
independent problems. No supplied historical multiplier is a promised outcome.

Before a batch, record model, reasoning effort, target/Spine/spec-kit/CLI versions,
ticket wording, held-out tests, resource limits, retry policy, and checklist/clarification
policy. Apply the same policy to every repeat. The stock runner uses a fixed serial order
in subscription mode; it does not randomize paired workflow order.

Report every attempted run, including pauses, failures, timeouts, and manual interventions.
Report held-out functional success and repository readiness separately. An unchanged
repository passing its gate is not an implementation success. A tracked documentation
update is not automatically a harmful scope violation. The current source-based scope
counter needs interpretation, not just a lower-is-better ranking.

Useful outputs are per-ticket cost/token/time distributions, success rates, repository
gate rates, intervention counts, and total spend divided by accepted implementations
(including failed attempts in spend). Preserve cache splits and identify cost as an API
list-price equivalent. Missing interrupted usage must remain unknown.

For a broader study, a practical starting plan is 12 different tickets across three
repositories, three repeats, and both workflows: 72 ticket-arm runs with one model.
Include new modules, existing-code bug fixes, cross-module changes, and refactoring.
This is a planning target, not a statistical power calculation.

That broader study requires extending this harness: repository-specific ticket catalogs,
target commits, grading, setup, scope rules, and a randomized paired execution schedule.
Simply changing SPINE_REPO or inventing IDs in TICKETS does not implement those changes.

Use paired ticket-level comparisons and keep repeat runs together when resampling.
Account for repository grouping, show per-repository results, and decide the desired
precision or detectable effect before collecting more data. Do not stop solely when
p falls below 0.05. A non-significant quality difference does not demonstrate equivalence.

References:
- [SciPy: independent vs paired comparisons](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.mannwhitneyu.html)
- [ASA: interpretation of p-values](https://www.amstat.org/docs/default-source/amstat-documents/p-valuestatement.pdf)
