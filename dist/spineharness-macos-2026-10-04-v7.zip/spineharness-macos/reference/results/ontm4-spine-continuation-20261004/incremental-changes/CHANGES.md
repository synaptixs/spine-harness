# Proposed changes

These changes exist only in the disposable benchmark copy.

```diff
diff --git a/runtime/reasoning_search/_loaders.py b/runtime/reasoning_search/_loaders.py
index c7d0530..458863f 100644
--- a/runtime/reasoning_search/_loaders.py
+++ b/runtime/reasoning_search/_loaders.py
@@ -229,6 +229,17 @@ def load_rules(
                     )
             except ValueError:
                 continue
+    if not source:
+        from .rule_compiler import compile_rules
+
+        ontology_dir = os.path.join(root, "output", "ontology")
+        ontology_paths = [
+            os.path.join(ontology_dir, name)
+            for name in ("enterprise.ttl", "events.ttl")
+            if os.path.isfile(os.path.join(ontology_dir, name))
+        ]
+        if ontology_paths:
+            candidates.extend(compile_rules(ontology_paths))
     if stored_rules is None:
         session_path = os.path.join(root, ".wizard_session.json")
         if os.path.isfile(session_path):
diff --git a/runtime/reasoning_search/engine.py b/runtime/reasoning_search/engine.py
index 1decaf9..b00e246 100644
--- a/runtime/reasoning_search/engine.py
+++ b/runtime/reasoning_search/engine.py
@@ -448,11 +448,20 @@ def search(
     inferred_cites: list[Citation] = []
     if rules:
         facts: list = list(extra_facts or [])
+        primary_table = mapping.table_for(the_plan.primary_class)
+        mapped_properties = [
+            (prop, col)
+            for (cls, prop), (table, col) in mapping.prop_col.items()
+            if cls == the_plan.primary_class and table == primary_table
+        ]
         for i, row in enumerate(rows):
             key = str(row.get("id", i))
             facts.append((the_plan.primary_class, key))
             for col, val in row.items():
                 facts.append((col, key, str(val)))
+            for prop, col in mapped_properties:
+                if col in row and prop != col:
+                    facts.append((prop, key, str(row[col])))
         if auto_relations and neighbors:
             facts += _facts_from_neighbors(neighbors)
         try:
diff --git a/tests/test_search_rule_default_inference.py b/tests/test_search_rule_default_inference.py
new file mode 100644
index 0000000..36f9d8d
--- /dev/null
+++ b/tests/test_search_rule_default_inference.py
@@ -0,0 +1,128 @@
+"""Exercise default OWL rule compilation with real forward chaining."""
+
+from __future__ import annotations
+
+import json
+import sqlite3
+from pathlib import Path
+from typing import Any
+
+import pytest
+
+from runtime.reasoning_search import _loaders, engine, search
+from runtime.reasoning_search.cli import run
+
+
+class OfflineAdapter:
+    """Supply a fixed plan while leaving inference to the real reasoner."""
+
+    model_id = "offline"
+
+    def complete(self, payload: dict[str, Any]) -> str:
+        if payload.get("payload_id") == "reasoning-search-synth":
+            return "Search complete."
+        return json.dumps({"intent": "list", "classes": ["DomainEvent"], "filters": []})
+
+
+def test_default_rules_compile_and_infer(
+    tmp_path: Path,
+    monkeypatch: pytest.MonkeyPatch,
+    capsys: pytest.CaptureFixture[str],
+) -> None:
+    ontology_dir = tmp_path / "output" / "ontology"
+    ontology_dir.mkdir(parents=True)
+    (ontology_dir / "events.ttl").write_text(
+        "@prefix ex: <urn:test#> . "
+        "@prefix owl: <http://www.w3.org/2002/07/owl#> . "
+        "ex:DomainEvent a owl:Class . "
+        "ex:IncidentEvent a owl:Class ; owl:equivalentClass "
+        "[ owl:intersectionOf ( ex:DomainEvent [ a owl:Restriction ; "
+        'owl:onProperty ex:hasEventType ; owl:hasValue "INCIDENT" ] ) ] . '
+        "ex:MaintenanceEvent a owl:Class ; owl:equivalentClass "
+        "[ owl:intersectionOf ( ex:DomainEvent [ a owl:Restriction ; "
+        'owl:onProperty ex:hasEventType ; owl:hasValue "MAINTENANCE" ] ) ] . '
+        "ex:hasEventType a owl:DatatypeProperty .",
+        encoding="utf-8",
+    )
+    flavors_dir = tmp_path / "flavors"
+    flavors_dir.mkdir()
+    (flavors_dir / "demo.json").write_text(
+        json.dumps(
+            {
+                "owl_classes": ["DomainEvent", "IncidentEvent", "MaintenanceEvent"],
+                "db_tables": ["events"],
+            }
+        ),
+        encoding="utf-8",
+    )
+    mapping_path = tmp_path / "mapping.csv"
+    mapping_path.write_text(
+        "\n".join(
+            (
+                "ontology_class,ontology_property,physical_table,"
+                "physical_column,sensitivity_tier",
+                "DomainEvent,(class),events,(table),Internal",
+                "DomainEvent,id,events,id,Internal",
+                "DomainEvent,hasEventType,events,event_type,Internal",
+            )
+        )
+        + "\n",
+        encoding="utf-8",
+    )
+    db_path = tmp_path / "events.db"
+    with sqlite3.connect(db_path) as connection:
+        connection.execute("CREATE TABLE events (id INTEGER, event_type TEXT)")
+        connection.executemany(
+            "INSERT INTO events VALUES (?, ?)",
+            [(1, "INCIDENT"), (2, "MAINTENANCE")],
+        )
+
+    def adapter_for(providers: str | dict[str, str] | None) -> OfflineAdapter:
+        return OfflineAdapter()
+
+    monkeypatch.delenv("ONTOFORGE_RULES", raising=False)
+    monkeypatch.setattr(engine, "_DEFAULT_FLAVORS", str(flavors_dir))
+    monkeypatch.setattr(engine, "_DEFAULT_MAPPING", str(mapping_path))
+    monkeypatch.setattr(engine, "_resolve_adapter", adapter_for)
+    rules = _loaders.load_rules("demo", root=str(tmp_path), stored_rules=[])
+    assert any(rule.startswith("IncidentEvent(?x) :-") for rule in rules)
+    assert any(rule.startswith("MaintenanceEvent(?x) :-") for rule in rules)
+
+    answer = search(
+        "Which events occurred?", flavor="demo", db_path=str(db_path), rules=rules
+    )
+    facts = {tuple(item["fact"]) for item in answer.inferred}
+    assert ("IncidentEvent", "1") in facts
+    assert ("MaintenanceEvent", "2") in facts
+    incident = next(
+        item for item in answer.inferred if item["fact"] == ["IncidentEvent", "1"]
+    )
+    assert {tuple(fact) for fact in incident["derived_from"]} >= {
+        ("DomainEvent", "1"),
+        ("hasEventType", "1", "INCIDENT"),
+    }
+    assert any(
+        stage.get("stage") == "reason"
+        and stage.get("rules_loaded") == len(rules)
+        and stage.get("derived", 0) >= 2
+        for stage in answer.trace
+    )
+
+    original_load_rules = _loaders.load_rules
+
+    def local_load_rules(flavor: str, **kwargs: Any) -> list[str]:
+        return original_load_rules(flavor, root=str(tmp_path), **kwargs)
+
+    monkeypatch.setattr(_loaders, "load_rules", local_load_rules)
+    args = [
+        "Which events occurred?",
+        "--flavor",
+        "demo",
+        "--db",
+        str(db_path),
+        "--json",
+    ]
+    assert run(args) == 0
+    assert json.loads(capsys.readouterr().out)["inferred"]
+    assert run([*args, "--no-rules"]) == 0
+    assert json.loads(capsys.readouterr().out)["inferred"] == []

```
