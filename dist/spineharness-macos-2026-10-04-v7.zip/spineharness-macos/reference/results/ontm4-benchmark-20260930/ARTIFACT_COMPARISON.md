## Generated artifacts: what exists and what works

Both workflows produced **proposed source-code patches and tests in disposable copies of Ontomesh**. Neither delivered a deployed service, an installed release, a merged change, or a modified Jira ticket. The ZIP is an evidence package containing the proposed changes, documentation, measurements and validation results; it is not a ready-to-deploy application distribution.

| Output | spec-kit | Spine + PKG — after measured continuation |
|---|---|---|
| Application implementation | Five application files added/modified: CLI, engine, new `rule_sources.py`, HTTP handlers, and Ask HTML template. | Four application files modified: `_loaders.py`, CLI, engine, and HTTP handlers. |
| Tests in the patch | Two new test files (`test_search_rule_sources.py`, `test_search_rule_wiring.py`) and additions to two existing phase test files. | Two new test files: the original six surface tests plus `test_search_rule_default_inference.py`, a real compilation/inference test. Seven generated tests pass in total. |
| Planning and explanatory documents | Nine saved planning files: specification, plan, research, data model, tasks, quickstart, surface contract, and two checklists. | No equivalent standalone planning-document set was exported. The continuation now includes a rendered deterministic `design.md`, design metadata, exact diagnostic feedback, model requests and patches. |
| Tool scaffolding | Thirty `.agents` / `.specify` setup files also appear in the captured patch. These are workflow setup, not thirty application features. | PKG construction and deterministic design were used during execution. The export does not include a standalone reusable PKG database. |
| Reviewable code evidence | [spec-kit proposed changes](gpt-6-sol/speckit/ontm-4-p1/CHANGES.md), patch, saved source files and summary. | [Final cumulative Spine changes](../ontm4-spine-continuation-20261004/cumulative-changes/CHANGES.md), [incremental repair](../ontm4-spine-continuation-20261004/incremental-changes/CHANGES.md), and continuation summary. The original patch is also retained. |
| Behavioral result | The selected CLI, HTTP, SSE and fresh-SPARQL default-inference checks work on the test fixture. All seven independent checks pass. | All seven reused checks now pass, including default CLI/HTTP/SSE/fresh-SPARQL inference. This follows one measured refinement with diagnostic feedback. The original first result was three passed and four failed. |

### How far apart are the implementations?

**The previously demonstrated default-rule gap is closed. Both saved outputs now pass the seven selected behaviors.** Spine’s continuation invokes the supplied compiler for default ontology sources and adds logical property aliases to the primary-row facts consumed by the reasoner. It retains explicit rule-file support and CLI opt-out. The four earlier surface failures shared a rule-source gap; the follow-up is now a measured repair, not an estimated future task.

The repair changed two application files and added one real-inference test file. One additional gpt-6-sol/high response used **97,270 tokens** and **$0.280420 API list-price equivalent**. Combined with the completed October 4 attempt, Spine used **297,267 tokens** and **$0.789800 API list-price equivalent**. These are not subscription charges; earlier suspended/unknown consumption is still separately disclosed.

The new test compiles a temporary OWL ontology, maps physical `event_type` values to the logical `hasEventType` predicate, checks IncidentEvent/MaintenanceEvent derivations and supporting facts using the real parser/reasoner, and exercises CLI default and opt-out behavior. Its LLM response and data locations are controlled; inference is not stubbed. The original six stubbed tests remain, and the frozen seven-check suite exercises the real HTTP/SSE/SPARQL paths. All 55 configured regression checks also pass.

This closes the observed functional difference on the selected suite, but does not prove the implementations interchangeable in all conditions. Spec-kit generated a separate rule-source resolver and Ask-template changes; Spine uses its loader and leaves the Ask template unchanged. Broader rule-source validation, completed browser rendering, mappings, entity identity and production behavior remain outside full acceptance. See [continuation validation](CONTINUATION_VALIDATION.md).

**Spec-kit also remains short of full production acceptance.** Its convergence review left four open remediation tasks: an inherited empty-column-projection fallback, permissive malformed-rule validation in its new resolver, a loaded-rule count lost in the completed Ask rendering, and inherited neighbor-key deduplication limitations. The independent review qualifies their attribution and reachability: these are not four newly introduced defects or four failed frozen tests. Additional rendering and broader mapping concerns are documented in [the independent review](INDEPENDENT_REVIEW.md). They still require investigation, appropriate fixes and validation before a production-readiness claim.

The current comparison is **matching results on seven selected behaviors, more planning/documentation from spec-kit, and lower recorded consumption for Spine even after its measured repair**. The feedback conditions differ: Spine was given the failed-check diagnosis before the additional refinement. This supports a transparent case comparison with cumulative costs, not an unbiased estimate of how often either tool will succeed or of equal overall code quality.

### Files to hand to a reviewer

| Artifact | Purpose |
|---|---|
| [COMPARISON_REPORT.md](COMPARISON_REPORT.md) | The readable comparison, stage costs, test explanations, implementation gaps and limitations. |
| [RESULTS.md](RESULTS.md) and [Spine completed-attempt results](../ontm4-spine-resumed-20261004/RESULTS.md) | Detailed per-attempt checks and proposed code changes. The original results file also preserves the failed first Spine attempt. |
| [Continuation report](CONTINUATION_REPORT.md) and [continuation verification](CONTINUATION_VERIFICATION.json) | Added repair work, cumulative Spine consumption and evidence after diagnostic feedback. |
| Each workflow’s `changes.patch` / `CHANGES.md` | Exact proposed changes relative to the prepared baseline; requires review before use in another checkout. |
| [spec-kit planning documents](gpt-6-sol/speckit/ontm-4-p1/planning/spec.md) | Specification and accompanying plan, tasks, contracts and quickstart in the same planning directory. The quickstart describes this generated proposal; it is not proof of acceptance. |
| [SUPPLEMENTAL_VALIDATION.md](SUPPLEMENTAL_VALIDATION.md) and `acceptance_audit/` | The independent seven-check results, logs, frozen tests and failure explanations. |
| [STAGE_TOKEN_BREAKDOWN.json](STAGE_TOKEN_BREAKDOWN.json), [recorded-usage.json](recorded-usage.json), [EVIDENCE_VERIFICATION.json](EVIDENCE_VERIFICATION.json) | Machine-readable stage accounting, all known recorded consumption and integrity checks. Missing interrupted-call usage stays explicit. |
| `comparison-results.zip` | Packaged evidence from all attempts, including this report and proposed changes; credentials and full raw model transcripts are excluded. |
