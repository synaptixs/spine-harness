# Validation after completing Spine default-rule integration

The user authorized completing the missing integration after the original report. The original Spine code, its three-of-seven result, the spec-kit result, and all interrupted-attempt evidence remain preserved. One separately recorded native Spine refinement produced the new output; no supervisor hand-edit of application code was used.

## What changed and why the gap is closed

The incremental patch changes `runtime/reasoning_search/_loaders.py` to call the existing `compile_rules()` using available `output/ontology/enterprise.ttl` and `events.ttl` when no explicit rule-source override is selected. Existing file loading and stored-rule handling remain. The engine now adds the primary class’s logical property predicates alongside physical-column facts, allowing mapped properties such as `hasEventType` to match the compiler’s rules when the physical column is named `event_type`.

The new `tests/test_search_rule_default_inference.py` runs real OWL compilation, SQL-backed search, rule parsing and forward chaining. It asserts both event classifications, derivation support, rule/derived counts in the trace, and CLI default/opt-out behavior. It replaces the language-model adapter and fixture paths, not the compiler or inference engine. The original six generated surface tests were retained.

| Validation on the continued Spine output | Result |
|---|---|
| Unchanged seven-check suite: explicit-rule control, CLI default, CLI opt-out, HTTP default, SSE default, fresh SPARQL, feature gates | 7 passed |
| Generated tests: six original plus one new real-inference test | 7 passed |
| Named FK-neighbor confidentiality suite | 6 passed; test file unchanged |
| Other configured project regression selection | 49 passed |
| Original source fingerprint and original frozen audit artifacts | Unchanged |
| Final cumulative and incremental patches | Match the disposable source |

The seven-check suite is unchanged, but the diagnostic feedback was used for this continuation. Its new result is **post-audit validation**, not an unseen holdout. The final trace and HTTP behavior were exercised with an offline scripted LLM; no live deployment or production data was used.

## Remaining limits

The demonstrated default-rule gap is fixed. That does not certify all Jira requirements or erase other limitations. The new engine aliases concern primary rows, not comprehensive neighbor identity/mapping support. The inherited primary-query empty-projection fallback and broader tier/property-alias combinations are not resolved by this repair; passing the six FK tests does not establish that every primary-query projection is safe. Spine still leaves the Ask HTML template unchanged. This follow-up did not perform complete browser-rendering, malformed-source, all-ontology, deployment or security acceptance.

Spec-kit’s original seven checks passed, while its qualified residual findings remain in `INDEPENDENT_REVIEW.md`. Both outputs therefore match the selected seven behaviors, but full functionality and overall quality equivalence remain unverified.

## Measured consumption

The additional closed Codex/gpt-6-sol/high response consumed **97,270 tokens**: uncached input **86,535**, output **10,735**, cache write **0**, cache read **0**. Its cost is **$0.280420 API list-price equivalent**, not subscription charges. The completed October 4 Spine attempt plus this continuation consumed **297,267 tokens**, **$0.7897996 API list-price equivalent**. Earlier suspended/unknown consumption is separate and retained in the aggregate accounting.

All available benchmark records, including this continuation and the known suspended response, reconcile to **12,093,075 tokens** (uncached input 755,819; output 133,800; cache write 0; cache read 11,203,456), **$5.0903292 API list-price equivalent**. Four older interrupted calls have unknown additional usage. Preparation, supervision and independent review are excluded. The active supervisory turn is not yet closed and is not reported as zero-cost work.

See [continuation verification](CONTINUATION_VERIFICATION.json), [cumulative patch](../ontm4-spine-continuation-20261004/cumulative-changes/CHANGES.md), [incremental patch](../ontm4-spine-continuation-20261004/incremental-changes/CHANGES.md), and [exact feedback](../ontm4-spine-continuation-20261004/FEEDBACK.txt).
