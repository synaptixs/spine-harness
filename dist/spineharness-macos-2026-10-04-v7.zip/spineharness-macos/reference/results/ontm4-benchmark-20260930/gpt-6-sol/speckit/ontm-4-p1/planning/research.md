# Research: Reasoning Rules on Search Surfaces

**Date**: 2026-09-30
**Source**: repository inspection for [spec.md](spec.md). No external services were contacted.

## Decision 1: Use the ONTM-2 compiler as the available runtime rule source

**Decision**: Resolve rules through `runtime.reasoning_search.rule_compiler.compile_rules()` using its repository-anchored local ontology inputs. Treat its output as shared ontology rules. Define a source adapter boundary so a future ONTM-3 store of Datalog-compatible rules can be combined with it, with identical parsed rules counted once.

**Rationale**: `compile_rules()` already returns deterministic `list[str]` Datalog rules compatible with `engine.search(rules=...)` (`runtime/reasoning_search/rule_compiler.py:117-132`; `runtime/reasoning_search/engine.py:240,344-366`). A read-only probe of the checked-in ontology compiled 72 rules. The present Wizard session stores SHACL, SPARQL, or OWL rule bodies rather than Datalog (`wizard/rules.py:13-27`, `wizard/app.py:1018-1036`); sending those bodies to `parse_rule` would be incorrect. ONTM-2 alone satisfies the stated prerequisite.

**Alternatives considered**: Parse Wizard rule bodies as Datalog (invalid format); translate every SHACL/SPARQL rule in this feature (broadens scope); require ONTM-3 before implementing (unnecessary because ONTM-2 exists).

## Decision 2: Derive only from authorized, mapped facts

**Decision**: Preserve the engine's physical-column facts for existing callers, and add ontology-property aliases only for returned columns that the mapping marks readable at the requested tier. For neighbor rows, retain the existing `auto_relations` gate and derive aliases only from rows already returned by the fail-closed neighbor loader.

**Rationale**: The compiler emits ontology predicates such as `hasEventType`, while row facts currently use physical column names such as `event_type` (`rule_compiler.py:81-113`, `engine.py:348-355`, `output/mapping/logical_physical_map.csv:50`). A plain `rules=` wire would make property-conditioned rules inert. `Mapping.readable_columns()` already identifies mapped, tier-cleared columns (`_loaders.py:60-84`). No rule may create a new database read.

**Alternatives considered**: Rewrite compiled rules to physical column names (loses ontology vocabulary and risks collisions); include every returned column as an ontology alias (could classify unmapped or above-tier data); turn on `auto_relations` whenever rules exist (violates the spec).

## Decision 3: Keep the existing access and relationship boundaries

**Decision**: Leave `_fk_neighbors` and its call conditions unchanged. Keep the selected tier ceiling, flavor table allow-list, mapped readable-column projection, and neighbor masking. Treat compiled global ontology rules as shared; any future stored rule needs explicit flavor or shared scope metadata before it is eligible.

**Rationale**: `_fk_neighbors` fails closed without a mapping, restricts allowed tables, and projects readable columns only (`engine.py:119-204`). It feeds both reasoning and materialized graphs, so weakening it would reopen the known SPARQL confidentiality bypass. The current Wizard `industry` field is not a search flavor field and must not be assumed equivalent.

**Alternatives considered**: Broaden automatic relationships for better inference (changes behavior and data exposure); infer flavor from Wizard industry (unsupported mapping); use unclassified neighbor columns (unsafe).

## Decision 4: Resolve a rule snapshot before each surface search

**Decision**: A shared resolver returns usable rule strings, diagnostics, and a stable revision fingerprint. CLI, synchronous HTTP, fresh-search SPARQL, and SSE each resolve a snapshot and pass its `rules` into `search`. The synchronous cache key includes the fingerprint. `--no-rules` supplies an empty snapshot.

**Rationale**: The three HTTP search calls are separate (`wizard/app.py:2197-2198,2239-2243,2287-2297`); the Ask console calls the SSE route. The current 60-second cache key omits rule state (`wizard/app.py:2186-2193`). Fingerprinting the effective, deduplicated rules prevents a stale cached inference after a rule change.

**Alternatives considered**: Resolve rules in only the synchronous route (misses SSE and SPARQL); disable the entire cache (changes unrelated performance behavior); trust TTL to expire stale inferences (violates FR-011).

## Decision 5: Emit one reason stage even for zero usable rules

**Decision**: After a search reaches reasoning, parse usable rules independently, run the valid set, and emit one `reason` trace entry with `rules_loaded` and `derived`, plus non-sensitive diagnostics if a source or rule failed. Blocked and ungrounded terminal searches retain their current earlier trace. The engine's existing `emit` callback sends the same stage to SSE before the final answer.

**Rationale**: The engine currently emits a reason stage only when `rules` is truthy and reports only derived count (`engine.py:344-368`). `on_event` is already the shared trace/SSE hook (`engine.py:260-267`). Per-rule validation allows a usable rule to fire despite another invalid rule, as clarified in the spec.

**Alternatives considered**: Add a separate SSE-only reason event (risks divergence from synchronous trace); fail the entire search on one bad rule (loses direct results); silently skip failures (hides why no inference appeared).

## Decision 6: Verify derivation with the real engine at each boundary

**Decision**: Use a temporary SQLite database, flavor JSON, mapping CSV, deterministic adapter, and a controlled rule. Test CLI default/opt-out, JSON status 200 with nonempty `inferred`, SSE reason event and final inferred facts, fresh-search SPARQL, cache revision, no-rules/error cases, and tier boundaries. Set `ONTOFORGE_SEARCH=1` before importing the HTTP app in new integration fixtures. Run `tests/test_fk_neighbor_tier_gating.py` separately.

**Rationale**: Existing API tests mostly stub `search` and can pass without reasoning (`tests/test_search_api.py:60-71,94-110`). The phase-2 engine fixtures show an offline deterministic adapter (`tests/test_reasoning_search_phase2.py:17-87`). The named FK regression has six cases; a baseline standalone run passed 6/6, but it must be rerun after implementation.

**Alternatives considered**: Assert only a non-error HTTP response (can pass against the feature-disabled 404 path or a non-reasoning response); use a live provider in tests (nondeterministic); rely only on the full suite total (hides the specific security gate).

## Resolved unknowns

- **Runtime rule format**: ONTM-2 yields Datalog strings; the current Wizard store does not.
- **Rule applicability**: compiled ontology rules are shared; future stored rules require explicit flavor/shared metadata.
- **Fact vocabulary**: expose mapped ontology-property aliases from authorized rows.
- **Cache revision**: fingerprint the effective rule set before synchronous cache lookup.
- **SSE progress**: use the engine's existing trace callback with a reason stage containing both counts.
