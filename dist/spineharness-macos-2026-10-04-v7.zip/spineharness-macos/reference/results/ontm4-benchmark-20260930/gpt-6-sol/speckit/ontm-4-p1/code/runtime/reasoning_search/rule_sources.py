"""Resolve an immutable, eligible Datalog rule set for one search flavor.

ONTM-2's local ontology compiler is the current source. A Datalog-compatible
stored source can be supplied by an adapter without interpreting Wizard's
SHACL/SPARQL/OWL session rule bodies as Datalog.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Callable, Iterable

from .reasoner import parse_rule
from .rule_compiler import compile_rules

_ATOM_TEXT = r"[A-Za-z_]\w*\s*\([^()]*\)"
_RULE_TEXT = re.compile(rf"\s*{_ATOM_TEXT}\s*:-\s*{_ATOM_TEXT}(?:\s*,\s*{_ATOM_TEXT})*\s*")


@dataclass(frozen=True)
class StoredRule:
    text: str
    scope: str = "shared"


@dataclass(frozen=True)
class RuleSnapshot:
    rules: tuple[str, ...]
    diagnostics: tuple[str, ...]
    revision: str
    flavor: str


def resolve_rules(
    flavor: str,
    *,
    stored_source: Callable[[], Iterable[StoredRule]] | None = None,
) -> RuleSnapshot:
    """Load and validate sources independently, preserving usable rules.

    Diagnostics contain only source names and rule positions. Exception text
    can contain file paths or stored rule bodies, so it is never included.
    """
    diagnostics: list[str] = []
    candidates: list[tuple[str, StoredRule]] = []
    try:
        candidates.extend(("compiled", StoredRule(text)) for text in compile_rules())
    except Exception:  # noqa: BLE001 - a failed source must not mask another
        diagnostics.append("compiled rule source unavailable")
    if stored_source is not None:
        try:
            candidates.extend(("stored", item) for item in stored_source())
        except Exception:  # noqa: BLE001
            diagnostics.append("stored rule source unavailable")

    found: dict[tuple, str] = {}
    for index, (source, candidate) in enumerate(candidates, 1):
        if not isinstance(candidate, StoredRule):
            diagnostics.append(f"{source} rule {index} has incompatible format")
            continue
        if candidate.scope not in ("shared", flavor):
            continue
        try:
            if not isinstance(candidate.text, str) or not _RULE_TEXT.fullmatch(candidate.text):
                raise ValueError("invalid rule syntax")
            parsed = parse_rule(candidate.text)
            body_vars = {term for atom in parsed.body for term in atom[1:]
                         if term.startswith("?")}
            if not all(term in body_vars for term in parsed.head[1:]
                       if term.startswith("?")):
                raise ValueError("unbound head variable")
        except (TypeError, ValueError):
            diagnostics.append(f"{source} rule {index} is invalid Datalog")
            continue
        identity = (parsed.head, parsed.body)
        found.setdefault(identity, candidate.text.strip())

    ordered = sorted(found.items(), key=lambda pair: repr(pair[0]))
    rules = tuple(text for _, text in ordered)
    canonical = json.dumps([identity for identity, _ in ordered],
                           ensure_ascii=False, separators=(",", ":"))
    revision = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return RuleSnapshot(rules, tuple(diagnostics), revision, flavor)
