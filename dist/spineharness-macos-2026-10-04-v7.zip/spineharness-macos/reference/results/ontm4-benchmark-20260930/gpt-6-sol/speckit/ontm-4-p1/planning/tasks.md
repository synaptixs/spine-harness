---
description: "Dependency-ordered implementation tasks for rule-enabled reasoning search"
---

# Tasks: Reasoning Rules on Search Surfaces

**Input**: [spec.md](spec.md), [plan.md](plan.md), [research.md](research.md), [data-model.md](data-model.md), [contracts/search-surfaces.md](contracts/search-surfaces.md), and [quickstart.md](quickstart.md)

**Tests**: Included because the feature specification requires focused derivation checks and an isolated six-case confidentiality regression.

**Organization**: Shared prerequisites first, then one phase for each user story in specification order. Paths below are relative to the repository root unless they refer to feature documents.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can proceed in parallel with independent work in a different file once its stated prerequisites are met.
- **[Story]**: Maps tasks to User Stories 1–4.
- Every task below names the file to create, edit, or validate.

## Path Conventions

- Runtime search code: `runtime/reasoning_search/`
- HTTP routes and Ask console: `wizard/app.py`, `wizard/templates/ask.html`
- Focused tests: `tests/`
- Planning and validation records: this feature directory

## Phase 1: Setup (Shared Offline Fixture)

**Purpose**: Prepare one deterministic, local search fixture for the surface-level acceptance checks; no new application infrastructure is needed.

- [X] T001 Create reusable temporary SQLite, flavor JSON, mapping CSV, fixed adapter, and isolated HTTP flag fixtures in tests/test_search_rule_wiring.py; set ONTOFORGE_SEARCH=1 before importing the enabled app and keep a separate disabled-gate fixture.

**Checkpoint**: Surface tests can run without a live model or external service.

---

## Phase 2: Foundational (Blocks All User Stories)

**Purpose**: Provide the rule snapshot and safe engine behavior that every surface uses.

- [X] T002 [P] Add failing resolver tests in tests/test_search_rule_sources.py for the ONTM-2 compiled source, a compatible injected stored source, shared versus flavor-specific eligibility, parsed-rule duplicate removal, deterministic revision, source failure, and invalid-rule isolation; assert Wizard SHACL/SPARQL bodies are never passed as Datalog.
- [X] T003 [P] Add failing engine tests in tests/test_reasoning_search_phase2.py for ontology-property facts from mapped readable columns, unchanged physical-column facts, no above-tier or unmapped aliases, unchanged auto_relations behavior, and a reason stage with loaded-rule and derived-fact counts including zero.
- [X] T004 Implement the shared RuleSnapshot resolver in runtime/reasoning_search/rule_sources.py: rules are deterministic, eligible, valid, and duplicate-free Datalog strings; diagnostics contain no sensitive database values; revision is stable; flavor scope is shared or a named flavor. Load compile_rules() by default, accept a compatible stored-source adapter when present, deduplicate identical parsed head/body pairs, and retain usable rules after another source or rule fails.
- [X] T005 [P] Add ontology-property aliases only for already returned columns cleared by Mapping.readable_columns() in runtime/reasoning_search/engine.py; retain existing physical-column facts and leave _fk_neighbors(), its fail-closed mapping check, allow-list, masking, tier projection, and auto_relations call conditions intact.
- [X] T006 Emit one reason trace entry for each search reaching reasoning in runtime/reasoning_search/engine.py, with rules_loaded equal to valid eligible deduplicated rules and derived equal to newly inferred facts, including zero counts; parse rules independently, include non-sensitive source/rule diagnostics, and use the existing on_event callback for SSE.

**Checkpoint**: A direct engine search with an ONTM-2 rule can derive a cited fact; zero-rule, invalid-rule, and restricted-data cases have defined traces and preserve direct results.

---

## Phase 3: User Story 1 — Command Line Search Derives Answers (Priority: P1) 🎯 MVP

**Goal**: The CLI uses rules by default and offers an explicit opt-out.

**Independent Test**: With the real resolver and engine over the shared fixture, CLI --json output has nonempty inferred for default and --rules searches; --no-rules has empty inferred and retains direct results.

### Tests for User Story 1

- [X] T007 [US1] Add failing CLI integration cases in tests/test_search_rule_wiring.py for default, --rules, and --no-rules with --json; assert a real newly derived fact, provenance, zero-rule trace on opt-out, and unchanged direct result/status.

### Implementation for User Story 1

- [X] T008 [US1] Add mutually exclusive --rules and --no-rules options in runtime/reasoning_search/cli.py, resolve rules by default, pass rules= and diagnostics to search(), and preserve existing --db, --provider, --max-tier, --k, --json, text output, and exit behavior.

**Checkpoint**: User Story 1 is independently demonstrable through the CLI without HTTP.

---

## Phase 4: User Story 2 — Enabled HTTP Search Returns Inferred Facts (Priority: P1)

**Goal**: POST /api/search produces a real reasoned answer when the feature is enabled and never serves an answer from an obsolete rule set.

**Independent Test**: With ONTOFORGE_SEARCH=1 explicitly set before app import, POST /api/search returns status 200 with nonempty inferred for a rule-dependent question; a changed rule snapshot yields a fresh answer; the disabled route remains 404.

### Tests for User Story 2

- [X] T009 [P] [US2] Add failing real-engine POST /api/search cases and four-route disabled-gate assertions in tests/test_search_rule_wiring.py; enabled cases must assert status 200 and nonempty inferred rather than only a non-error response.
- [X] T010 [US2] Add failing synchronous cache cases in tests/test_search_rule_wiring.py for unchanged-revision cache reuse, changed-rule revision refresh, and bypass of cache reuse when rule resolution reports a current failure.

### Implementation for User Story 2

- [X] T011 [US2] Resolve the rule snapshot and pass rules= plus diagnostics in the synchronous POST /api/search path in wizard/app.py, preserving the current gate, request fields, tier, materialize flag, metrics, and ReasonedAnswer JSON shape.
- [X] T012 [US2] Include the effective rule revision in the POST /api/search cache identity in wizard/app.py and bypass cache reuse on resolver diagnostics, preserving the existing TTL and cached response marker.

**Checkpoint**: The synchronous HTTP contract is independently testable. The Ask console’s derived answer uses the SSE route and reaches full story acceptance after User Story 3.

---

## Phase 5: User Story 3 — Streaming Search Exposes the Same Reasoning (Priority: P1)

**Goal**: SSE emits a reason stage with both counts before the final answer, and the Ask console exposes those counts and inferred facts.

**Independent Test**: With the enabled flag, POST /api/search/stream emits a reason stage followed by an answer whose inferred facts match the synchronous result; GET /ask remains gated and its trace presentation includes both counts.

### Tests for User Story 3

- [X] T013 [US3] Add failing SSE and Ask-console cases in tests/test_search_rule_wiring.py for status 200, reason-stage rules_loaded and derived counts, stage-before-answer order, nonempty final inferred parity with POST /api/search, visible trace-count labels, and disabled-gate 404.

### Implementation for User Story 3

- [X] T014 [US3] Resolve the rule snapshot in the POST /api/search/stream worker in wizard/app.py and pass rules=, diagnostics, and on_event to search(); preserve event: stage, event: answer, event: error, and the existing feature gate.
- [X] T015 [P] [US3] Show rules_loaded alongside derived in the existing Ask console trace presentation in wizard/templates/ask.html without changing its streaming request or answer flow.

**Checkpoint**: Streaming and Ask-console reasoning are complete, and User Story 2’s Ask-console scenario can be checked end to end.

---

## Phase 6: User Story 4 — Search-Backed Graph Queries Include Authorized Inferences (Priority: P2)

**Goal**: Fresh-search SPARQL can query rule-derived triples while supplied-triples queries remain unchanged.

**Independent Test**: With the enabled flag and a rule-dependent question, POST /api/sparql without supplied triples returns a derived triple; supplied-triples behavior and disabled-gate 404 remain as before.

### Tests for User Story 4

- [X] T016 [P] [US4] Add failing fresh-search SPARQL cases in tests/test_search_rule_wiring.py for a derived rdf:type triple, preservation of the supplied-triples branch, and the disabled-gate response; include a lower-tier case with no restricted or unmapped neighbor data.

### Implementation for User Story 4

- [X] T017 [US4] Resolve and pass rules= plus diagnostics only in the fresh-search branch of POST /api/sparql in wizard/app.py, retaining materialize=True, the supplied-triples branch, SPARQL result format, tier ceiling, and current feature gate.

**Checkpoint**: All four user stories have focused, independently described acceptance paths.

---

## Phase 7: Polish & Cross-Cutting Validation

**Purpose**: Run the requested security gate by name, adjacent regressions, and measurable acceptance checks.

- [X] T018 Run python -m pytest -q tests/test_fk_neighbor_tier_gating.py by name after code changes, require all six cases to pass, and record the command/result in quickstart.md validation notes; never replace the fail-closed neighbor projection with SELECT *.
- [X] T019 Run the focused and adjacent suites named in quickstart.md, including tests/test_search_rule_sources.py, tests/test_search_rule_wiring.py, tests/test_reasoning_search_phase2.py, tests/test_reasoning_search_phase4.py, tests/test_search_api.py, and tests/test_benchmark_rule_compiler.py; record failures and fixes in quickstart.md.
- [X] T020 Measure at least 20 controlled searches with at most 100 direct records and one rule against the SC-006 95%-within-10-seconds target, and record conditions and results in quickstart.md.
- [X] T021 Record the five-participant derived-fact comprehension criterion from spec.md in quickstart.md if a user acceptance exercise is available; otherwise explicitly report SC-007 as unverified without claiming completion.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)** → **Foundational (Phase 2)** → each user story.
- **US1** is the first MVP after Foundation.
- **US2 synchronous search** and **US4 graph query** need Foundation; their edits to wizard/app.py should be serialized in this shared workspace.
- **US3** needs the synchronous result from US2 for parity, although the SSE route can be wired from Foundation alone.
- **US2 Ask-console acceptance** completes after US3 because the existing console sends searches through SSE.
- **Polish** follows all desired story phases.

### User Story Dependencies

| Story | Required before starting | Independent completion signal |
|---|---|---|
| US1 CLI | Foundation | Default and explicit rules infer; --no-rules preserves direct result |
| US2 synchronous HTTP | Foundation | Enabled 200 with nonempty inferred; cache reflects current rules |
| US3 SSE and Ask | Foundation; US2 for parity comparison | Reason stage precedes answer; final inferred matches sync |
| US4 fresh SPARQL | Foundation | Derived triple queryable; supplied triples unchanged |

### Within Each Story

- Write the story’s failing focused tests before its implementation task.
- Apply model/snapshot constraints before wiring routes.
- Preserve feature gate and tier behavior while adding rule inputs.
- Run the story’s focused cases before moving to the next shared-file edit.

### Parallel Opportunities

- T002 and T003 can be drafted in parallel because they affect different test files.
- After their respective tests exist, T004 and T005 can proceed in parallel in different runtime files.
- T008 CLI work can overlap T009 synchronous HTTP test drafting after T007 has finished editing the shared test file.
- T014 SSE route work and T015 Ask trace presentation can proceed in parallel after T013 defines the expected stage.
- T016 SPARQL test drafting can overlap T015 Ask template work after T013 finishes editing the shared test file.
- Edits to wizard/app.py and edits to tests/test_search_rule_wiring.py are serialized within each file.

## Parallel Examples by User Story

- **US1**: After T007, work on T008 in runtime/reasoning_search/cli.py while US2 starts T009 in tests/test_search_rule_wiring.py.
- **US2**: After T010, work on T011/T012 in wizard/app.py while US3 prepares T013 in tests/test_search_rule_wiring.py.
- **US3**: After T013, work on T014 in wizard/app.py and T015 in wizard/templates/ask.html concurrently.
- **US4**: After T007, draft T016 in tests/test_search_rule_wiring.py while US1 implements T008 in runtime/reasoning_search/cli.py; T017 follows T016 and does not overlap other wizard/app.py edits.

## Implementation Strategy

### MVP First (User Story 1)

1. Complete T001–T006 to establish safe rule selection and reasoning.
2. Complete T007–T008 for default CLI rules and explicit opt-out.
3. Run the US1 focused cases and the named FK regression locally. No external deployment is part of this benchmark.

### Incremental Delivery

1. Add US2 synchronous HTTP with explicit enabled-flag and nonempty-inferred assertions.
2. Add US3 SSE and Ask console, then compare streamed and synchronous inferred facts.
3. Add US4 fresh-SPARQL rule wiring.
4. Run T018–T021 and report any unmet or unverified acceptance criterion.

## Notes

- [P] tasks have no unfinished dependency on another task touching the same file.
- The current Wizard session stores SHACL/SPARQL/OWL rules; it is not a Datalog source. ONTM-2 compiled rules satisfy the prerequisite now.
- The custom code-quality checklist is reviewer-owned; implementation work must not mark its checkboxes.
- Work only in the disposable repository copy and designated planning directory. Do not contact Jira, push, open a pull request, or change external services.

## Phase 8: Convergence

- [ ] T022 Remove the `SELECT *` fallback when `compile_sql()` has no mapped, tier-readable primary columns; fail closed or use a projection that cannot expose physical data, and add lower-tier tests covering direct results, inferred facts, materialized graph, and SSE in runtime/reasoning_search/query_compiler.py and tests/test_search_rule_wiring.py per FR-008 and FR-007 (contradicts).
- [ ] T023 Validate complete Datalog argument lists in runtime/reasoning_search/rule_sources.py and the parser path used by search, rejecting malformed stored rules such as `Derived(?x) :- Base(?x,,)` with a non-sensitive trace diagnostic while valid rules still derive; add resolver and surface tests in tests/test_search_rule_sources.py and tests/test_search_rule_wiring.py per FR-010 (partial).
- [ ] T024 Keep `rules_loaded` and `derived` visible in the Ask console trace after the final answer replaces live progress; update wizard/templates/ask.html and add a completed-stream rendering check in tests/test_search_rule_wiring.py per US3/AC1 and plan: integration step 5 (partial).
- [ ] T025 Include facts and mapped property aliases from every authorized FK neighbor when different tables share a reference key; update runtime/reasoning_search/engine.py and add a two-table same-key auto_relations test in tests/test_reasoning_search_phase4.py per T005 and plan: integration step 4 (partial).
