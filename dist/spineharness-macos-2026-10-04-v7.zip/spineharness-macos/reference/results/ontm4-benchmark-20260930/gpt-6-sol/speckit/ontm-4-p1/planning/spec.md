# Feature Specification: Reasoning Rules on Search Surfaces

**Feature Branch**: N/A (detached HEAD; no branch hook)

**Created**: 2026-09-30

**Status**: Draft

**Input**: User description: "Wire available reasoning rules into ontoforge search and every HTTP search flow, including streaming, while preserving access controls."

## Clarifications

### Session 2026-09-30

- Q: When compiled and stored rules are both available for a search, which rules should the search use? → A: Combine both sources and remove identical rules.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Command line search derives answers (Priority: P1)

A user asks ontoforge search a question whose answer depends on an available rule. The search uses rules by default and shows the resulting derived fact in its full result. The user can explicitly enable rules or use --no-rules to get the current search behavior.

**Why this priority**: The command line is a primary search surface, and a rule-dependent question must actually be reasoned over to earn the product name.

**Independent Test**: With a small connected dataset and one applicable rule, run the same question through the command line with default settings, --rules, and --no-rules, requesting the full structured answer each time; inspect inferred in each answer.

**Acceptance Scenarios**:

1. **Given** an available rule and facts that satisfy it, **when** the user searches with default settings or --rules, **then** the full structured answer has a non-empty inferred collection with rule provenance.
2. **Given** the same data and question, **when** the user searches with --no-rules, **then** no derived fact is added and the existing direct search result remains available.
3. **Given** no applicable rule, **when** the user searches with rules enabled, **then** the search still returns the direct result and reports zero derived facts.
4. **Given** one invalid rule and one usable rule, **when** the user searches with rules enabled, **then** the usable rule can still derive facts and the trace reports the invalid rule.

---

### User Story 2 - Enabled HTTP search returns inferred facts (Priority: P1)

A user of the enabled Ask console or POST /api/search asks a rule-dependent question and receives the same derived facts in the search answer.

**Why this priority**: Users of the product's HTTP surface must receive the reasoning already available to the underlying search capability.

**Independent Test**: Explicitly enable the search feature in the test environment, submit a rule-dependent question to POST /api/search, and verify a successful response containing a non-empty inferred collection. Also verify the Ask console can submit the question through the enabled search flow.

**Acceptance Scenarios**:

1. **Given** search is enabled and an applicable rule is available, **when** the user submits a rule-dependent question to POST /api/search, **then** the response has status 200 and includes at least one derived fact in inferred.
2. **Given** search is disabled, **when** the user requests the Ask console or any HTTP search endpoint, **then** that surface returns 404 with the existing "reasoning search is not enabled" error.
3. **Given** a search result with inferred facts, **when** a user opens it through the Ask console, **then** the console presents the answer produced by the enabled search flow.
4. **Given** an earlier cached answer and a change to the applicable rules, **when** the user repeats the question, **then** the result reflects the current rules.
5. **Given** rules for multiple flavors, **when** the user searches one flavor, **then** only rules eligible for that flavor or explicitly shared can derive facts.

---

### User Story 3 - Streaming search exposes the same reasoning (Priority: P1)

A user of POST /api/search/stream watches the search stages and receives the final answer with the derived facts from the same question.

**Why this priority**: Streaming is a separate route and must not lag behind the synchronous answer.

**Independent Test**: With search enabled and an applicable rule, read the complete event stream for a rule-dependent question and compare its final inferred collection with the synchronous result.

**Acceptance Scenarios**:

1. **Given** search is enabled and an applicable rule is available, **when** the user requests a stream, **then** a reasoning stage reports the loaded-rule count and derived-fact count before the final answer, and the final answer contains at least one derived fact.
2. **Given** the same question and data, **when** the user compares streamed and synchronous answers, **then** both contain the same derived facts.
3. **Given** search is disabled, **when** the user requests the stream, **then** it returns 404 with the existing "reasoning search is not enabled" error.

---

### User Story 4 - Search-backed graph queries include authorized inferences (Priority: P2)

A user asks the subgraph/SPARQL route to run a fresh search and can query derived facts in its resulting graph, subject to the existing access ceiling.

**Why this priority**: The graph route performs its own search; leaving it unwired would make reasoning differ across HTTP surfaces.

**Independent Test**: With search enabled, request a fresh search-backed graph query that targets a derived fact and verify it is returned without exposing restricted or unmapped data.

**Acceptance Scenarios**:

1. **Given** a rule-dependent question and an applicable rule, **when** the graph route performs a fresh search, **then** its queryable graph includes the authorized derived fact.
2. **Given** caller-supplied graph data, **when** the graph route runs a query over that data, **then** its existing behavior remains intact.
3. **Given** search is disabled, **when** the graph route is called, **then** it returns 404 with the existing "reasoning search is not enabled" error.

### Edge Cases

- If neither compiled nor stored rules are available, searches still return direct results and the reasoning stage reports zero loaded rules and zero derived facts.
- If a rule source is unavailable or a rule is malformed, the search reports that problem in its trace and continues with any usable rules; it retains the direct result if none remain.
- A search blocked by the existing access ceiling or unable to ground the question retains its current terminal behavior; it does not claim that reasoning ran.
- If rules are available but their conditions do not match the returned facts, the reasoning stage reports the loaded count and zero derived facts.
- Explicit --no-rules excludes rule-derived facts and reports zero loaded rules and zero derived facts.
- A missing data mapping prevents neighboring data from being followed. Neighboring data outside the permitted scope, above the selected access ceiling, or without an approved classification is withheld from results, inferences, graphs, and streams.
- Data masking that applies to direct results also applies to neighboring data used for reasoning.
- A rule that cannot be used must not create an inferred fact; the existing search error reporting remains available.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The command line and every HTTP route that performs a fresh search MUST use all available rules applicable to the selected flavor by default, whether they come from compiled rules, stored rules, or both. Rules shared across flavors remain eligible; rules exclusive to another flavor MUST be excluded. Identical rules from both sources MUST be used and counted only once.
- **FR-002**: The command line MUST offer --rules and --no-rules, with rules enabled by default and --no-rules restoring the current direct-search behavior.
- **FR-003**: A search with an applicable rule MUST expose each newly derived fact and its provenance in the full answer. The synchronous HTTP answer and streamed final answer MUST contain the same inferred facts for the same search.
- **FR-004**: Every search that reaches reasoning MUST include a reasoning trace stage stating the number of usable, applicable rules loaded after duplicate removal and the number of facts derived, including zero counts. The streaming route MUST send that stage as a progress event before its final answer.
- **FR-005**: Fresh searches initiated by the graph query route MUST include authorized derived facts in the queryable result.
- **FR-006**: The Ask console, synchronous search, graph query, and streaming search routes MUST retain their existing feature gate; when search is disabled, each MUST return its existing 404 response with the "reasoning search is not enabled" error.
- **FR-007**: Adding rules MUST preserve the existing access ceiling and the current behavior of automatic relationship discovery. Rules MUST use only facts allowed by those settings.
- **FR-008**: Neighboring records MUST be excluded when the data mapping is missing or the target lies outside the permitted scope. Only mapped, readable fields at or below the selected access ceiling may contribute to answers, inferences, graphs, and streams.
- **FR-009**: Data masking requirements MUST continue to apply to neighboring records before they can contribute to reasoning or graph results.
- **FR-010**: Searches with no usable rules or no matching rule MUST continue to return their direct-search result without fabricated inferences. A loading or rule-validation failure MUST be visible in the trace; other usable rules MUST still run.
- **FR-011**: A cached search answer MUST NOT be reused after the applicable rule set changes.

### Key Entities *(include if feature involves data)*

- **Available rule**: A compiled or stored rule that can be applied to facts in the current search; its identity provides provenance for any result it derives.
- **Search fact**: A permitted fact drawn from direct search results or from an authorized relationship, after access controls and masking.
- **Derived fact**: A new fact produced by an available rule, including its source rule and supporting facts.
- **Reasoning trace stage**: A progress record containing the count of loaded rules and the count of derived facts for one search.
- **Search answer**: The direct results, inferred facts, citations, trace, and optional queryable graph returned through a search surface.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: In the controlled rule-dependent acceptance case, 100% of default command line, explicitly enabled command line, synchronous HTTP, and streaming HTTP searches expose at least one derived fact.
- **SC-002**: For the same controlled question, 100% of streamed final answers have the same inferred facts as synchronous answers, and a progress event with both reasoning counts arrives before the final answer.
- **SC-003**: In the controlled opt-out case, --no-rules produces zero derived facts and preserves the direct answer in 100% of runs.
- **SC-004**: All four HTTP surfaces retain their existing unavailable response when the search feature is disabled; enabled synchronous HTTP acceptance checks receive status 200 with inferred facts.
- **SC-005**: All six existing foreign-key neighbor confidentiality regression cases pass when run as a named, isolated suite, and no restricted or unmapped neighboring field appears in a lower-tier answer, inference, graph, or stream.
- **SC-006**: On a fixed local acceptance fixture of at most 100 direct records and one rule, 95% of completed searches return a final answer within 10 seconds under the same test conditions used for the existing search baseline.
- **SC-007**: In user acceptance trials with the controlled rule-dependent question, at least five of five participants can identify the derived fact and see whether it came from a rule in the full result.
- **SC-008**: In 100% of controlled rule-change cases, a repeated search reflects the changed applicable rules even when the earlier answer was cached.

## Assumptions

- ONTM-2 compiled rules or ONTM-3 stored rules are available before this feature is implemented; either source can satisfy the dependency. This feature does not create a rule-authoring workflow.
- Rules are eligible when they apply to the selected flavor or are explicitly shared. Identical rules in both sources count once; differing rules from both sources remain available. The storage format and source integration are planning decisions.
- A failed rule load or invalid rule does not remove the direct search result. The failure is visible in the trace, and other usable rules continue to run.
- Searches terminated before reasoning by the existing access or grounding checks retain their current terminal responses.
- Rule changes make previously cached answers stale; the next search must reflect the currently applicable rules.
- The HTTP feature gate remains controlled by ONTOFORGE_SEARCH=1. HTTP acceptance fixtures explicitly set this value.
- Automatic relationship discovery remains at its current default and is not enabled solely because rules are available.
- The existing named regression suite is tests/test_fk_neighbor_tier_gating.py and must be run separately during implementation verification.
- This specification is for the disposable benchmark copy only; it does not authorize changes to Jira, external services, pushes, or pull requests.
