"""Rule snapshot selection is deterministic and accepts only Datalog."""

from runtime.reasoning_search import rule_sources


def test_compiled_rules_load_by_default(monkeypatch):
    monkeypatch.setattr(rule_sources, "compile_rules", lambda: ["Derived(?x) :- Base(?x)"])
    snapshot = rule_sources.resolve_rules("alpha")
    assert snapshot.rules == ("Derived(?x) :- Base(?x)",)
    assert snapshot.diagnostics == ()
    assert snapshot.revision == rule_sources.resolve_rules("alpha").revision


def test_scope_deduplication_and_stable_revision(monkeypatch):
    monkeypatch.setattr(rule_sources, "compile_rules", lambda: ["Derived(?x) :- Base(?x)"])

    def stored():
        return [
            rule_sources.StoredRule("Derived( ?x ) :- Base(?x)", scope="shared"),
            rule_sources.StoredRule("Local(?x) :- Base(?x)", scope="alpha"),
            rule_sources.StoredRule("Other(?x) :- Base(?x)", scope="beta"),
        ]

    first = rule_sources.resolve_rules("alpha", stored_source=stored)
    second = rule_sources.resolve_rules("alpha", stored_source=stored)
    assert len(first.rules) == 2
    assert first.revision == second.revision
    assert all("Other" not in r for r in first.rules)
    assert len(rule_sources.resolve_rules("beta", stored_source=stored).rules) == 2


def test_invalid_rule_and_failed_source_are_isolated(monkeypatch):
    monkeypatch.setattr(rule_sources, "compile_rules", lambda: [
        "Broken", "Derived(?x) :- Base(?x)"])

    def failed():
        raise RuntimeError("private source details")

    snapshot = rule_sources.resolve_rules("alpha", stored_source=failed)
    assert snapshot.rules == ("Derived(?x) :- Base(?x)",)
    assert len(snapshot.diagnostics) == 2
    assert "private source details" not in repr(snapshot.diagnostics)


def test_wizard_style_bodies_are_not_passed_as_datalog(monkeypatch):
    monkeypatch.setattr(rule_sources, "compile_rules", lambda: [])
    snapshot = rule_sources.resolve_rules("alpha", stored_source=lambda: [
        rule_sources.StoredRule("SELECT ?x WHERE { ?x a :Thing }"),
        rule_sources.StoredRule("<sh:NodeShape> a sh:NodeShape"),
    ])
    assert snapshot.rules == ()
    assert len(snapshot.diagnostics) == 2


def test_compiler_failure_leaves_usable_stored_rules(monkeypatch):
    def failed():
        raise FileNotFoundError("private ontology path")

    monkeypatch.setattr(rule_sources, "compile_rules", failed)
    snapshot = rule_sources.resolve_rules("alpha", stored_source=lambda: [
        rule_sources.StoredRule("Derived(?x) :- Base(?x)")])
    assert snapshot.rules == ("Derived(?x) :- Base(?x)",)
    assert len(snapshot.diagnostics) == 1
    assert "private ontology path" not in repr(snapshot.diagnostics)
