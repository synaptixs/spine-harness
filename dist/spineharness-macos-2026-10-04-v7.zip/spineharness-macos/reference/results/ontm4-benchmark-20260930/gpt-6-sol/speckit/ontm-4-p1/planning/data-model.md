# Data Model: Reasoning Rules on Search Surfaces

**Date**: 2026-09-30
**Scope**: runtime selection and search output. No new persistent table or migration is planned.

## Available rule

| Field | Meaning | Validation |
|---|---|---|
| `text` | Datalog rule string accepted by the existing parser | Must parse as a rule with a nonempty body |
| `source` | Compiled ontology or a future compatible stored source | Used for diagnostics, not exposed as a new public field |
| `scope` | Shared, or a named search flavor | A rule exclusive to another flavor is ineligible |
| `identity` | Canonical parsed head and body | Identical rules from multiple sources count once |
| `rule_name` | Head predicate used for provenance | Existing reasoner behavior |

The current ONTM-2 compiler supplies shared rules. Wizard session SHACL, SPARQL, and OWL bodies are not Datalog `Available rule` records; they need a separate conversion before they can enter this model.

## Rule snapshot

| Field | Meaning |
|---|---|
| `rules` | Deterministically ordered, eligible, valid, duplicate-free Datalog strings |
| `diagnostics` | Source-load and per-rule validation failures, without sensitive database values |
| `revision` | Stable fingerprint of the effective rule set |
| `flavor` | Search flavor used for eligibility filtering |

**Lifecycle**: source discovery → parse/validate → flavor eligibility → duplicate removal → immutable snapshot. A source failure yields a diagnostic and does not erase rules from another usable source. An empty snapshot is valid. A synchronous cached answer is reusable only with the same revision and no unresolved source diagnostic; a change to applicable rules forces a fresh search.

## Search fact

A fact is an ephemeral tuple `(predicate, subject_key[, value...])` supplied to the existing reasoner. It comes from an already returned primary row, an authorized neighbor when existing `auto_relations` allows it, or an existing explicitly supplied fact. The primary row contributes its ontology class predicate. A mapped, tier-readable column may contribute both its current physical-column predicate and its ontology-property alias so compiled rules can match. No alias may be created for an unmapped or above-tier column, and no additional database read is introduced for aliasing.

The FK neighbor path remains fail-closed: no mapping means no neighbor fact; out-of-flavor tables and unreadable columns contribute none. Existing masking applies before facts are created.

## Derived fact

| Public field | Meaning |
|---|---|
| `fact` | Newly inferred tuple serialized as an array |
| `rule` | Rule name credited by the reasoner |
| `derived_from` | Supporting fact tuples serialized as arrays |

A derived fact is new relative to the base fact set. The existing `ReasonedAnswer.inferred` collection holds these records, and inferred citations remain attached. With `materialize=True`, the existing subgraph builder includes derived facts as triples.

## Reasoning trace entry

The `reason` stage has `rules_loaded` (count of valid, eligible, deduplicated rules) and `derived` (count of newly inferred facts). A non-sensitive `errors` collection may describe skipped sources or rules. The stage is emitted once for every search that reaches reasoning, including zero-rule and `--no-rules` searches. Searches stopped earlier as blocked or ungrounded retain their existing terminal traces. The same entry appears in `ReasonedAnswer.trace` and, for SSE, an `event: stage` frame before `event: answer`.

## Existing answer and cache

`ReasonedAnswer` remains the public answer object; no new required top-level fields are planned. The synchronous HTTP cache retains its current TTL and request dimensions, with the rule snapshot revision added to cache identity. If rule resolution reports an error, bypass cache reuse so the trace can report the current failure.
