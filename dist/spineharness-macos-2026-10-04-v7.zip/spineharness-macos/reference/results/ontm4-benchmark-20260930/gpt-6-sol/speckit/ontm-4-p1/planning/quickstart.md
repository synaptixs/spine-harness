# Quickstart: Validate Rule-Enabled Search

**Purpose**: Run focused, offline checks after implementing [plan.md](plan.md). The new test module named below is planned by this design and does not exist yet.

## Prerequisites

- Run from the repository root with Python 3.10+ and the existing `pytest`, `rdflib`, and Flask test dependencies available.
- Keep tests local. Use a temporary SQLite database, flavor JSON, mapping CSV, deterministic search adapter, and local ontology rules. No live model or external service is needed.
- New HTTP integration fixtures must set `ONTOFORGE_SEARCH=1` before importing the app. A disabled-gate fixture must use a separate import state.

## 1. Confirm the rule source and existing security baseline

```sh
python -m pytest -q tests/test_benchmark_rule_compiler.py
python -m pytest -q tests/test_fk_neighbor_tier_gating.py
```

The second command must be run by name, separately from any larger suite. It has six cases covering tier limits, unmapped columns, flavor allow-list, missing mapping, and masking. A pre-implementation read-only baseline run passed 6/6; run it again after implementation.

## 2. Run the new end-to-end surface checks

```sh
ONTOFORGE_SEARCH=1 python -m pytest -q tests/test_search_rule_wiring.py
```

The planned module should exercise these scenarios using the real rule resolver and engine:

1. CLI default and `--rules` produce a full answer with nonempty `inferred`; `--no-rules` leaves `inferred` empty and retains direct results.
2. POST `/api/search` returns status 200 and nonempty `inferred` for a rule-dependent question. A 404 is a failure for this enabled case.
3. POST `/api/search/stream` emits `event: stage` with `rules_loaded` and `derived` before `event: answer`, whose inferred facts match the synchronous answer.
4. Fresh-search POST `/api/sparql` can query a derived triple. The supplied-`triples` branch retains existing behavior.
5. Changing applicable rules invalidates a cached answer. Identical rules from two compatible sources count once; a rule exclusive to another flavor is not used.
6. An invalid rule is reported while another usable rule still derives a fact. An absent source yields a zero-rule reason stage and a direct answer.
7. A property-based compiled rule can fire from a mapped, readable column; an unmapped or above-tier neighbor property cannot create an inference.

A minimal deterministic derivation is `DomainEntity(?x) :- ObservationRecord(?x)`, which can infer `["DomainEntity","1"]` from an authorized `ObservationRecord` row. Include a property-predicate case, such as `hasEventType` mapped from `event_type`, to prove the ontology/physical-name bridge.

## 3. Run adjacent regressions

```sh
python -m pytest -q tests/test_reasoning_search_phase1.py tests/test_reasoning_search_phase2.py tests/test_reasoning_search_phase4.py tests/test_search_api.py
python -m pytest -q tests/test_fk_neighbor_tier_gating.py
```

The repeated named security run is intentional after broader checks. Confirm the default relationship behavior and tier ceiling remain unchanged. The exact request and response fields are in [contracts/search-surfaces.md](contracts/search-surfaces.md).

## 4. Review outcomes

Inspect a representative full answer for a nonempty `inferred` record, rule provenance, a reason trace with both counts, and an inferred citation. In the Ask console, confirm the visible trace shows the loaded-rule and derived-fact counts. For the fixed fixture of at most 100 direct records and one rule, measure at least 20 completed local runs and confirm at least 95% finish within 10 seconds under the same conditions as the pre-change baseline. The five-person comprehension criterion in the spec requires a separate user acceptance exercise.

Record any failed command or unmet criterion. Do not treat a passing stubbed API response or an aggregate suite total as proof of end-to-end derivation.

## Implementation validation (2026-09-30)

- `python -m pytest -q tests/test_search_rule_sources.py tests/test_search_rule_wiring.py tests/test_reasoning_search_phase1.py tests/test_reasoning_search_phase2.py tests/test_reasoning_search_phase4.py tests/test_search_api.py tests/test_benchmark_rule_compiler.py`: 61 passed, 1 third-party deprecation warning. The first combined run failed five legacy disabled-gate cases because the new enabled fixture left the module flag on; fixture teardown was corrected, then the command passed.
- `python -m pytest -q tests/test_fk_neighbor_tier_gating.py`: 6 passed in an isolated, named run after the code changes; repeated after adjacent regressions, also 6 passed.
- `git diff --check` and Python compilation of the changed runtime, route, and new test modules passed.
- The end-to-end fixture has two direct `DomainEvent` records, a mapped `hasEventType` property, and one incident. CLI default and `--rules`, enabled synchronous HTTP, and SSE derive `IncidentEvent/1`; `--no-rules` preserves direct rows with zero inferred facts. Fresh SPARQL queries the derived type. Lower-tier graph and stream checks exclude mapped confidential and unmapped neighboring values.
- SC-006 timing: 20 direct engine searches with zero rules and 20 with one `IncidentEvent` rule, using the same local temporary SQLite fixture, fixed adapter, two direct rows, `max_replans=0`, and no external calls. Baseline: 20/20 within 10 seconds, max 0.402 ms, mean 0.194 ms. One rule: 20/20 within 10 seconds, max 0.312 ms, mean 0.206 ms. This satisfies the local 95% target under these controlled conditions; it is not a production load result.
- SC-007 remains **unverified**. No five-participant user acceptance exercise was supplied or conducted; the implementation and automated tests cannot establish comprehension.
