"""Offline end-to-end checks for CLI, HTTP, SSE, and fresh SPARQL reasoning."""

from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
for location in (ROOT, ROOT / "wizard", ROOT / "src"):
    if str(location) not in sys.path:
        sys.path.insert(0, str(location))


class FixedAdapter:
    model_id = "fixed"

    def complete(self, payload):
        if "synth" in payload["payload_id"]:
            return "The incident is derived from the event type."
        return '{"intent":"find incidents","classes":["DomainEvent"],"filters":[]}'


@pytest.fixture()
def search_fixture(tmp_path, monkeypatch):
    import runtime.reasoning_search.engine as engine

    db = tmp_path / "search.db"
    with sqlite3.connect(db) as con:
        con.executescript(
            "CREATE TABLE agents (id INTEGER PRIMARY KEY, name TEXT, "
            "credential_expiry TEXT, secret_note TEXT);"
            "CREATE TABLE events (id INTEGER PRIMARY KEY, event_type TEXT, "
            "secret_note TEXT, confidential_code TEXT, "
            "agent_id INTEGER REFERENCES agents(id));"
            "INSERT INTO agents VALUES (1, 'NOC', '2027-01-01', 'hidden agent note');"
            "INSERT INTO events VALUES (1, 'INCIDENT', 'hidden', 'classified', 1);"
            "INSERT INTO events VALUES (2, 'OTHER', 'hidden too', 'classified too', 1);"
        )
    flavors = tmp_path / "flavors"
    flavors.mkdir()
    (flavors / "f.json").write_text(json.dumps({
        "name": "f", "owl_classes": ["DomainEvent"],
        "context_terms": {"DomainEvent": "event", "hasEventType": "type"},
        "db_tables": ["events", "agents"]}), encoding="utf-8")
    mapping = tmp_path / "mapping.csv"
    mapping.write_text(
        "ontology_class,ontology_property,property_type,logical_element,physical_table,"
        "physical_column,xsd_type,required,sensitivity_tier,semantic_notes,cq_coverage\n"
        "DomainEvent,(class),OWL Class,event,events,(table),,Y,Internal,,\n"
        "DomainEvent,id,Data Property,event.id,events,id,xsd:integer,N,Internal,,\n"
        "DomainEvent,hasEventType,Data Property,event.type,events,event_type,xsd:string,N,Internal,,\n"
        "DomainEvent,agent_id,Data Property,event.agent,events,agent_id,xsd:integer,N,Internal,,\n"
        "DomainEvent,hasConfidentialCode,Data Property,event.code,events,confidential_code,xsd:string,N,Confidential,,\n"
        "Agent,(class),OWL Class,agent,agents,(table),,Y,Internal,,\n"
        "Agent,id,Data Property,agent.id,agents,id,xsd:integer,N,Internal,,\n"
        "Agent,hasName,Data Property,agent.name,agents,name,xsd:string,N,Internal,,\n"
        "Agent,hasCredentialExpiry,Data Property,agent.expiry,agents,credential_expiry,xsd:string,N,Confidential,,\n",
        encoding="utf-8")
    monkeypatch.setattr(engine, "_DEFAULT_FLAVORS", str(flavors))
    monkeypatch.setattr(engine, "_DEFAULT_MAPPING", str(mapping))
    monkeypatch.setattr(engine, "_resolve_adapter", lambda providers: FixedAdapter())
    return str(db)


@pytest.fixture()
def enabled_client(search_fixture, monkeypatch):
    pytest.importorskip("flask")
    monkeypatch.setenv("ONTOFORGE_SEARCH", "1")
    import app as app_module

    app_module.ONTOFORGE_SEARCH = True
    monkeypatch.setattr(app_module, "SEARCH_DB", search_fixture)
    monkeypatch.setattr(app_module, "_build_memory", lambda: None)
    app_module._SEARCH_CACHE.clear()
    app_module.app.config["TESTING"] = True
    with app_module.app.test_client() as client:
        yield client
    app_module._SEARCH_CACHE.clear()
    app_module.ONTOFORGE_SEARCH = False


@pytest.fixture()
def disabled_client(monkeypatch):
    pytest.importorskip("flask")
    monkeypatch.delenv("ONTOFORGE_SEARCH", raising=False)
    import app as app_module

    app_module.ONTOFORGE_SEARCH = False
    app_module.app.config["TESTING"] = True
    with app_module.app.test_client() as client:
        yield client
    app_module.ONTOFORGE_SEARCH = False


def _payload():
    return {"question": "which events are incidents?", "flavor": "f"}


def _facts(answer):
    return {tuple(item["fact"]) for item in answer["inferred"]}


def test_cli_default_explicit_and_opt_out(search_fixture, capsys):
    from runtime.reasoning_search.cli import run

    base = [_payload()["question"], "--flavor", "f", "--db", search_fixture, "--json"]
    assert run(base) == 0
    default = json.loads(capsys.readouterr().out)
    assert ("IncidentEvent", "1") in _facts(default)
    assert ("IncidentEvent", "2") not in _facts(default)
    assert any(c["inferred"] for c in default["citations"])
    assert default["results"] and default["status"] == "ok"
    assert run(base + ["--rules"]) == 0
    explicit = json.loads(capsys.readouterr().out)
    assert _facts(default) == _facts(explicit)
    assert run(base + ["--no-rules"]) == 0
    opted_out = json.loads(capsys.readouterr().out)
    assert opted_out["inferred"] == []
    assert opted_out["results"] == default["results"]
    assert opted_out["status"] == default["status"]
    assert next(t for t in opted_out["trace"] if t["stage"] == "reason")["rules_loaded"] == 0


def test_enabled_http_derives_a_real_fact(enabled_client):
    response = enabled_client.post("/api/search", json=_payload())
    assert response.status_code == 200
    answer = response.get_json()
    assert ("IncidentEvent", "1") in _facts(answer)
    assert answer["inferred"]
    stage = next(t for t in answer["trace"] if t["stage"] == "reason")
    assert stage["rules_loaded"] > 0 and stage["derived"] > 0
    assert all("secret_note" not in row and "confidential_code" not in row
               for row in answer["results"])


def test_all_routes_still_use_feature_gate(disabled_client):
    requests = [
        disabled_client.get("/ask"),
        disabled_client.post("/api/search", json=_payload()),
        disabled_client.post("/api/search/stream", json=_payload()),
        disabled_client.post("/api/sparql", json={"query": "SELECT ?s WHERE { ?s rdf:type IncidentEvent }", **_payload()}),
    ]
    for response in requests:
        assert response.status_code == 404
        assert response.get_json() == {"error": "reasoning search is not enabled"}


def test_cache_tracks_rule_revision_and_resolution_errors(enabled_client, monkeypatch):
    import app as app_module
    from runtime.reasoning_search import rule_sources

    monkeypatch.setattr(app_module, "SEARCH_CACHE_TTL", 60.0)
    first = enabled_client.post("/api/search", json=_payload())
    second = enabled_client.post("/api/search", json=_payload())
    assert first.status_code == second.status_code == 200
    assert second.get_json()["cached"] is True

    monkeypatch.setattr(rule_sources, "compile_rules", lambda: [
        "Alternate(?x) :- DomainEvent(?x)"])
    changed = enabled_client.post("/api/search", json=_payload())
    assert changed.status_code == 200
    assert "cached" not in changed.get_json()
    assert ("Alternate", "1") in _facts(changed.get_json())
    assert ("IncidentEvent", "1") not in _facts(changed.get_json())

    def unavailable():
        raise RuntimeError("private path")

    monkeypatch.setattr(rule_sources, "compile_rules", unavailable)
    failed = enabled_client.post("/api/search", json=_payload())
    again = enabled_client.post("/api/search", json=_payload())
    assert failed.status_code == again.status_code == 200
    assert "cached" not in again.get_json()
    assert failed.get_json()["inferred"] == []
    assert next(t for t in failed.get_json()["trace"] if t["stage"] == "reason")["errors"]


def test_sse_emits_reason_stage_before_matching_answer(enabled_client):
    expected = enabled_client.post("/api/search", json=_payload())
    response = enabled_client.post("/api/search/stream", json=_payload())
    assert expected.status_code == response.status_code == 200
    frames = []
    for frame in response.get_data(as_text=True).strip().split("\n\n"):
        lines = frame.splitlines()
        frames.append((lines[0][7:], json.loads(lines[1][6:])))
    reason_index = next(i for i, (kind, data) in enumerate(frames)
                        if kind == "stage" and data.get("stage") == "reason")
    answer_index = next(i for i, (kind, _) in enumerate(frames) if kind == "answer")
    assert reason_index < answer_index
    stage = frames[reason_index][1]
    assert stage["rules_loaded"] > 0 and stage["derived"] > 0
    assert _facts(frames[answer_index][1]) == _facts(expected.get_json())


def test_streamed_graph_excludes_restricted_and_unmapped_neighbors(enabled_client):
    response = enabled_client.post("/api/search/stream", json={
        **_payload(), "max_tier": "Internal", "materialize": True})
    assert response.status_code == 200
    body = response.get_data(as_text=True)
    assert "event: answer" in body
    assert "2027-01-01" not in body
    assert "hidden agent note" not in body
    assert "credential_expiry" not in body


def test_ask_console_shows_both_reason_counts(enabled_client):
    response = enabled_client.get("/ask")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "s.rules_loaded" in html and "s.derived" in html
    assert "'/api/search/stream'" in html


def test_fresh_sparql_contains_derived_type_and_supplied_branch(enabled_client):
    query = "SELECT ?s WHERE { ?s rdf:type IncidentEvent }"
    response = enabled_client.post("/api/sparql", json={"query": query, **_payload()})
    assert response.status_code == 200
    assert response.get_json()["rows"] == [{"?s": "DomainEvent/1"}]
    supplied = enabled_client.post("/api/sparql", json={
        "query": query, "triples": [["Supplied/9", "rdf:type", "IncidentEvent", True]]})
    assert supplied.status_code == 200
    assert supplied.get_json()["rows"] == [{"?s": "Supplied/9"}]
    restricted = enabled_client.post("/api/sparql", json={
        "query": 'SELECT ?s WHERE { ?s hasConfidentialCode "classified" }',
        **_payload(), "max_tier": "Internal"})
    assert restricted.status_code == 200
    assert restricted.get_json()["rows"] == []
    neighbor = enabled_client.post("/api/sparql", json={
        "query": 'SELECT ?s WHERE { ?s name "NOC" }', **_payload(),
        "max_tier": "Internal"})
    assert neighbor.status_code == 200
    assert neighbor.get_json()["rows"] == [{"?s": "agents/1"}]
    for column, value in (("credential_expiry", "2027-01-01"),
                          ("secret_note", "hidden agent note")):
        withheld = enabled_client.post("/api/sparql", json={
            "query": f'SELECT ?s WHERE {{ ?s {column} "{value}" }}',
            **_payload(), "max_tier": "Internal"})
        assert withheld.status_code == 200
        assert withheld.get_json()["rows"] == []
