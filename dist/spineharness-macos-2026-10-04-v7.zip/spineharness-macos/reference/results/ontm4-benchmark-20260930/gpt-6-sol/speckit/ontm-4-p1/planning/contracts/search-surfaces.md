# Search Surface Contract

**Date**: 2026-09-30
**Status**: Planned extension to existing interfaces. See [data-model.md](../data-model.md) for rule and fact definitions.

## Command line

`ontoforge search QUESTION --flavor FLAVOR [--rules | --no-rules] [--json]`

| Input | Contract |
|---|---|
| No rules option | Load eligible rules by default |
| `--rules` | Explicitly use the same default rule loading |
| `--no-rules` | Pass no rules; direct search remains available |
| `--json` | Serialize the existing full `ReasonedAnswer`, including `inferred` and `trace` |

The existing `--db`, `--provider`, `--max-tier`, `--k`, exit status, and text answer behavior remain. The text response may continue to identify inferred citations; the structured result is the acceptance surface for exact inferred facts.

## HTTP feature gate

The existing `ONTOFORGE_SEARCH=1` gate applies to GET `/ask`, POST `/api/search`, POST `/api/sparql`, and POST `/api/search/stream`. When disabled, each returns status 404 and JSON `{"error":"reasoning search is not enabled"}`. Test fixtures must set the flag before evaluating enabled behavior.

## POST /api/search

Existing request fields remain: `question` and `flavor` required; `db`, `provider`, `max_tier`, `k`, and `materialize` optional. Rules are enabled by default; this feature adds no HTTP rules toggle.

A successful request returns status 200 with the existing `ReasonedAnswer` JSON shape. In a controlled rule-dependent case:

```json
{
  "inferred": [
    {
      "fact": ["DomainEntity", "1"],
      "rule": "DomainEntity",
      "derived_from": [["ObservationRecord", "1"]]
    }
  ],
  "trace": [
    {"stage": "reason", "rules_loaded": 1, "derived": 1}
  ]
}
```

Other answer fields remain present as today. The example shows the changed fields only. If no rules are available or none fire, `inferred` is empty and the reason stage reports zero derived facts. A failed rule source or invalid rule is reported in the reason stage while usable rules continue. Existing invalid-request and search-failure status codes remain. A cached response may include the existing `cached: true` marker, but it must not be served after applicable rules change.

## POST /api/search/stream

Request fields and gate match synchronous search. The response remains `text/event-stream`. The engine emits a reason stage through the existing progress callback, followed by one final answer event:

```text
event: stage
data: {"stage":"reason","rules_loaded":1,"derived":1}

event: answer
data: {"inferred":[{"fact":["DomainEntity","1"],"rule":"DomainEntity","derived_from":[["ObservationRecord","1"]]}],"...":"existing answer fields"}
```

The final `answer` event contains the same inferred facts that synchronous search would return for the same data and rule snapshot. Existing `event: error` behavior remains for request execution errors. The Ask console consumes this stream and renders inferred facts.

## POST /api/sparql

With caller-supplied `triples`, behavior remains unchanged. When `triples` is omitted, the route requires `question` and `flavor`, performs a fresh materialized search with default rules, then executes the supplied read-only `query` over that graph. Authorized derived facts become queryable there. The route retains its existing SPARQL result format and status codes; it does not return a `ReasonedAnswer` body.

## Safety and ordering

Rule loading does not enable `auto_relations` or broaden the selected tier. Only already authorized, mapped, readable, masked facts may support an inference. The reason stage follows execution and precedes synthesis/final answer for searches that reach reasoning. Blocked and ungrounded searches retain their existing terminal behavior.
