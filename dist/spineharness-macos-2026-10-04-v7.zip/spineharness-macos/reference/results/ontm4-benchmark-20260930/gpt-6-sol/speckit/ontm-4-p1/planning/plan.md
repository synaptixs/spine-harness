# Implementation Plan: Reasoning Rules on Search Surfaces

**Branch**: `ontm-4-p1` (setup context; checkout is detached) | **Date**: 2026-09-30 | **Spec**: [spec.md](spec.md)

**Input**: Clarified feature specification in [spec.md](spec.md)

## Summary

Make the CLI and every HTTP path that performs a search pass a shared, eligible rule snapshot into the existing search engine. Use the available ONTM-2 ontology compiler as the current Datalog source; combine a future compatible ONTM-3 source through the same resolver if present. Add mapped ontology-property facts so compiled property rules can fire without expanding database reads. Emit a reason stage with loaded-rule and derived-fact counts for synchronous and streaming results, and include the rule revision in the synchronous cache identity. Preserve the feature gate, `auto_relations` behavior, tier ceiling, and fail-closed FK neighbor projection.

## Technical Context

**Language/Version**: Python 3.10+; existing Ask console JavaScript for trace display

**Primary Dependencies**: Existing `rdflib` ontology compiler, Datalog parser/reasoner, Flask Wizard routes, Python standard library

**Storage**: Existing read-only SQLite search database, local ontology Turtle files, flavor JSON and mapping CSV; existing in-memory HTTP response cache. No new persistent schema.

**Testing**: `pytest` with temporary SQLite/flavor/mapping fixtures and a deterministic adapter; Flask test client for HTTP and SSE

**Target Platform**: Existing `ontoforge` CLI and Flask HTTP server

**Project Type**: Python CLI plus web service over a shared search engine

**Performance Goals**: At least 95% of controlled searches over at most 100 direct records and one rule complete within 10 seconds under the same local test conditions as the baseline; reason stage precedes the SSE answer event

**Constraints**: `ONTOFORGE_SEARCH=1` remains the HTTP gate; `--no-rules` preserves direct search; no automatic relationship expansion solely from rule availability; no unmapped or above-tier neighbor data in facts, answers, graphs, or streams; no external-service changes

**Scale/Scope**: One selected flavor and access ceiling per request; existing engine result limit defaults to 200 rows; CLI, synchronous search, SSE search, and fresh-search SPARQL are in scope. The Ask console consumes SSE. SDK behavior outside these surfaces is unchanged.

## Constitution Check

*GATE: evaluated before research and re-evaluated after Phase 1 design.*

| Constitution principle | Before research | After design | Evidence |
|---|---|---|---|
| Use existing conventions and types | Pass | Pass | Reuse `compile_rules()`, `search(rules=...)`, `ReasonedAnswer`, the trace callback, and current routes. |
| Preserve behavior outside this change | Pass | Pass | Keep gate, request shape, cache TTL, auto-relations setting, and FK neighbor projection; add only rule-aware cache identity. |
| Add focused tests | Pass | Pass | [quickstart.md](quickstart.md) names real-inference surface checks and the isolated six-case FK regression. |
| Work only in disposable copy and planning directory | Pass | Pass | Design changes target this repository copy and this feature directory. |
| No Jira, push, PR, or external-service changes | Pass | Pass | Validation is offline; no such action is part of the plan. |
| Report incomplete work and failed checks honestly | Pass | Pass | Baseline six-case regression is recorded separately; implementation and end-to-end correctness are not claimed. |

No constitution violation or unresolved design question remains. ONTM-2 is present and usable, satisfying the stated ONTM-2-or-ONTM-3 prerequisite.

## Project Structure

### Documentation (this feature)

```text
./
├── spec.md
├── plan.md
├── research.md
├── data-model.md
├── quickstart.md
├── contracts/
│   └── search-surfaces.md
└── checklists/
    └── requirements.md
```

`tasks.md` belongs to the later `$speckit-tasks` phase and is not created here.

### Source Code (repository root)

```text
runtime/reasoning_search/
├── cli.py                 # command options and search call
├── engine.py              # fact building, reason stage, answer
├── rule_compiler.py       # ONTM-2 local ontology -> Datalog rules
├── reasoner.py            # parser, forward chaining, provenance
├── _loaders.py            # flavor and tier-aware mapping
└── rule_sources.py        # planned shared rule resolver/snapshot

wizard/
├── app.py                 # gate, sync/cache, fresh-SPARQL, SSE calls
└── templates/ask.html     # visible trace counts

tests/
├── test_search_rule_wiring.py        # planned real-inference surface checks
├── test_search_api.py                # existing route contracts/cache tests
├── test_reasoning_search_phase2.py   # existing engine derivation tests
├── test_reasoning_search_phase4.py   # existing auto-relations tests
├── test_benchmark_rule_compiler.py   # existing compiler tests
└── test_fk_neighbor_tier_gating.py   # six-case isolated security gate
```

**Structure Decision**: Extend the existing search package and Wizard routes; add one focused rule-source module and one focused integration test module. No new service, database table, or deployment component is needed.

## Phase 0: Research Outcome

[research.md](research.md) resolves source compatibility, predicate naming, flavor eligibility, cache revision, trace/SSE behavior, and the security/test strategy. The checked-in ONTM-2 compiler yields Datalog strings; the current Wizard session stores SHACL/SPARQL/OWL bodies and is not a compatible runtime Datalog source. Those bodies will not be passed raw to `parse_rule`. A future ONTM-3-compatible source can implement the resolver boundary and combine its eligible rules with compiled rules.

## Phase 1: Design and Contracts

[data-model.md](data-model.md) defines available rules, rule snapshots, authorized facts, derived facts, reason trace entries, and cache identity. [contracts/search-surfaces.md](contracts/search-surfaces.md) defines CLI options, HTTP gate and JSON shape, SSE event ordering, and SPARQL fresh-search behavior. [quickstart.md](quickstart.md) gives offline, runnable validation scenarios for implementation.

### Integration sequence

1. Add a shared resolver that loads ONTM-2 compiled rules, validates each Datalog rule, applies scope, removes duplicates, records non-sensitive failures, and computes a stable revision. Treat compiled ontology rules as shared. Keep the adapter boundary ready for a genuinely compatible ONTM-3 store.
2. Add CLI `--rules` and `--no-rules`; resolve by default and pass `rules=` into `search`. The explicit opt-out supplies an empty rule set.
3. In `wizard/app.py`, resolve a snapshot separately for synchronous, SSE, and fresh-SPARQL searches. The Ask console continues through SSE. Include snapshot revision in the synchronous cache key; bypass reuse when resolution reports a current failure.
4. In the engine, keep existing physical-column facts and add ontology-property aliases only from returned mapped, readable columns. Leave `_fk_neighbors`, its allow-list and tier checks, masking, and `auto_relations` call conditions intact.
5. Parse rules independently so one invalid rule does not suppress other valid rules. Emit a single `reason` trace entry containing `rules_loaded` and `derived` after execution, including zero counts. Pass source diagnostics into that entry. Let the existing `on_event` hook emit the same stage in SSE. Show both counts in the Ask trace.
6. Add focused integration tests that exercise the real resolver and engine, including a property-predicate rule, and rerun the named FK confidentiality suite separately after implementation.

### Design limits and risks

- The present Wizard session's `industry` metadata is not a search flavor. SHACL/SPARQL/OWL Wizard rules require a separate, explicit conversion before they are eligible for Datalog search. This plan uses ONTM-2 now because the dependency allows either source.
- Compiled OWL property names differ from physical SQL column names. Passing rules without mapped aliases can produce an apparently successful search with empty `inferred`; the validation guide requires a property-based case.
- Rule loading must happen before synchronous cache lookup to prevent stale inferences, but errors should not expose source file contents or database values.
- Baseline `python -m pytest -q tests/test_fk_neighbor_tier_gating.py` passed 6/6 before implementation. It must pass again after code changes; the current pass does not establish feature correctness.
