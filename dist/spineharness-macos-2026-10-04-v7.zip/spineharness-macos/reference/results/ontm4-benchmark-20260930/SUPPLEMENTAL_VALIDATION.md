# Original supplemental ONTM-4 validation

**Follow-up:** the user subsequently authorized completing Spine’s default-rule integration. Its separately measured continuation now passes all seven reused checks. The original failure analysis below remains historical evidence; see [continuation validation](CONTINUATION_VALIDATION.md) for the current output and additional costs.

Verified after all measured sessions closed on 2026-10-04T11:41:57.878180+00:00.

“Completed October 4 attempt” identifies the fresh Spine run whose workflow finished. The earlier label “recovery” referred only to restarting after interruption. “3/7” means three of seven independent behavioral tests passed and four failed; it does not count completed stages or indicate percent implementation complete. See [artifact comparison](ARTIFACT_COMPARISON.md) for what was produced and what works.

## Frozen audit results

| Check | Baseline | spec-kit | Spine + PKG — completed October 4 attempt |
|---|---|---|---|
| test_positive_control_explicit_rules | passed | passed | passed |
| test_cli_loads_rules_by_default | failed | passed | failed |
| test_cli_no_rules_disables_derivation | failed | passed | passed |
| test_http_enabled_search_derives_facts | failed | passed | failed |
| test_sse_enabled_search_derives_same_facts | failed | passed | failed |
| test_fresh_sparql_search_receives_rules | failed | passed | failed |
| test_http_and_stream_remain_flag_gated | passed | passed | passed |

The frozen suite hash is `2c0fa95531f422dfab2d6d6c565a124de1db344e800e59660ad6ce3ee25cc783`, matching its pre-implementation protocol. Spec-kit: 7 passed. Spine: 3 passed, 4 failed. Both were tested in their disposable generated repositories with no network access and no real model calls. No audit output was fed back to either measured workflow, and no implementation was repaired.

## Failure adjudication

The four Spine failures are default CLI, enabled HTTP search, enabled SSE search, and fresh SPARQL search. Each reaches real search execution and returns an otherwise successful answer with empty inferred facts. HTTP/SSE/SPARQL return 200, and the SPARQL capture hook records its expected single call. The default fixture mapping and LLM substitutions therefore function; the failures do not arise from an internal injection incompatibility. The explicit-rule positive control passes, proving that the real reasoner derives the expected IncidentEvent and MaintenanceEvent facts when supplied the shared compiler output.

Source inspection explains the gap. `runtime/reasoning_search/_loaders.py:181` adds `load_rules()`, which searches `output/rules/compiled.json`, other guessed artifact filenames, optional ONTOFORGE_RULES/explicit paths, and stored session rules. Missing files mean an empty rule list. The generated checkout has no `output/rules` directory, and this loader never invokes the prepared `rule_compiler.compile_rules()` API. All three HTTP search routes and the CLI call this loader. The prepared compiler and source ontology are present and unchanged; the missing step is integrating the available default source. This establishes failure on the prepared baseline, not that the implementation can never work with an externally supplied compatible artifact.

Spine’s six generated tests pass after one refinement, but their fixture creates a custom compiled.json, sets ONTOFORGE_RULES, and monkeypatches both parsing and inference with stubs (`tests/test_search_rule_surfaces.py:65–100`). Those checks support plumbing and trace propagation for that synthetic setup. They do not establish real default rule compilation or derivation. The frozen audit substitutes only the language-model planner/synthesizer and fixture data locations; real SQL, parsing and inference remain active.

## Other validation and provenance

- Spine configured project checks: 6 named FK-neighbor checks and 49 selected regression checks passed (55 total). Its FK test file is byte-for-byte unchanged from the prepared baseline. The new six generated tests are a separate selection.
- Spec-kit configured project checks: 6 named FK-neighbor checks and 52 selected regression checks passed (58 total); its additions explain the differing regression count. The earlier independent review verified the FK test was unchanged and existing test assertions were not removed.
- Re-capturing the Spine disposable source after the audit reproduces its saved patch hash `ace6d5e73e76048ef8fdff081c434261efad51884f71e2adce71b5af3cfb84d6`. The shared compiler is unchanged.
- The native Spine console prints ACCEPTED and a generic preflight-tools label, but the project adapter disables independent fit grading and runs the configured pytest commands. The saved summary correctly sets accepted/fit/independent_accepted to null. Do not interpret the native console label as independent ticket acceptance.
- The original source repository fingerprint remains unchanged. The audit wrote only disposable temporary test output and result artifacts.

## Limits and interpretation

The frozen audit covers seven selected behaviors, not every Jira acceptance criterion or production/security requirement. It does not fully exercise all trace-count/rendering cases, malformed rule sources, auto-relations or mapping combinations. Spec-kit still has the qualified residual findings in INDEPENDENT_REVIEW.md. Its 7/7 result is not full acceptance certification.

Spine’s lower recorded token usage accompanies a demonstrated default-integration gap. This run therefore cannot establish equal-quality efficiency, statistical significance, broad financial infeasibility of spec-kit, or a causal advantage from PKG. One prepared issue remains one case study.

## Accounting

No additional benchmark model calls were made for this audit. Closed measured Codex/gpt-6-sol accounting across all available attempt records: 11,995,805 tokens (uncached input 669,284; output 123,065; cache write 0; cache read 11,203,456), $4.8099092 API list-price equivalent, not subscription charges. Four interrupted calls have unknown additional consumption. Supervision/review is excluded and the active supervisory turn is not yet closed; its cost is not represented as zero.
