# ONTM-4 benchmark preparation

**The shared prerequisite baseline is prepared. No benchmark has run.**

## Selected task and protocol

- Jira: ONTM-4 — Wire rules into the CLI and HTTP search surfaces.
- Repository: https://github.com/synaptixs/ontomesh
- Original commit: `f771c8c4ee32a28144f9b08d061d4172e4366ebb`.
- Prepared baseline: `82e12bb908cea139f92ed537dfd2967234976701`.
- Both workflows: spec-kit v1.0.11 and Spine v3.52.0 + PKG.
- Configured benchmark model: **gpt-6-sol**, reasoning effort **high**, through ChatGPT sign-in. These are configuration values; no benchmark response has yet been observed.
- Frozen requirements: `jira-ontm4-selected/scenarios.json`. Acceptance criteria remain verbatim in the Jira description. Both workflow catalog fingerprints match.
- Mode: token-only comparison. Existing regression checks do not prove completion of all ONTM-4 acceptance criteria. One issue cannot establish general statistical significance.

## Common prerequisite

ONTM-4 requires a source of rules from ONTM-2 or ONTM-3. A reference compiler was prepared in a separate disposable repository and committed locally. Only two files were added:

- `runtime/reasoning_search/rule_compiler.py`: deterministic named subclass rules, equivalent properties in both directions, and supported equivalent-class intersections with hasValue restrictions. Exposes `compile_rules()` and `compile_graph(graph)`; default input is the repository's enterprise.ttl + events.ttl. It performs no network imports.
- `tests/test_benchmark_rule_compiler.py`: prerequisite tests, supplied equally to both workflows.

The CLI, HTTP/SSE routes and engine were left at their original implementations. Connecting the compiler to search remains ONTM-4's measured task. Both arms will clone the same clean, independent, remote-free baseline. Preparation work is outside measured benchmark sessions and must not be attributed to either arm's token totals.

This is a bounded reference prerequisite, not a claim that Jira ONTM-2 has been completed. Unsupported OWL expressions are skipped as a whole; ambiguous predicate names fail. The existing Datalog parser's literal limitations are respected.

## Verification

- **55 tests passed** with network blocked and filesystem writes restricted to the disposable copy: six named FK-neighbor tier-gating checks, plus 49 compiler/search/API tests. One upstream logging deprecation warning was observed.
- **72 unique rules** compile and parse on the pinned ontology; applying all of them to **1,716 projected ABox facts** derives **201 facts**, including all four event classes with supporting-fact provenance.
- These are actual baseline measurements, not a reproduction of the ticket prototype's 74/65 counts. The input artifacts differ; the checked-in materialised.ttl contains no DomainEvent instances, so the prerequisite test uses instances.ttl. Exact inputs and hashes are in BASELINE_MANIFEST.json.
- Both workflow previews passed with identical task fingerprints and baseline commit. No model was invoked by the previews.
- Existing isolated harness login reports **Logged in using ChatGPT**. No credentials are included in these results.
- Original Ontomesh working files and Git metadata still match the pre-preparation fingerprint, including the existing requirements-db.txt edit. Jira was only read.

## Reproduction evidence

- `PREREQUISITE.patch`: exact two-file prerequisite delta against the original commit.
- `BASELINE_MANIFEST.json`: commit, input/file hashes, measured compiler output, event provenance and model configuration.
- `application-requirements.lock`: pinned packages installed in the dedicated application environment.
- `BASELINE_CHECKS.json` and `BASELINE_CHECKS.log`: offline check commands and outputs.
- `TARGET_CATALOG.json` and `SPINE_CATALOG.json`: matched scenario snapshots.
- `DRY_RUN.log`: both workflow previews.
- `PROJECT.json` and `benchmark.env`: active local configuration.

To reconstruct the prerequisite elsewhere, use a separate clone at the original commit, apply PREREQUISITE.patch after verifying its manifest hash, install the lockfile in a fresh Python 3.12 environment, and run the recorded tests. Record the resulting commit/tree in that environment's project configuration. Do not apply this patch to a production checkout as part of benchmark preparation.

## Execution state

`BENCHMARK_EXECUTE=0` remains set. The baseline and frozen requirements have been reviewed for token-only comparison. A requested measured run is the next stage; it will produce proposed-change Markdown/patches and token accounting in results, without writing to Jira or the original repository.

For a correctness-adjusted comparison, independent ONTM-4 acceptance judges are still needed. Existing tests cover regressions and the common compiler prerequisite. They do not establish that default CLI/API/SSE rule loading, opt-out behavior, and rule-count tracing have been implemented.
