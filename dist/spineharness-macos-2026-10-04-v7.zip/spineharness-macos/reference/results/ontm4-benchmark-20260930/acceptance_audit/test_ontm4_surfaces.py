"""Supplemental black-box validation, authored before either measured solution.

Only the LLM adapter and fixture data locations are substituted. Search,
rule loading, SQL execution and forward chaining remain the implementation's.
These checks are not supplied to either measured workflow or used for refinement.
"""
import json
import sqlite3
import pytest


class OfflineAdapter:
    model_id = 'offline-audit-fixture'
    def complete(self, payload):
        if 'synth' in payload.get('payload_id', ''):
            return 'The incident classification is derived from the event type.'
        return json.dumps({'intent': 'classify events', 'classes': ['DomainEvent'], 'filters': []})


@pytest.fixture
def fixture_data(tmp_path, monkeypatch):
    import runtime.reasoning_search.engine as engine
    db = tmp_path / 'events.db'
    with sqlite3.connect(db) as con:
        con.executescript('''CREATE TABLE events (id INTEGER PRIMARY KEY, hasEventType TEXT);
        INSERT INTO events VALUES (1, 'INCIDENT'), (2, 'MAINTENANCE');''')
    flavors = tmp_path / 'flavors'; flavors.mkdir()
    (flavors / 'audit.json').write_text(json.dumps({'name': 'audit', 'owl_classes': ['DomainEvent'],
        'context_terms': {'id': 'identifier', 'hasEventType': 'event type'}, 'db_tables': ['events']}))
    mapping = tmp_path / 'mapping.csv'
    mapping.write_text('ontology_class,ontology_property,physical_table,physical_column,sensitivity_tier\n'
        'DomainEvent,(class),events,(table),Internal\n'
        'DomainEvent,id,events,id,Internal\n'
        'DomainEvent,hasEventType,events,hasEventType,Internal\n')
    monkeypatch.setattr(engine, '_DEFAULT_FLAVORS', str(flavors))
    monkeypatch.setattr(engine, '_DEFAULT_MAPPING', str(mapping))
    monkeypatch.setattr(engine, '_resolve_adapter', lambda providers: OfflineAdapter())
    monkeypatch.setenv('ONTOFORGE_SEARCH', '1')
    monkeypatch.setenv('ONTOMESH_DB_URL', str(tmp_path / 'ontologies.db'))
    return str(db)


def assert_derived(answer):
    assert answer['status'] == 'ok'
    inferred = {tuple(row['fact']): row for row in answer['inferred']}
    assert ('IncidentEvent', '1') in inferred, 'No derived IncidentEvent from real rule execution'
    assert ('MaintenanceEvent', '2') in inferred, 'No derived MaintenanceEvent from real rule execution'
    row = inferred[('IncidentEvent', '1')]
    assert row['rule']
    assert {('DomainEvent', '1'), ('hasEventType', '1', 'INCIDENT')} <= {tuple(f) for f in row['derived_from']}


def test_positive_control_explicit_rules(fixture_data):
    from dataclasses import asdict
    from runtime.reasoning_search import search
    from runtime.reasoning_search.rule_compiler import compile_rules
    answer = search('Classify the events', flavor='audit', db_path=fixture_data, rules=compile_rules())
    assert_derived(asdict(answer))


def test_cli_loads_rules_by_default(fixture_data, capsys):
    from runtime.reasoning_search.cli import run
    assert run(['Classify the events', '--flavor', 'audit', '--db', fixture_data, '--json']) == 0
    assert_derived(json.loads(capsys.readouterr().out))


def test_cli_no_rules_disables_derivation(fixture_data, capsys):
    from runtime.reasoning_search.cli import run
    assert run(['Classify the events', '--flavor', 'audit', '--db', fixture_data, '--json', '--no-rules']) == 0
    answer = json.loads(capsys.readouterr().out)
    assert answer['status'] == 'ok'
    assert answer['inferred'] == []


@pytest.fixture
def client(fixture_data, monkeypatch):
    import wizard.app as web
    monkeypatch.setattr(web, 'ONTOFORGE_SEARCH', True)
    monkeypatch.setattr(web, 'SEARCH_CACHE_TTL', 0)
    monkeypatch.setattr(web, '_build_memory', lambda: None)
    web.app.config['TESTING'] = True
    with web.app.test_client() as c:
        yield c


def body(db):
    return {'question': 'Classify the events', 'flavor': 'audit', 'db': db}


def test_http_enabled_search_derives_facts(client, fixture_data):
    response = client.post('/api/search', json=body(fixture_data))
    assert response.status_code == 200
    assert_derived(response.get_json())


def test_sse_enabled_search_derives_same_facts(client, fixture_data):
    response = client.post('/api/search/stream', json=body(fixture_data))
    assert response.status_code == 200
    events = []
    for chunk in response.get_data(as_text=True).split('\n\n'):
        lines = chunk.splitlines()
        event = next((x[7:] for x in lines if x.startswith('event: ')), None)
        data = next((x[6:] for x in lines if x.startswith('data: ')), None)
        if event and data:events.append((event, json.loads(data)))
    assert not any(kind == 'error' for kind, _ in events)
    answers = [data for kind, data in events if kind == 'answer']
    assert len(answers) == 1
    assert_derived(answers[0])


def test_fresh_sparql_search_receives_rules(client, fixture_data, monkeypatch):
    import runtime.reasoning_search as rs
    real_search = rs.search
    observed = []
    def capture(*args, **kwargs):
        result = real_search(*args, **kwargs)
        observed.append(result)
        return result
    monkeypatch.setattr(rs, 'search', capture)
    response = client.post('/api/sparql', json={**body(fixture_data), 'query': 'SELECT ?s ?p ?o WHERE {?s ?p ?o}'})
    assert response.status_code == 200
    assert len(observed) == 1
    from dataclasses import asdict
    assert_derived(asdict(observed[0]))


def test_http_and_stream_remain_flag_gated(client, fixture_data, monkeypatch):
    import wizard.app as web
    monkeypatch.setattr(web, 'ONTOFORGE_SEARCH', False)
    for route in ('/api/search', '/api/search/stream', '/api/sparql'):
        assert client.post(route, json=body(fixture_data)).status_code == 404
