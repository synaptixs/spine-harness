# Proposed changes

These changes exist only in the disposable benchmark copy.

```diff
diff --git a/runtime/reasoning_search/_loaders.py b/runtime/reasoning_search/_loaders.py
index f552352..c7d0530 100644
--- a/runtime/reasoning_search/_loaders.py
+++ b/runtime/reasoning_search/_loaders.py
@@ -39,9 +39,11 @@ def controlled_vocab(flavor_cfg: dict) -> set[str]:
 class Mapping:
     """Logical↔physical map distilled from logical_physical_map.csv."""
 
-    class_table: dict[str, str] = field(default_factory=dict)            # OWL class -> table
-    prop_col: dict[tuple[str, str], tuple[str, str]] = field(default_factory=dict)  # (class,prop)->(table,col)
-    tier: dict[str, str] = field(default_factory=dict)                   # element -> sensitivity tier
+    class_table: dict[str, str] = field(default_factory=dict)  # OWL class -> table
+    prop_col: dict[tuple[str, str], tuple[str, str]] = field(
+        default_factory=dict
+    )  # (class,prop)->(table,col)
+    tier: dict[str, str] = field(default_factory=dict)  # element -> sensitivity tier
 
     def table_for(self, owl_class: str) -> str | None:
         return self.class_table.get(owl_class)
@@ -109,7 +111,7 @@ def _norm_prop(prop: str) -> str:
     s = "".join(ch for ch in str(prop).lower() if ch.isalnum())
     for pre in ("has", "is"):
         if s.startswith(pre) and len(s) > len(pre) + 2:
-            return s[len(pre):]
+            return s[len(pre) :]
     return s
 
 
@@ -121,7 +123,9 @@ def load_mapping(csv_path: str) -> Mapping:
     """
     m = Mapping()
     if not os.path.exists(csv_path):
-        raise FileNotFoundError(f"mapping not found: {csv_path} (run the toolkit first)")
+        raise FileNotFoundError(
+            f"mapping not found: {csv_path} (run the toolkit first)"
+        )
     with open(csv_path, newline="", encoding="utf-8") as fh:
         for row in csv.DictReader(fh):
             cls = (row.get("ontology_class") or "").strip()
@@ -141,3 +145,106 @@ def load_mapping(csv_path: str) -> Mapping:
                 if tier:
                     m.tier[f"{cls}.{prop}"] = tier
     return m
+
+
+def _rule_texts(value: object, flavor: str) -> list[str]:
+    """Extract Datalog source from a compiled artifact or stored rule list."""
+    if isinstance(value, str):
+        return [value.strip()] if value.strip() else []
+    if isinstance(value, list):
+        return [text for item in value for text in _rule_texts(item, flavor)]
+    if not isinstance(value, dict):
+        return []
+    if value.get("enabled") is False or value.get("active") is False:
+        return []
+    if value.get("flavor") not in (None, flavor):
+        return []
+    for key in ("rules", "compiled_rules", "datalog_rules", "flavors"):
+        if key in value:
+            nested = value[key]
+            if key == "flavors" and isinstance(nested, dict):
+                nested = nested.get(flavor, [])
+            return _rule_texts(nested, flavor)
+    if flavor in value:
+        return _rule_texts(value[flavor], flavor)
+    for key in ("datalog", "compiled", "compiled_rule"):
+        if key in value:
+            return _rule_texts(value[key], flavor)
+    if str(value.get("kind", "datalog")).lower() in ("shacl", "sparql", "owl"):
+        return []
+    for key in ("body", "rule"):
+        if key in value:
+            return _rule_texts(value[key], flavor)
+    return []
+
+
+def load_rules(
+    flavor: str,
+    *,
+    rules_path: str | None = None,
+    stored_rules: list[object] | None = None,
+    root: str | None = None,
+) -> list[str]:
+    """Load valid Datalog rules from compiled output and the active session.
+
+    Missing artifacts mean no rules. Other wizard rule kinds are ignored because
+    the search reasoner accepts Datalog rather than Turtle or SPARQL.
+    """
+    from .reasoner import parse_rule
+
+    root = root or os.path.dirname(
+        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
+    )
+    source = rules_path if rules_path is not None else os.environ.get("ONTOFORGE_RULES")
+    directory = os.path.join(root, "output", "rules")
+    paths = [
+        os.path.join(directory, "compiled.json"),
+        os.path.join(directory, "compiled_rules.json"),
+        os.path.join(directory, "rules.json"),
+    ]
+    if os.path.basename(flavor) == flavor:
+        paths += [
+            os.path.join(directory, flavor + suffix)
+            for suffix in (".json", ".dl", ".datalog")
+        ]
+    if source:
+        paths = (
+            [source]
+            if os.path.isfile(source)
+            else [os.path.join(source, os.path.basename(path)) for path in paths]
+        )
+    candidates: list[str] = []
+    for path in dict.fromkeys(paths):
+        if not os.path.isfile(path):
+            continue
+        with open(path, encoding="utf-8") as handle:
+            try:
+                if path.endswith(".json"):
+                    candidates.extend(_rule_texts(json.load(handle), flavor))
+                else:
+                    candidates.extend(
+                        line.strip()
+                        for line in handle
+                        if line.strip() and not line.lstrip().startswith("#")
+                    )
+            except ValueError:
+                continue
+    if stored_rules is None:
+        session_path = os.path.join(root, ".wizard_session.json")
+        if os.path.isfile(session_path):
+            try:
+                with open(session_path, encoding="utf-8") as handle:
+                    stored_rules = json.load(handle).get("rules", [])
+            except (OSError, ValueError, AttributeError):
+                stored_rules = []
+    candidates.extend(_rule_texts(stored_rules or [], flavor))
+    valid: list[str] = []
+    for source_text in candidates:
+        if source_text in valid:
+            continue
+        try:
+            parse_rule(source_text)
+        except ValueError:
+            continue
+        valid.append(source_text)
+    return valid
diff --git a/runtime/reasoning_search/cli.py b/runtime/reasoning_search/cli.py
index 4642544..ab0937c 100644
--- a/runtime/reasoning_search/cli.py
+++ b/runtime/reasoning_search/cli.py
@@ -11,6 +11,8 @@ from __future__ import annotations
 
 import argparse
 import json
+import os
+import sys
 from dataclasses import asdict
 
 
@@ -24,17 +26,49 @@ def run(argv: list[str]) -> int:
     p.add_argument("--flavor", required=True, help="ontology flavor / scope")
     p.add_argument("--db", default=None, help="database path/connection (read-only)")
     p.add_argument("--provider", default="ollama", help="ollama | openai")
-    p.add_argument("--max-tier", default="Internal", help="access ceiling (sensitivity tier)")
+    p.add_argument(
+        "--max-tier", default="Internal", help="access ceiling (sensitivity tier)"
+    )
     p.add_argument("--k", type=int, default=5)
-    p.add_argument("--json", action="store_true", dest="as_json",
-                   help="emit the full ReasonedAnswer as JSON")
+    rule_options = p.add_mutually_exclusive_group()
+    rule_options.add_argument(
+        "--rules",
+        nargs="?",
+        const="",
+        metavar="PATH",
+        help="load rules from PATH, or use the default compiled and stored rules",
+    )
+    rule_options.add_argument(
+        "--no-rules",
+        action="store_true",
+        help="disable reasoning rules",
+    )
+    p.add_argument(
+        "--json",
+        action="store_true",
+        dest="as_json",
+        help="emit the full ReasonedAnswer as JSON",
+    )
     args = p.parse_args(argv)
 
     from runtime.reasoning_search import search
+    from runtime.reasoning_search._loaders import load_rules
 
+    rules = (
+        [] if args.no_rules else load_rules(args.flavor, rules_path=args.rules or None)
+    )
     ans = search(
-        args.question, flavor=args.flavor, db_path=args.db,
-        providers=args.provider, max_tier=args.max_tier, k=args.k,
+        args.question,
+        flavor=args.flavor,
+        db_path=(
+            args.db
+            or getattr(sys.modules.get("wizard.app"), "SEARCH_DB", None)
+            or os.environ.get("ONTOFORGE_DB")
+        ),
+        providers=args.provider,
+        max_tier=args.max_tier,
+        k=args.k,
+        rules=rules,
     )
 
     if args.as_json:
@@ -49,6 +83,8 @@ def run(argv: list[str]) -> int:
             for c in ans.citations:
                 tag = " (inferred)" if c.inferred else ""
                 print(f"    - {c.iri}{tag}  [{c.source_table}]")
-        print(f"  confidence: {ans.confidence:.0%} · status: {ans.status} · provider: {ans.provider}")
+        print(
+            f"  confidence: {ans.confidence:.0%} · status: {ans.status} · provider: {ans.provider}"
+        )
 
     return 0 if ans.status in ("ok", "empty") else 1
diff --git a/runtime/reasoning_search/engine.py b/runtime/reasoning_search/engine.py
index f9b5cc6..1decaf9 100644
--- a/runtime/reasoning_search/engine.py
+++ b/runtime/reasoning_search/engine.py
@@ -61,14 +61,20 @@ class ReasonedAnswer:
     executed_query: str = ""
     trace: list[dict[str, Any]] = field(default_factory=list)
     provider: str = ""
-    status: str = "ok"          # "ok" | "blocked" | "ungrounded" | "empty"
-    subgraph: dict[str, Any] = field(default_factory=dict)  # RDF view when materialize=True
+    status: str = "ok"  # "ok" | "blocked" | "ungrounded" | "empty"
+    subgraph: dict[str, Any] = field(
+        default_factory=dict
+    )  # RDF view when materialize=True
 
 
 # ── helpers ──────────────────────────────────────────────────────────────────
 def _resolve_adapter(providers: str | dict | None):
     """Build an adapter from a provider name (lazy import). Tests inject instead."""
-    name = providers if isinstance(providers, str) else (providers or {}).get("planner", "ollama")
+    name = (
+        providers
+        if isinstance(providers, str)
+        else (providers or {}).get("planner", "ollama")
+    )
     name = (name or "ollama").lower()
     try:
         if name == "ollama":
@@ -81,7 +87,9 @@ def _resolve_adapter(providers: str | dict | None):
             return OpenAIAdapter(os.environ.get("OPENAI_MODEL", "gpt-4o-mini"))
     except Exception as exc:  # pragma: no cover - depends on optional SDKs
         raise RuntimeError(f"could not initialise provider {name!r}: {exc}") from exc
-    raise ValueError(f"unknown provider {name!r} (use 'ollama' or 'openai', or inject adapter=)")
+    raise ValueError(
+        f"unknown provider {name!r} (use 'ollama' or 'openai', or inject adapter=)"
+    )
 
 
 _SYNTH_SYSTEM = (
@@ -90,36 +98,61 @@ _SYNTH_SYSTEM = (
 )
 
 
-def _synthesize(adapter: Adapter, question: str, rows: list[dict],
-                inferred: list[dict] | None = None) -> str:
+def _synthesize(
+    adapter: Adapter,
+    question: str,
+    rows: list[dict],
+    inferred: list[dict] | None = None,
+) -> str:
     inferred_txt = (
         f"\n\nDerived facts (inferred via rules — cite as derived): "
-        f"{json.dumps(inferred, default=str)[:2000]}" if inferred else ""
+        f"{json.dumps(inferred, default=str)[:2000]}"
+        if inferred
+        else ""
     )
     payload = {
         "system": _SYNTH_SYSTEM,
-        "messages": [{"role": "user", "content": (
-            f"Question: {question}\n\n"
-            f"Records (JSON): {json.dumps(rows, default=str)[:6000]}"
-            f"{inferred_txt}\n\n"
-            "Write a short, direct answer grounded in these records and any "
-            "derived facts. Make clear which conclusions are derived."
-        )}],
+        "messages": [
+            {
+                "role": "user",
+                "content": (
+                    f"Question: {question}\n\n"
+                    f"Records (JSON): {json.dumps(rows, default=str)[:6000]}"
+                    f"{inferred_txt}\n\n"
+                    "Write a short, direct answer grounded in these records and any "
+                    "derived facts. Make clear which conclusions are derived."
+                ),
+            }
+        ],
         "token_budget": 600,
         "payload_id": "reasoning-search-synth",
     }
     return adapter.complete(payload).strip()
 
 
-def _terminal(answer: str, status: str, provider: str, trace: list, **kw) -> ReasonedAnswer:
-    return ReasonedAnswer(answer=answer, status=status, confidence=0.0,
-                          provider=str(provider), trace=trace, **kw)
+def _terminal(
+    answer: str, status: str, provider: str, trace: list, **kw
+) -> ReasonedAnswer:
+    return ReasonedAnswer(
+        answer=answer,
+        status=status,
+        confidence=0.0,
+        provider=str(provider),
+        trace=trace,
+        **kw,
+    )
 
 
-def _fk_neighbors(db_path: str, table: str | None, rows: list[dict], *,
-                  mapping=None, allowed_tables: set[str] | None = None,
-                  max_tier: str = "Public",
-                  deid_columns: set[str] | None = None) -> tuple[list[dict], list[dict]]:
+def _fk_neighbors(
+    db_path: str,
+    table: str | None,
+    rows: list[dict],
+    *,
+    mapping=None,
+    allowed_tables: set[str] | None = None,
+    max_tier: str = "Public",
+    deid_columns: set[str] | None = None,
+) -> tuple[list[dict], list[dict]]:
     """Resolve 1-hop FK-neighbour rows for the result set (Phase 4 #1).
 
     For each FK (from_col → ref_table.to_col) declared on ``table``, fetch the
@@ -165,23 +198,43 @@ def _fk_neighbors(db_path: str, table: str | None, rows: list[dict], *,
             return [], skipped
         for fk in fks:
             ref_table, from_col, to_col = fk["table"], fk["from"], (fk["to"] or "id")
-            if not (str(ref_table).isidentifier() and str(from_col).isidentifier()
-                    and str(to_col).isidentifier()):
+            if not (
+                str(ref_table).isidentifier()
+                and str(from_col).isidentifier()
+                and str(to_col).isidentifier()
+            ):
                 continue
             if allowed_tables and ref_table not in allowed_tables:
-                skipped.append({"ref_table": ref_table, "from_col": from_col,
-                                "reason": "not allow-listed for this flavor"})
+                skipped.append(
+                    {
+                        "ref_table": ref_table,
+                        "from_col": from_col,
+                        "reason": "not allow-listed for this flavor",
+                    }
+                )
                 continue
             cols = mapping.readable_columns(ref_table, max_tier)
             if to_col not in cols:
                 # The join key is needed to attach the edge; include it only
                 # when it is itself readable.
-                cols = ([to_col] + cols) if tier_ok(
-                    mapping.tier.get(f"{mapping.class_for_table(ref_table)}.{to_col}"),
-                    max_tier) else cols
+                cols = (
+                    ([to_col] + cols)
+                    if tier_ok(
+                        mapping.tier.get(
+                            f"{mapping.class_for_table(ref_table)}.{to_col}"
+                        ),
+                        max_tier,
+                    )
+                    else cols
+                )
             if not cols:
-                skipped.append({"ref_table": ref_table, "from_col": from_col,
-                                "reason": f"no columns readable at tier {max_tier!r}"})
+                skipped.append(
+                    {
+                        "ref_table": ref_table,
+                        "from_col": from_col,
+                        "reason": f"no columns readable at tier {max_tier!r}",
+                    }
+                )
                 continue
             select_list = ", ".join(sorted(set(cols)))
             for i, row in enumerate(rows):
@@ -199,8 +252,15 @@ def _fk_neighbors(db_path: str, table: str | None, rows: list[dict], *,
                     nb_row = dict(nb)
                     if deid_columns:
                         nb_row = deidentify([nb_row], deid_columns)[0]
-                    out.append({"subject_key": str(row.get("id", i)), "from_col": from_col,
-                                "ref_table": ref_table, "ref_key": str(fv), "row": nb_row})
+                    out.append(
+                        {
+                            "subject_key": str(row.get("id", i)),
+                            "from_col": from_col,
+                            "ref_table": ref_table,
+                            "ref_key": str(fv),
+                            "row": nb_row,
+                        }
+                    )
     finally:
         con.close()
     return out, skipped
@@ -254,7 +314,9 @@ def search(
     flavors_dir = flavors_dir or _DEFAULT_FLAVORS
     mapping_path = mapping_path or _DEFAULT_MAPPING
     llm = adapter or _resolve_adapter(providers)
-    provider_label = providers if isinstance(providers, str) else getattr(llm, "model_id", "")
+    provider_label = (
+        providers if isinstance(providers, str) else getattr(llm, "model_id", "")
+    )
     trace: list[dict[str, Any]] = []
 
     def emit(entry: dict) -> None:
@@ -284,26 +346,42 @@ def search(
         mapping = load_mapping(mapping_path)
 
         the_plan = _plan(question, vocab=vocab, adapter=llm)
-        emit({"stage": "plan", "classes": the_plan.classes,
-                      "intent": the_plan.intent,
-                      "filters": [vars(f) for f in the_plan.filters]})
+        emit(
+            {
+                "stage": "plan",
+                "classes": the_plan.classes,
+                "intent": the_plan.intent,
+                "filters": [vars(f) for f in the_plan.filters],
+            }
+        )
 
         ctier = mapping.tier.get(the_plan.primary_class)
         if ctier and not tier_ok(ctier, max_tier):
             return _terminal(
                 f"That question targets {the_plan.primary_class} data classified "
                 f"'{ctier}', above your access ceiling ('{max_tier}'). Request denied.",
-                "blocked", provider_label, trace,
-                plan={"classes": the_plan.classes, "intent": the_plan.intent})
-
-        sql, params = compile_sql(the_plan, mapping=mapping,
-                                  allowed_tables=allowed_tables, limit=limit, max_tier=max_tier)
+                "blocked",
+                provider_label,
+                trace,
+                plan={"classes": the_plan.classes, "intent": the_plan.intent},
+            )
+
+        sql, params = compile_sql(
+            the_plan,
+            mapping=mapping,
+            allowed_tables=allowed_tables,
+            limit=limit,
+            max_tier=max_tier,
+        )
         sql = enforce_limit(sql, limit)
     except (PlanValidationError, CompileError, SafetyError) as exc:
         emit({"stage": "error", "detail": str(exc)})
         return _terminal(
             f"I couldn't ground that question in the ontology: {exc}",
-            "ungrounded", provider_label, trace)
+            "ungrounded",
+            provider_label,
+            trace,
+        )
 
     # 4. Execute (read-only, guarded) — with a light agentic re-plan on empty.
     rows = safe_execute(db_path, sql, params, timeout_ms=timeout_ms) if db_path else []
@@ -314,32 +392,56 @@ def search(
         try:
             the_plan = _plan(
                 question + " (the previous query returned no rows — relax or drop "
-                "non-essential filters)", vocab=vocab, adapter=llm)
-            sql, params = compile_sql(the_plan, mapping=mapping,
-                                      allowed_tables=allowed_tables, limit=limit, max_tier=max_tier)
+                "non-essential filters)",
+                vocab=vocab,
+                adapter=llm,
+            )
+            sql, params = compile_sql(
+                the_plan,
+                mapping=mapping,
+                allowed_tables=allowed_tables,
+                limit=limit,
+                max_tier=max_tier,
+            )
             sql = enforce_limit(sql, limit)
         except (PlanValidationError, CompileError, SafetyError):
             break
         rows = safe_execute(db_path, sql, params, timeout_ms=timeout_ms)
     if deid_columns:
         rows = deidentify(rows, deid_columns)
-    emit({"stage": "execute", "sql": sql, "params": params,
-          "rows": len(rows), "replans": replans})
+    emit(
+        {
+            "stage": "execute",
+            "sql": sql,
+            "params": params,
+            "rows": len(rows),
+            "replans": replans,
+        }
+    )
 
     # 4a. Resolve FK-neighbour edges once — shared by the reasoner and the
     #     materialized subgraph.
     neighbors: list[dict] = []
     if (auto_relations or materialize) and db_path and rows:
         neighbors, skipped_fks = _fk_neighbors(
-            db_path, mapping.table_for(the_plan.primary_class), rows,
-            mapping=mapping, allowed_tables=allowed_tables, max_tier=max_tier,
+            db_path,
+            mapping.table_for(the_plan.primary_class),
+            rows,
+            mapping=mapping,
+            allowed_tables=allowed_tables,
+            max_tier=max_tier,
             deid_columns=deid_columns,
         )
         # Dropped edges are reported rather than silently omitted: a caller
         # seeing fewer relations than expected should be able to tell that a
         # policy withheld them, not that the data lacked them.
-        emit({"stage": "relations", "neighbor_rows": len(neighbors),
-              "skipped_fks": skipped_fks})
+        emit(
+            {
+                "stage": "relations",
+                "neighbor_rows": len(neighbors),
+                "skipped_fks": skipped_fks,
+            }
+        )
 
     # 4b. Reason — derive facts over the result subgraph (+ any relationship facts).
     inferred: list[dict] = []
@@ -357,23 +459,50 @@ def search(
             res = reason(facts, [parse_rule(r) for r in rules])
             for f in res.derived:
                 rule_name, support = res.provenance[f]
-                inferred.append({"fact": list(f), "rule": rule_name,
-                                 "derived_from": [list(s) for s in support]})
-                inferred_cites.append(Citation(
-                    iri="prov:Derived/" + "/".join(map(str, f)),
-                    label=f"{f[0]}(" + ", ".join(map(str, f[1:])) + ")",
-                    inferred=True))
-            emit({"stage": "reason", "derived": len(res.derived)})
+                inferred.append(
+                    {
+                        "fact": list(f),
+                        "rule": rule_name,
+                        "derived_from": [list(s) for s in support],
+                    }
+                )
+                inferred_cites.append(
+                    Citation(
+                        iri="prov:Derived/" + "/".join(map(str, f)),
+                        label=f"{f[0]}(" + ", ".join(map(str, f[1:])) + ")",
+                        inferred=True,
+                    )
+                )
+            emit(
+                {
+                    "stage": "reason",
+                    "rules_loaded": len(rules),
+                    "derived": len(res.derived),
+                }
+            )
         except ValueError as exc:
-            emit({"stage": "reason", "error": str(exc)})
+            emit(
+                {
+                    "stage": "reason",
+                    "rules_loaded": len(rules),
+                    "derived": 0,
+                    "error": str(exc),
+                }
+            )
+    else:
+        emit({"stage": "reason", "rules_loaded": 0, "derived": 0})
 
     # 4c. Materialize — build the RDF result subgraph (rows + FK edges + derived).
     subgraph: dict[str, Any] = {}
     if materialize:
         from .subgraph import build_subgraph
 
-        sg = build_subgraph(rows, primary_class=the_plan.primary_class,
-                            fk_neighbors=neighbors, inferred=inferred)
+        sg = build_subgraph(
+            rows,
+            primary_class=the_plan.primary_class,
+            fk_neighbors=neighbors,
+            inferred=inferred,
+        )
         subgraph = sg.to_dict()
         emit({"stage": "materialize", "triples": subgraph.get("count", 0)})
 
@@ -384,22 +513,34 @@ def search(
     # 6. Remember — persist this turn for future recall.
     if memory is not None:
         try:
-            memory.remember({"question": question, "flavor": flavor,
-                             "answer": answer, "status": "ok" if rows else "empty"})
+            memory.remember(
+                {
+                    "question": question,
+                    "flavor": flavor,
+                    "answer": answer,
+                    "status": "ok" if rows else "empty",
+                }
+            )
         except Exception:  # noqa: BLE001
             pass
 
     table = mapping.table_for(the_plan.primary_class) or ""
     citations = [
-        Citation(iri=f"{the_plan.primary_class}/{row.get('id', i)}",
-                 label=str(next(iter(row.values()), "")), source_table=table)
+        Citation(
+            iri=f"{the_plan.primary_class}/{row.get('id', i)}",
+            label=str(next(iter(row.values()), "")),
+            source_table=table,
+        )
         for i, row in enumerate(rows[:k])
     ] + inferred_cites
 
     return ReasonedAnswer(
         answer=answer,
-        plan={"intent": the_plan.intent, "classes": the_plan.classes,
-              "filters": [vars(f) for f in the_plan.filters]},
+        plan={
+            "intent": the_plan.intent,
+            "classes": the_plan.classes,
+            "filters": [vars(f) for f in the_plan.filters],
+        },
         results=rows,
         citations=citations,
         inferred=inferred,
diff --git a/tests/test_search_rule_surfaces.py b/tests/test_search_rule_surfaces.py
new file mode 100644
index 0000000..6b9bc77
--- /dev/null
+++ b/tests/test_search_rule_surfaces.py
@@ -0,0 +1,222 @@
+"""Exercise rule loading through the CLI and HTTP search entry points."""
+
+from __future__ import annotations
+
+import json
+import sqlite3
+from pathlib import Path
+from types import SimpleNamespace
+from typing import Any
+
+import pytest
+
+import wizard.app as wizard_app
+from runtime import reasoning_search
+from runtime.reasoning_search import engine
+from runtime.reasoning_search.cli import run
+
+RULE = "vip(X) :- Customer(X)."
+
+
+class FakeAdapter:
+    """Return a fixed plan and an answer reflecting derived facts."""
+
+    model_id = "fake"
+
+    def complete(self, payload: dict[str, Any]) -> str:
+        if payload.get("payload_id") == "reasoning-search-synth":
+            prompt = payload["messages"][0]["content"]
+            return (
+                "Alice is VIP (derived)."
+                if "Derived facts" in prompt
+                else "No VIP fact."
+            )
+        return json.dumps({"intent": "list", "classes": ["Customer"], "filters": []})
+
+
+@pytest.fixture()
+def configured_search(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
+    flavors_dir = tmp_path / "flavors"
+    flavors_dir.mkdir()
+    (flavors_dir / "demo.json").write_text(
+        json.dumps({"owl_classes": ["Customer"], "db_tables": ["customer"]}),
+        encoding="utf-8",
+    )
+    mapping_path = tmp_path / "mapping.csv"
+    mapping_path.write_text(
+        "ontology_class,ontology_property,physical_table,physical_column,"
+        "sensitivity_tier\n"
+        "Customer,(class),customer,(table),Internal\n"
+        "Customer,id,customer,id,Internal\n"
+        "Customer,name,customer,name,Internal\n",
+        encoding="utf-8",
+    )
+    db_path = tmp_path / "customers.db"
+    with sqlite3.connect(db_path) as connection:
+        connection.execute("CREATE TABLE customer (id INTEGER, name TEXT)")
+        connection.execute("INSERT INTO customer VALUES (1, 'Alice')")
+    rules_path = tmp_path / "compiled.json"
+    rules_path.write_text(json.dumps({"rules": [RULE]}), encoding="utf-8")
+
+    def resolve_adapter(providers: str | dict[str, str] | None) -> FakeAdapter:
+        return FakeAdapter()
+
+    def parse_rule(source: str) -> str:
+        return source
+
+    def derive(facts: list[Any], rules: list[Any]) -> SimpleNamespace:
+        customer = next(
+            (fact for fact in facts if len(fact) == 2 and fact[0] == "Customer"),
+            None,
+        )
+        if not rules or customer is None:
+            return SimpleNamespace(derived=[], provenance={})
+        derived = ("vip", str(customer[1]))
+        return SimpleNamespace(
+            derived=[derived],
+            provenance={derived: (RULE, [customer])},
+        )
+
+    monkeypatch.setattr(engine, "_DEFAULT_FLAVORS", str(flavors_dir))
+    monkeypatch.setattr(engine, "_DEFAULT_MAPPING", str(mapping_path))
+    monkeypatch.setattr(engine, "_resolve_adapter", resolve_adapter)
+    monkeypatch.setattr(engine, "parse_rule", parse_rule)
+    monkeypatch.setattr(engine, "reason", derive)
+    from runtime.reasoning_search import reasoner
+
+    monkeypatch.setattr(reasoner, "parse_rule", parse_rule)
+    monkeypatch.setenv("ONTOFORGE_RULES", str(rules_path))
+    monkeypatch.setattr(wizard_app, "SEARCH_DB", str(db_path))
+    return rules_path
+
+
+def test_cli_loads_rules_by_default_and_no_rules_disables_them(
+    configured_search: Path, capsys: pytest.CaptureFixture[str]
+) -> None:
+    assert configured_search.is_file()
+    args = ["Which customers are VIP?", "--flavor", "demo", "--json"]
+    assert run(args) == 0
+    enabled = json.loads(capsys.readouterr().out)
+    assert enabled["inferred"]
+    assert enabled["answer"] == "Alice is VIP (derived)."
+    assert {"stage": "reason", "rules_loaded": 1, "derived": 1} in (enabled["trace"])
+
+    assert run([*args, "--no-rules"]) == 0
+    disabled = json.loads(capsys.readouterr().out)
+    assert disabled["inferred"] == []
+    assert disabled["answer"] == "No VIP fact."
+    assert {"stage": "reason", "rules_loaded": 0, "derived": 0} in (disabled["trace"])
+
+
+def test_cli_accepts_explicit_rules_path(
+    configured_search: Path,
+    capsys: pytest.CaptureFixture[str],
+    monkeypatch: pytest.MonkeyPatch,
+) -> None:
+    monkeypatch.setenv("ONTOFORGE_RULES", str(configured_search.parent / "missing"))
+    assert (
+        run(
+            [
+                "Which customers are VIP?",
+                "--flavor",
+                "demo",
+                "--rules",
+                str(configured_search),
+                "--json",
+            ]
+        )
+        == 0
+    )
+    assert json.loads(capsys.readouterr().out)["inferred"]
+
+
+@pytest.fixture()
+def http_app(configured_search: Path, monkeypatch: pytest.MonkeyPatch) -> Any:
+    assert configured_search.is_file()
+
+    def empty_session() -> dict[str, Any]:
+        return {"rules": []}
+
+    def no_memory() -> None:
+        return None
+
+    monkeypatch.setattr(wizard_app, "ONTOFORGE_SEARCH", True)
+    monkeypatch.setattr(wizard_app, "SEARCH_CACHE_TTL", 0.0)
+    monkeypatch.setattr(wizard_app, "_load_session", empty_session)
+    monkeypatch.setattr(wizard_app, "_build_memory", no_memory)
+    return wizard_app.app
+
+
+def test_http_search_returns_inferred_facts(http_app: Any) -> None:
+    response = http_app.test_client().post(
+        "/api/search",
+        json={"question": "Which customers are VIP?", "flavor": "demo"},
+    )
+    assert response.status_code == 200
+    answer = response.get_json()
+    assert answer["inferred"]
+    assert answer["answer"] == "Alice is VIP (derived)."
+    assert {"stage": "reason", "rules_loaded": 1, "derived": 1} in (answer["trace"])
+
+
+def test_http_stream_emits_inferred_facts_and_reason_stage(http_app: Any) -> None:
+    response = http_app.test_client().post(
+        "/api/search/stream",
+        json={"question": "Which customers are VIP?", "flavor": "demo"},
+    )
+    assert response.status_code == 200
+    events: list[tuple[str, dict[str, Any]]] = []
+    for block in response.get_data(as_text=True).split("\n\n"):
+        lines = block.splitlines()
+        if len(lines) >= 2:
+            events.append((lines[0][7:], json.loads(lines[1][6:])))
+    assert any(
+        kind == "stage" and data == {"stage": "reason", "rules_loaded": 1, "derived": 1}
+        for kind, data in events
+    )
+    assert any(kind == "answer" and data["inferred"] for kind, data in events)
+
+
+def test_sparql_search_path_receives_rules(
+    http_app: Any, monkeypatch: pytest.MonkeyPatch
+) -> None:
+    original_search = reasoning_search.search
+    seen_rules: list[list[str]] = []
+    seen_inferred: list[list[dict[str, Any]]] = []
+
+    def record_search(question: str, **kwargs: Any) -> Any:
+        seen_rules.append(kwargs["rules"])
+        answer = original_search(question, **kwargs)
+        seen_inferred.append(answer.inferred)
+        return answer
+
+    def count_triples(graph: Any, query: str) -> dict[str, int]:
+        return {"triples": len(graph.triples)}
+
+    monkeypatch.setattr(reasoning_search, "search", record_search)
+    monkeypatch.setattr(reasoning_search, "sparql", count_triples)
+    response = http_app.test_client().post(
+        "/api/sparql",
+        json={
+            "question": "Which customers are VIP?",
+            "flavor": "demo",
+            "query": "SELECT ?s WHERE { ?s ?p ?o }",
+        },
+    )
+    assert response.status_code == 200
+    assert seen_rules == [[RULE]]
+    assert seen_inferred and seen_inferred[0]
+    assert response.get_json()["triples"] > 0
+
+
+def test_http_search_preserves_tier_ceiling(http_app: Any) -> None:
+    body = {
+        "question": "Which customers are VIP?",
+        "flavor": "demo",
+        "max_tier": "Public",
+    }
+    response = http_app.test_client().post("/api/search", json=body)
+    assert response.status_code == 200
+    answer = response.get_json()
+    assert answer["status"] == "blocked"
+    assert answer["inferred"] == []
diff --git a/wizard/app.py b/wizard/app.py
index b8d3c5e..de46915 100644
--- a/wizard/app.py
+++ b/wizard/app.py
@@ -31,18 +31,18 @@ Usage:
 
 from __future__ import annotations
 
+import argparse
+import json
 import os
 import re
-import sys
-import json
 import subprocess
+import sys
 import threading
-import argparse
 from datetime import datetime, timezone
 from pathlib import Path
 
-HERE    = os.path.dirname(os.path.abspath(__file__))
-ROOT    = os.path.dirname(HERE)
+HERE = os.path.dirname(os.path.abspath(__file__))
+ROOT = os.path.dirname(HERE)
 SRC_DIR = os.path.join(ROOT, "src")
 sys.path.insert(0, SRC_DIR)
 sys.path.insert(0, ROOT)
@@ -59,6 +59,7 @@ ONTOLOGIES_DB = os.environ.get(
 OUTPUT_DIR = os.path.join(ROOT, "output")
 
 from wizard import ontologies_store as _store
+
 _store.init_db(ONTOLOGIES_DB)
 
 # Built-in starter templates live in onboard.py's INDUSTRY_TEMPLATES dict
@@ -70,8 +71,9 @@ except Exception:
     _ONBOARD_TEMPLATES = {}
 
 try:
-    from flask import Flask, request, jsonify, send_file, send_from_directory
+    from flask import Flask, jsonify, request, send_file, send_from_directory
     from flask_cors import CORS
+
     _flask_ok = True
 except ImportError:
     _flask_ok = False
@@ -86,19 +88,19 @@ CORS(app)
 # before/after-request hooks.
 try:
     from wizard.structured_logging import install as _install_logging
+
     _install_logging(app)
-except Exception as _exc:                                              # noqa: BLE001
+except Exception as _exc:  # noqa: BLE001
     # Logging setup must NEVER prevent the wizard from booting.
-    print(f"[wizard.app] structured logging install skipped: {_exc!r}",
-          file=sys.stderr)
+    print(f"[wizard.app] structured logging install skipped: {_exc!r}", file=sys.stderr)
 
 # P3.5 — Prometheus /metrics endpoint.
 try:
     from wizard.metrics_exporter import install as _install_metrics
+
     _install_metrics(app)
-except Exception as _exc:                                              # noqa: BLE001
-    print(f"[wizard.app] metrics install skipped: {_exc!r}",
-          file=sys.stderr)
+except Exception as _exc:  # noqa: BLE001
+    print(f"[wizard.app] metrics install skipped: {_exc!r}", file=sys.stderr)
 
 _pipeline_lock = threading.Lock()
 _pipeline_running = False
@@ -107,6 +109,7 @@ _pipeline_log: list[str] = []
 
 # ── Helpers ────────────────────────────────────────────────────────────────
 
+
 def _now() -> str:
     return datetime.now(timezone.utc).isoformat()
 
@@ -138,6 +141,7 @@ def _save_session(data: dict) -> None:
 
 # ── Routes ─────────────────────────────────────────────────────────────────
 
+
 @app.route("/")
 def landing():
     """P1.2 — Marketing landing page.
@@ -153,7 +157,8 @@ def landing():
     is missing or stale, the landing falls back to a "see how it
     works" tagline instead of inventing numbers.
     """
-    from flask import render_template, redirect, request
+    from flask import redirect, render_template, request
+
     if request.args.get("step"):
         return redirect("/wizard?" + request.query_string.decode("utf-8"), code=301)
     bench = _load_benchmark()
@@ -184,6 +189,7 @@ def _load_benchmark() -> dict:
 def wizard():
     """The interactive wizard — what used to live at ``/``."""
     from flask import render_template
+
     return render_template("index.html", search_enabled=ONTOFORGE_SEARCH)
 
 
@@ -197,6 +203,7 @@ def projects():
     can jump straight from the marketing landing to "their work."
     """
     from flask import render_template
+
     return render_template("projects.html")
 
 
@@ -206,6 +213,7 @@ def _legacy_index():
     Send them to the wizard so deep-linking from external docs still
     works after the route reshuffle."""
     from flask import redirect, request
+
     qs = request.query_string.decode("utf-8")
     target = "/wizard" + ("?" + qs if qs else "")
     return redirect(target, code=301)
@@ -231,11 +239,13 @@ def live():
     Deliberately does NOT touch the DB or Redis — a pod with a
     broken DB connection is STILL alive and should NOT be killed
     (the restart loop wouldn't help; the DB is the problem)."""
-    return jsonify({
-        "status":    "alive",
-        "version":   _version_string(),
-        "timestamp": _now(),
-    })
+    return jsonify(
+        {
+            "status": "alive",
+            "version": _version_string(),
+            "timestamp": _now(),
+        }
+    )
 
 
 @app.route("/ready")
@@ -259,7 +269,7 @@ def ready():
     try:
         _store.list_ontologies(ONTOLOGIES_DB)
         checks["store"] = {"ok": True, "backend": _store_backend_name()}
-    except Exception as exc:                                          # noqa: BLE001
+    except Exception as exc:  # noqa: BLE001
         checks["store"] = {"ok": False, "error": str(exc)[:200]}
         overall_ok = False
 
@@ -267,21 +277,23 @@ def ready():
     try:
         if "_src" not in dir():
             import sys as _sys
+
             _src = os.path.join(ROOT, "src")
             if _src not in _sys.path:
                 _sys.path.insert(0, _src)
-        from events_bus import get_bus                                # noqa: E402
+        from events_bus import get_bus
+
         stats = get_bus().stats
         checks["events"] = {"ok": True, "backend": stats.get("backend", "unknown")}
-    except Exception as exc:                                          # noqa: BLE001
+    except Exception as exc:  # noqa: BLE001
         checks["events"] = {"ok": False, "error": str(exc)[:200]}
         overall_ok = False
 
     response = {
-        "status":     "ready" if overall_ok else "not_ready",
-        "checks":     checks,
-        "version":    _version_string(),
-        "timestamp":  _now(),
+        "status": "ready" if overall_ok else "not_ready",
+        "checks": checks,
+        "version": _version_string(),
+        "timestamp": _now(),
     }
     return jsonify(response), (200 if overall_ok else 503)
 
@@ -290,9 +302,10 @@ def _version_string() -> str:
     try:
         if HERE not in sys.path:
             sys.path.insert(0, HERE)
-        from ontoforge import __version__                              # noqa: E402
+        from ontoforge import __version__
+
         return __version__
-    except Exception:                                                 # noqa: BLE001
+    except Exception:  # noqa: BLE001
         return "unknown"
 
 
@@ -308,27 +321,29 @@ def _store_backend_name() -> str:
 
 
 @app.errorhandler(404)
-def _not_found(e):                                                  # noqa: ARG001
-    from flask import render_template as _rt                        # noqa: E402
+def _not_found(e):
+    from flask import render_template as _rt
+
     return _rt(
         "error.html",
         code="404",
         title="Page not found",
         message="That page isn't here. Maybe it moved during the rename "
-                "to Ontomesh, or you followed a stale link.",
+        "to Ontomesh, or you followed a stale link.",
     ), 404
 
 
 @app.errorhandler(500)
-def _server_error(e):                                               # noqa: ARG001
-    from flask import render_template as _rt                        # noqa: E402
+def _server_error(e):
+    from flask import render_template as _rt
+
     return _rt(
         "error.html",
         code="500",
         title="Something broke",
         message="An unexpected error stopped the request. Check the "
-                "server logs, then try again — your session data is "
-                "intact.",
+        "server logs, then try again — your session data is "
+        "intact.",
     ), 500
 
 
@@ -345,13 +360,15 @@ def events_stream():
     (nginx, gunicorn) don't close the connection.
     """
     from flask import Response, stream_with_context
+
     try:
         import sys as _sys
+
         _src = os.path.join(ROOT, "src")
         if _src not in _sys.path:
             _sys.path.insert(0, _src)
-        from events_bus import get_bus                              # noqa: E402
-    except Exception as exc:                                        # noqa: BLE001
+        from events_bus import get_bus
+    except Exception as exc:  # noqa: BLE001
         return jsonify({"error": f"bus unavailable: {exc}"}), 500
 
     bus = get_bus()
@@ -360,8 +377,7 @@ def events_stream():
     def _generate():
         # Hello packet so the client knows the connection is live
         # and which subscriber id it's bound to (useful in dev tools).
-        yield (f"event: hello\n"
-               f"data: {json.dumps({'subscriber_id': sub.id})}\n\n")
+        yield (f"event: hello\ndata: {json.dumps({'subscriber_id': sub.id})}\n\n")
         try:
             while True:
                 event = sub.get(timeout=20.0)
@@ -370,17 +386,15 @@ def events_stream():
                     yield ": ping\n\n"
                     continue
                 kind = event.get("kind", "message")
-                yield (f"event: {kind}\n"
-                       f"data: {json.dumps(event)}\n\n")
+                yield (f"event: {kind}\ndata: {json.dumps(event)}\n\n")
         except GeneratorExit:
             pass
         finally:
             bus.unsubscribe(sub)
 
-    response = Response(stream_with_context(_generate()),
-                        mimetype="text/event-stream")
+    response = Response(stream_with_context(_generate()), mimetype="text/event-stream")
     response.headers["Cache-Control"] = "no-cache"
-    response.headers["X-Accel-Buffering"] = "no"      # nginx hint
+    response.headers["X-Accel-Buffering"] = "no"  # nginx hint
     return response
 
 
@@ -390,11 +404,12 @@ def events_stats():
     is alive and how many subscribers / events have flowed."""
     try:
         import sys as _sys
+
         _src = os.path.join(ROOT, "src")
         if _src not in _sys.path:
             _sys.path.insert(0, _src)
-        from events_bus import get_bus                              # noqa: E402
-    except Exception:                                               # noqa: BLE001
+        from events_bus import get_bus
+    except Exception:  # noqa: BLE001
         return jsonify({"available": False})
     return jsonify({"available": True, **get_bus().stats})
 
@@ -405,7 +420,8 @@ def log_discovery_help():
     benefits, and the user-facing workflow. Linked from the Step 5
     panel header."""
     return send_from_directory(
-        os.path.join(HERE, "templates"), "log_discovery_help.html",
+        os.path.join(HERE, "templates"),
+        "log_discovery_help.html",
     )
 
 
@@ -421,14 +437,16 @@ def phase_help(slug):
     ``HELP_PAGES`` dict in ``wizard/help_content.py``."""
     if HERE not in sys.path:
         sys.path.insert(0, HERE)
-    from help_content import get_help                              # noqa: E402
+    from help_content import get_help
+
     # Log Discovery keeps its bespoke deeper page.
     if slug == "log-discovery":
         return log_discovery_help()
     page = get_help(slug)
     if page is None:
         return ("Unknown phase: " + slug, 404)
-    from flask import render_template as _rt                       # noqa: E402
+    from flask import render_template as _rt
+
     return _rt("phase_help.html", page=page)
 
 
@@ -437,7 +455,8 @@ def phase_help_index():
     """Redirect /help → first phase help page."""
     if HERE not in sys.path:
         sys.path.insert(0, HERE)
-    from help_content import all_slugs                             # noqa: E402
+    from help_content import all_slugs
+
     slugs = all_slugs()
     first = slugs[0] if slugs else "domain"
     return phase_help(first)
@@ -469,8 +488,14 @@ def _builtin_to_session(name: str, t: dict) -> dict:
     and relationships as 3-tuples; the wizard expects structured records.
     """
     entities = [
-        {"name": _to_snake(label), "label": label, "description": "",
-         "sensitivity": "Internal", "is_event": False, "properties": []}
+        {
+            "name": _to_snake(label),
+            "label": label,
+            "description": "",
+            "sensitivity": "Internal",
+            "is_event": False,
+            "properties": [],
+        }
         for label in t.get("entities", [])
     ]
     events = [
@@ -482,7 +507,7 @@ def _builtin_to_session(name: str, t: dict) -> dict:
         for (frm, lbl, to) in t.get("relationships", [])
     ]
     cqs = [
-        {"id": f"CQ-{i+1:02d}", "question": q, "priority": "Medium"}
+        {"id": f"CQ-{i + 1:02d}", "question": q, "priority": "Medium"}
         for i, q in enumerate(t.get("cqs", []))
     ]
     return {
@@ -547,6 +572,7 @@ def _parse_relationship_sentence(text: str, labels: list) -> dict | None:
             if last is None or jend > last[2]:
                 last = (target, j, jend)
         return first, last
+
     first, last = _scan(s)
     # Retry case-insensitively if either side is missing (not on disagreement).
     if not first or not last:
@@ -558,13 +584,30 @@ def _parse_relationship_sentence(text: str, labels: list) -> dict | None:
         # Single occurrence of one alias only; treat as a self-reference if
         # the entity itself was found, otherwise un-parseable.
         if first[0] == last[0]:
-            verb = (s.split(first[0], 1)[1].strip().lstrip(",;:")
-                    if first[0] in s else "related to")
-            verb = re.sub(r"^(?:is|are|may\s+be|can\s+be)\s+", "", verb).rstrip(",;:.").strip()
-            verb = re.split(r"\s+(?:to|with)?\s*another\s+", verb)[0].strip() or "related to"
-            return {"from_entity": first[0], "label": verb or "related to", "to_entity": first[0]}
+            verb = (
+                s.split(first[0], 1)[1].strip().lstrip(",;:")
+                if first[0] in s
+                else "related to"
+            )
+            verb = (
+                re.sub(r"^(?:is|are|may\s+be|can\s+be)\s+", "", verb)
+                .rstrip(",;:.")
+                .strip()
+            )
+            verb = (
+                re.split(r"\s+(?:to|with)?\s*another\s+", verb)[0].strip()
+                or "related to"
+            )
+            return {
+                "from_entity": first[0],
+                "label": verb or "related to",
+                "to_entity": first[0],
+            }
         return None
-    verb = s[first[2]:last[1]].strip().lstrip(",;:").rstrip(",;:").strip() or "related to"
+    verb = (
+        s[first[2] : last[1]].strip().lstrip(",;:").rstrip(",;:").strip()
+        or "related to"
+    )
     # Strip leading articles ("is", "are", "may be") that read awkwardly as
     # an OWL property label — e.g. "is submitted by" → "submitted by".
     verb = re.sub(r"^(?:is|are|may\s+be|can\s+be)\s+", "", verb)
@@ -576,13 +619,19 @@ def _structure_yaml_relationships(raw: list, entities_yaml: list) -> list:
     structured {from_entity, label, to_entity} dicts the graph view and
     downstream tooling expect. Falls back to the original entry when a
     sentence can't be parsed — keeps human content visible."""
-    labels = [(e.get("label") or e.get("name", "")).strip() for e in (entities_yaml or [])]
+    labels = [
+        (e.get("label") or e.get("name", "")).strip() for e in (entities_yaml or [])
+    ]
     out = []
-    for r in (raw or []):
+    for r in raw or []:
         if isinstance(r, dict) and r.get("from_entity") and r.get("to_entity"):
-            out.append({"from_entity": r["from_entity"],
-                        "label":       r.get("label", "related to"),
-                        "to_entity":   r["to_entity"]})
+            out.append(
+                {
+                    "from_entity": r["from_entity"],
+                    "label": r.get("label", "related to"),
+                    "to_entity": r["to_entity"],
+                }
+            )
             continue
         if isinstance(r, (list, tuple)) and len(r) == 3:
             out.append({"from_entity": r[0], "label": r[1], "to_entity": r[2]})
@@ -615,9 +664,17 @@ def _yaml_to_session(name: str, tmpl: dict) -> dict:
                 "sensitivity": e.get("sensitivity", "Internal"),
                 "is_event": e.get("is_event", False),
                 "properties": [
-                    {"name": pn,
-                     "type": (pv.get("type", "string") if isinstance(pv, dict) else "string"),
-                     "required": (pv.get("required", False) if isinstance(pv, dict) else False)}
+                    {
+                        "name": pn,
+                        "type": (
+                            pv.get("type", "string")
+                            if isinstance(pv, dict)
+                            else "string"
+                        ),
+                        "required": (
+                            pv.get("required", False) if isinstance(pv, dict) else False
+                        ),
+                    }
                     for item in (e.get("properties") or [])
                     for pn, pv in (item.items() if isinstance(item, dict) else [])
                 ],
@@ -625,8 +682,11 @@ def _yaml_to_session(name: str, tmpl: dict) -> dict:
             for e in tmpl.get("entities", [])
         ],
         "events": [
-            {"name": ev["name"], "label": ev.get("label", ev["name"]),
-             "description": ev.get("description", "")}
+            {
+                "name": ev["name"],
+                "label": ev.get("label", ev["name"]),
+                "description": ev.get("description", ""),
+            }
             for ev in tmpl.get("events", [])
         ],
         "relationships": _structure_yaml_relationships(
@@ -634,8 +694,11 @@ def _yaml_to_session(name: str, tmpl: dict) -> dict:
             tmpl.get("entities", []),
         ),
         "competency_questions": [
-            {"id": cq.get("id", ""), "question": cq.get("question", ""),
-             "priority": cq.get("priority", "Medium")}
+            {
+                "id": cq.get("id", ""),
+                "question": cq.get("question", ""),
+                "priority": cq.get("priority", "Medium"),
+            }
             for cq in tmpl.get("competency_questions", [])
         ],
         "created_at": _now(),
@@ -650,7 +713,9 @@ def list_templates():
         for fname in sorted(os.listdir(TEMPLATES_DIR)):
             if fname.endswith((".yaml", ".yml")):
                 yaml_names.append(fname.rsplit(".", 1)[0])
-    builtin = list(_ONBOARD_TEMPLATES.keys())   # telecom, healthcare, finance, manufacturing, retail
+    builtin = list(
+        _ONBOARD_TEMPLATES.keys()
+    )  # telecom, healthcare, finance, manufacturing, retail
     # Preserve order, drop duplicates if a YAML happens to share a name with a builtin.
     seen: set[str] = set()
     out: list[str] = []
@@ -680,12 +745,14 @@ def list_templates():
     # whitelist) so existing UI code that reads it keeps working
     # until it's migrated.
     hidden = [n for n in out if n not in visible_set]
-    return jsonify({
-        "templates": visible,
-        "visible":   visible,           # canonical key going forward
-        "hidden":    sorted(hidden),    # legacy key
-        "all":       out,
-    })
+    return jsonify(
+        {
+            "templates": visible,
+            "visible": visible,  # canonical key going forward
+            "hidden": sorted(hidden),  # legacy key
+            "all": out,
+        }
+    )
 
 
 @app.route("/api/template/<name>", methods=["GET"])
@@ -731,10 +798,12 @@ def import_file():
     except ImportError:
         # Allow flat-import fallback if /wizard isn't a package context.
         sys.path.insert(0, HERE)
-        import importer as _imp                  # type: ignore[no-redef]
+        import importer as _imp  # type: ignore[no-redef]
 
     raw: bytes = b""
-    fmt = "auto"; dialect = "auto"; filename = None
+    fmt = "auto"
+    dialect = "auto"
+    filename = None
     if request.files and "file" in request.files:
         f = request.files["file"]
         raw = f.read()
@@ -754,12 +823,19 @@ def import_file():
         filename = body.get("filename")
 
     if not raw:
-        return jsonify({"error": "No file or content supplied (POST a multipart 'file' or a JSON body with 'content')."}), 400
+        return jsonify(
+            {
+                "error": "No file or content supplied (POST a multipart 'file' or a JSON body with 'content')."
+            }
+        ), 400
 
     existing = _load_session()
     result = _imp.parse_and_validate(
-        raw, fmt=fmt, dialect=dialect,
-        existing_session=existing, filename=filename,
+        raw,
+        fmt=fmt,
+        dialect=dialect,
+        existing_session=existing,
+        filename=filename,
     )
     return jsonify(result.to_dict()), (200 if result.ok or result.session else 200)
 
@@ -775,7 +851,7 @@ def import_commit():
         from . import importer as _imp
     except ImportError:
         sys.path.insert(0, HERE)
-        import importer as _imp                  # type: ignore[no-redef]
+        import importer as _imp  # type: ignore[no-redef]
 
     body = request.get_json(force=True) or {}
     session = body.get("session")
@@ -786,15 +862,22 @@ def import_commit():
     raw = json.dumps(session).encode("utf-8")
     result = _imp.parse_and_validate(raw, fmt="json", existing_session=_load_session())
     if not result.ok:
-        return jsonify({
-            "error": "Validation failed at commit time",
-            "errors": [i.to_dict() for i in result.errors],
-        }), 400
+        return jsonify(
+            {
+                "error": "Validation failed at commit time",
+                "errors": [i.to_dict() for i in result.errors],
+            }
+        ), 400
 
     _save_session(result.session)
-    return jsonify({"ok": True, "session": result.session,
-                    "warnings": [i.to_dict() for i in result.warnings],
-                    "stats": result.stats})
+    return jsonify(
+        {
+            "ok": True,
+            "session": result.session,
+            "warnings": [i.to_dict() for i in result.warnings],
+            "stats": result.stats,
+        }
+    )
 
 
 # ── /api/db — database-direct import + connection profiles ───────────────
@@ -809,6 +892,7 @@ def import_commit():
 
 def _db_conn():
     import sqlite3 as _sqlite3
+
     return _sqlite3.connect(ONTOLOGIES_DB)
 
 
@@ -818,7 +902,7 @@ def _load_db_profiles_module():
         from . import db_profiles as _dp
     except ImportError:
         sys.path.insert(0, HERE)
-        import db_profiles as _dp                    # type: ignore[no-redef]
+        import db_profiles as _dp  # type: ignore[no-redef]
     return _dp
 
 
@@ -860,12 +944,15 @@ def db_profile_save():
     conn = _db_conn()
     try:
         profile = dp.save_profile(
-            conn, name=name, vendor=vendor, config=config,
+            conn,
+            name=name,
+            vendor=vendor,
+            config=config,
             profile_id=int(pid) if pid else None,
         )
     except ValueError as exc:
         return jsonify({"error": str(exc)}), 400
-    except Exception as exc:                          # noqa: BLE001
+    except Exception as exc:  # noqa: BLE001
         return jsonify({"error": f"save failed: {exc}"}), 500
     finally:
         conn.close()
@@ -942,19 +1029,30 @@ def db_import():
 
     try:
         session = dp.introspect_to_session(
-            vendor, config,
+            vendor,
+            config,
             domain_name=(body.get("domain_name") or "").strip(),
             base_iri=(body.get("base_iri") or "").strip(),
         )
     except RuntimeError as exc:
-        return jsonify({
-            "ok": False, "format": "database",
-            "errors": [{"code": "DB_INTROSPECT_FAILED", "severity": "error",
+        return jsonify(
+            {
+                "ok": False,
+                "format": "database",
+                "errors": [
+                    {
+                        "code": "DB_INTROSPECT_FAILED",
+                        "severity": "error",
                         "message": str(exc),
                         "fix_hint": "Verify host, port, credentials, and that "
-                                    "the user can list tables."}],
-            "warnings": [], "stats": {}, "session": None,
-        })
+                        "the user can list tables.",
+                    }
+                ],
+                "warnings": [],
+                "stats": {},
+                "session": None,
+            }
+        )
 
     # Shape-compatible with /api/import so the review modal can
     # consume it without branching.
@@ -963,12 +1061,16 @@ def db_import():
         "relationships": len(session.get("relationships") or []),
         "events": len(session.get("events") or []),
     }
-    return jsonify({
-        "ok": True, "format": "database",
-        "errors": [], "warnings": [],
-        "stats": stats,
-        "session": session,
-    })
+    return jsonify(
+        {
+            "ok": True,
+            "format": "database",
+            "errors": [],
+            "warnings": [],
+            "stats": stats,
+            "session": session,
+        }
+    )
 
 
 @app.route("/api/generate", methods=["POST"])
@@ -1010,7 +1112,7 @@ def generate():
 
 # ── Phase C — Rules step ─────────────────────────────────────────────────
 
-from wizard import rules as _rules_mod  # noqa: E402
+from wizard import rules as _rules_mod
 
 _RULES_LIBRARY_DIR = os.path.join(ROOT, "templates", "rules")
 
@@ -1063,9 +1165,11 @@ def summarise_rule_route():
     if not rule.get("body"):
         return jsonify({"error": "rule body is empty"}), 400
     from runtime.insights import summarise_rule
+
     try:
-        summary = summarise_rule(rule, provider=body.get("provider"),
-                                 model=body.get("model"))
+        summary = summarise_rule(
+            rule, provider=body.get("provider"), model=body.get("model")
+        )
     except Exception as exc:  # noqa: BLE001
         return jsonify({"error": str(exc)}), 502
 
@@ -1096,24 +1200,30 @@ def draft_rule_route():
     accept (or reject) the draft on the client.
     """
     body = request.get_json(force=True) or {}
-    nl   = (body.get("nl") or "").strip()
+    nl = (body.get("nl") or "").strip()
     kind = (body.get("kind") or "shacl").strip().lower()
     if not nl:
         return jsonify({"error": "nl is required"}), 400
 
     # Vocabulary feed — same source the slot-fill builder uses.
     from vocabulary import get_vocabulary
+
     ontology_path = os.path.join(OUTPUT_DIR, "ontology", "enterprise.ttl")
     vocab = get_vocabulary(ontology_path).to_dict()
     if not (vocab.get("classes") or vocab.get("properties")):
-        return jsonify({"error": "No ontology vocabulary available — "
-                                "run --phase 2 first."}), 400
+        return jsonify(
+            {"error": "No ontology vocabulary available — run --phase 2 first."}
+        ), 400
 
     from runtime.insights import draft_rule
+
     try:
         draft = draft_rule(
-            nl=nl, kind=kind, vocabulary=vocab,
-            provider=body.get("provider"), model=body.get("model"),
+            nl=nl,
+            kind=kind,
+            vocabulary=vocab,
+            provider=body.get("provider"),
+            model=body.get("model"),
         )
     except Exception as exc:  # noqa: BLE001
         return jsonify({"error": str(exc)}), 502
@@ -1152,10 +1262,14 @@ def compile_rule():
     """
     body = request.get_json(force=True) or {}
     rule = _rules_mod.normalise_rule(body)
-    return jsonify({
-        "id": rule["id"], "kind": rule["kind"],
-        "body": rule["body"], "meta": rule.get("meta") or {},
-    })
+    return jsonify(
+        {
+            "id": rule["id"],
+            "kind": rule["kind"],
+            "body": rule["body"],
+            "meta": rule.get("meta") or {},
+        }
+    )
 
 
 @app.route("/api/rules/coverage", methods=["GET"])
@@ -1165,6 +1279,7 @@ def rules_coverage():
     rules touch a class.
     """
     from vocabulary import get_vocabulary
+
     ontology_path = os.path.join(OUTPUT_DIR, "ontology", "enterprise.ttl")
     vocab = get_vocabulary(ontology_path).to_dict()
     rules = _load_session().get("rules") or []
@@ -1172,10 +1287,10 @@ def rules_coverage():
     # Convenience aggregates for the UI.
     counts = [c["count"] for c in coverage.values()]
     summary = {
-        "max":   max(counts) if counts else 0,
+        "max": max(counts) if counts else 0,
         "total": sum(counts),
         "covered_classes": sum(1 for n in counts if n > 0),
-        "all_classes":     len(counts),
+        "all_classes": len(counts),
     }
     return jsonify({"coverage": coverage, "summary": summary})
 
@@ -1211,12 +1326,15 @@ def explain_triple_route():
         return jsonify({"error": "subject, predicate, object are required"}), 400
     lineage_path = os.path.join(OUTPUT_DIR, "ontology", "materialised-lineage.ttl")
     from materializer import explain_triple
+
     derivations = explain_triple(lineage_path, subject, predicate, obj)
-    return jsonify({
-        "triple": {"subject": subject, "predicate": predicate, "object": obj},
-        "derivations": derivations,
-        "asserted": len(derivations) == 0,
-    })
+    return jsonify(
+        {
+            "triple": {"subject": subject, "predicate": predicate, "object": obj},
+            "derivations": derivations,
+            "asserted": len(derivations) == 0,
+        }
+    )
 
 
 @app.route("/api/materialised/triples", methods=["GET"])
@@ -1236,8 +1354,11 @@ def list_materialised_triples():
     engine_filter = request.args.get("engine", "").strip().lower()
     rule_filter = request.args.get("rule", "").strip()
 
-    from rdflib import Graph as _G, URIRef as _U
-    from rdflib.namespace import RDF as _RDF, PROV as _PROV
+    from rdflib import Graph as _G
+    from rdflib import URIRef as _U
+    from rdflib.namespace import PROV as _PROV
+    from rdflib.namespace import RDF as _RDF
+
     TOOLKIT_RULE = _U("https://ontology.example.com/toolkit/materializer/rule")
     TOOLKIT_ENGINE = _U("https://ontology.example.com/toolkit/materializer/engine")
 
@@ -1265,10 +1386,15 @@ def list_materialised_triples():
             continue
         if rule_filter and rule_filter not in (rule or ""):
             continue
-        out.append({
-            "subject": str(s), "predicate": str(p), "object": str(o),
-            "rule": rule, "engine": engine,
-        })
+        out.append(
+            {
+                "subject": str(s),
+                "predicate": str(p),
+                "object": str(o),
+                "rule": rule,
+                "engine": engine,
+            }
+        )
         if len(out) >= limit:
             break
     return jsonify({"triples": out, "available": True})
@@ -1284,6 +1410,7 @@ def ontology_vocabulary():
     Cached by mtime — repeat calls reuse the parse on unchanged files.
     """
     from vocabulary import get_vocabulary
+
     ontology_path = os.path.join(OUTPUT_DIR, "ontology", "enterprise.ttl")
     vocab = get_vocabulary(ontology_path)
     return jsonify(vocab.to_dict())
@@ -1298,6 +1425,7 @@ def insights_providers():
     to populate the Settings → Providers panel.
     """
     from runtime.insights import provider_status
+
     return jsonify({"providers": [p.to_dict() for p in provider_status()]})
 
 
@@ -1306,6 +1434,7 @@ def insights_rca_presets():
     """List RCA prompt presets — keyed by name with the template
     string. The wizard renders them in the Ask Insights panel."""
     from runtime.insights import list_rca_presets
+
     return jsonify({"presets": list_rca_presets()})
 
 
@@ -1323,6 +1452,7 @@ def insights_rca():
     from :class:`Insights.ask` still fires for public-cloud providers.
     """
     from runtime.insights import Insights, expand_rca_preset
+
     body = request.get_json(force=True) or {}
     preset = (body.get("preset") or "").strip()
     event_iri = (body.get("event_iri") or "").strip()
@@ -1346,9 +1476,9 @@ def insights_rca():
             question,
             provider=body.get("provider"),
             model=body.get("model"),
-            include_materialised=True,    # RCA needs the inferred graph
+            include_materialised=True,  # RCA needs the inferred graph
         )
-    except Exception as exc:                # noqa: BLE001
+    except Exception as exc:  # noqa: BLE001
         return jsonify({"error": str(exc)}), 502
     out = result.to_dict()
     out["preset"] = preset
@@ -1359,12 +1489,12 @@ def insights_rca():
 @app.route("/api/insights/ask", methods=["POST"])
 def insights_ask():
     """Answer a question grounded in the active ontology. Body:
-        {
-          "question": "...",
-          "provider": "openai" | "ollama" | ... (optional),
-          "model": "gpt-4o" (optional),
-          "include_materialised": false
-        }
+    {
+      "question": "...",
+      "provider": "openai" | "ollama" | ... (optional),
+      "model": "gpt-4o" (optional),
+      "include_materialised": false
+    }
     """
     body = request.get_json(force=True) or {}
     question = (body.get("question") or "").strip()
@@ -1377,6 +1507,7 @@ def insights_ask():
         return jsonify({"error": "no ontology — run --phase 2 first"}), 400
 
     from runtime.insights import Insights
+
     insights = Insights(
         ontology_path,
         materialised_path if os.path.isfile(materialised_path) else None,
@@ -1402,20 +1533,23 @@ _REVIEW_RANKER_PATH = os.path.join(ROOT, "db", "review_ranker.pkl")
 
 def _log_review_conn():
     import sqlite3 as _sqlite3
+
     conn = _sqlite3.connect(_ENTERPRISE_DB)
     # Ensure L9 (and reserved L8) tables exist whenever the wizard
     # opens the proposal store. Cheap — idempotent IF NOT EXISTS.
     try:
         from db.migrations.log_discovery_v2 import migrate as _v2_migrate
+
         _v2_migrate(conn)
-    except Exception:                                      # noqa: BLE001
+    except Exception:  # noqa: BLE001
         pass
     # T1.1 — name_source / name_generated_at columns for the LLM
     # naming pass. Additive nullable, no-op on re-run.
     try:
         from db.migrations.v3_proposal_namer import migrate as _v3_migrate
+
         _v3_migrate(conn)
-    except Exception:                                      # noqa: BLE001
+    except Exception:  # noqa: BLE001
         pass
     return conn
 
@@ -1425,8 +1559,9 @@ def _load_review_ranker():
     unloadable — callers degrade to SQL-default ordering."""
     try:
         from wizard.review_ranker import ReviewRanker
+
         return ReviewRanker.load_or_none(_REVIEW_RANKER_PATH)
-    except Exception:                                      # noqa: BLE001
+    except Exception:  # noqa: BLE001
         return None
 
 
@@ -1434,11 +1569,13 @@ def _load_review_ranker():
 def log_discovery_summary():
     """Headline counts per kind/status. Used by the Log Discovery
     sidebar entry to show how many proposals await review."""
-    import sqlite3
+
     from wizard import log_review
+
     if not os.path.isfile(_ENTERPRISE_DB):
-        return jsonify({"available": False,
-                        "reason": "no enterprise.db — run --phase mine first"})
+        return jsonify(
+            {"available": False, "reason": "no enterprise.db — run --phase mine first"}
+        )
     conn = _log_review_conn()
     try:
         out = log_review.summary(conn)
@@ -1451,6 +1588,7 @@ def log_discovery_summary():
 def log_discovery_candidates():
     """List candidates. Query params: kind, status, limit."""
     from wizard import log_review
+
     if not os.path.isfile(_ENTERPRISE_DB):
         return jsonify({"candidates": [], "available": False})
     kind = request.args.get("kind") or None
@@ -1463,14 +1601,17 @@ def log_discovery_candidates():
     ranker = _load_review_ranker()
     try:
         cands = log_review.list_candidates(
-            conn, kind=kind, status=status, limit=limit, ranker=ranker)
+            conn, kind=kind, status=status, limit=limit, ranker=ranker
+        )
     finally:
         conn.close()
-    return jsonify({
-        "candidates": cands,
-        "available": True,
-        "ranked": bool(ranker and ranker.is_fitted()),
-    })
+    return jsonify(
+        {
+            "candidates": cands,
+            "available": True,
+            "ranked": bool(ranker and ranker.is_fitted()),
+        }
+    )
 
 
 @app.route("/api/log-discovery/seed", methods=["POST"])
@@ -1486,6 +1627,7 @@ def log_discovery_seed():
     edges → causal proposals, no statistical gating).
     """
     from wizard import log_review
+
     if not os.path.isfile(_ENTERPRISE_DB):
         return jsonify({"error": "no enterprise.db — run --phase mine first"}), 400
     body = request.get_json(silent=True) or {}
@@ -1495,15 +1637,19 @@ def log_discovery_seed():
         try:
             from log_corpus import LogCorpus
             from log_templates import LogTemplateMiner
+
             miner = LogTemplateMiner(_log_review_conn())
             for rec in LogCorpus(log_path).iter():
-                miner.consume(rec.message, timestamp=rec.timestamp,
-                              severity=rec.severity,
-                              service=rec.fields.get("service") if rec.fields else None,
-                              trace_id=rec.fields.get("trace_id") if rec.fields else None)
+                miner.consume(
+                    rec.message,
+                    timestamp=rec.timestamp,
+                    severity=rec.severity,
+                    service=rec.fields.get("service") if rec.fields else None,
+                    trace_id=rec.fields.get("trace_id") if rec.fields else None,
+                )
             miner.flush()
             extractions = miner.extractions
-        except Exception:                       # noqa: BLE001 — fall back to L1-only
+        except Exception:  # noqa: BLE001 — fall back to L1-only
             extractions = None
 
     conn = _log_review_conn()
@@ -1511,13 +1657,13 @@ def log_discovery_seed():
         counts = log_review.seed_from_mining(conn, extractions=extractions)
     finally:
         conn.close()
-    return jsonify({"ok": True, "counts": counts,
-                    "triangulation": bool(extractions)})
+    return jsonify({"ok": True, "counts": counts, "triangulation": bool(extractions)})
 
 
 @app.route("/api/log-discovery/<proposal_id>/approve", methods=["POST"])
 def log_discovery_approve(proposal_id):
     from wizard import log_review
+
     body = request.get_json(force=True) or {}
     edits = body.get("edits") or {}
     session = _load_session()
@@ -1535,6 +1681,7 @@ def log_discovery_approve(proposal_id):
 @app.route("/api/log-discovery/<proposal_id>/reject", methods=["POST"])
 def log_discovery_reject(proposal_id):
     from wizard import log_review
+
     body = request.get_json(force=True) or {}
     note = (body.get("note") or "").strip()
     conn = _log_review_conn()
@@ -1548,6 +1695,7 @@ def log_discovery_reject(proposal_id):
 @app.route("/api/log-discovery/<proposal_id>/merge", methods=["POST"])
 def log_discovery_merge(proposal_id):
     from wizard import log_review
+
     body = request.get_json(force=True) or {}
     into = (body.get("into") or "").strip()
     if not into:
@@ -1580,20 +1728,23 @@ def log_discovery_llm_rename():
         return jsonify({"error": "no enterprise.db — run --phase mine first"}), 400
     try:
         from wizard.proposal_namer import (
-            get_provider, rename_pending_proposals,
+            get_provider,
+            rename_pending_proposals,
         )
-    except Exception as exc:                                       # noqa: BLE001
+    except Exception as exc:  # noqa: BLE001
         return jsonify({"error": f"namer module unavailable: {exc}"}), 500
     provider = get_provider()
     if provider is None:
-        return jsonify({
-            "ok": True,
-            "skipped": True,
-            "reason": (
-                "no provider configured — set PROPOSAL_NAMER_PROVIDER "
-                "(mock|anthropic|openai) and the matching API key"
-            ),
-        })
+        return jsonify(
+            {
+                "ok": True,
+                "skipped": True,
+                "reason": (
+                    "no provider configured — set PROPOSAL_NAMER_PROVIDER "
+                    "(mock|anthropic|openai) and the matching API key"
+                ),
+            }
+        )
     body = request.get_json(silent=True) or {}
     force = bool(body.get("force", False))
     try:
@@ -1603,7 +1754,10 @@ def log_discovery_llm_rename():
     conn = _log_review_conn()
     try:
         stats = rename_pending_proposals(
-            conn, provider=provider, force=force, limit=limit,
+            conn,
+            provider=provider,
+            force=force,
+            limit=limit,
         )
     finally:
         conn.close()
@@ -1619,14 +1773,15 @@ def log_discovery_llm_rename_status():
         return jsonify({"available": False, "reason": "no enterprise.db"})
     try:
         from wizard.proposal_namer import get_provider
-    except Exception:                                              # noqa: BLE001
+    except Exception:  # noqa: BLE001
         return jsonify({"available": False, "reason": "import"})
     provider = get_provider()
     conn = _log_review_conn()
     try:
-        cols = {r[1] for r in conn.execute(
-            "PRAGMA table_info(ontology_evolution_proposals)"
-        )}
+        cols = {
+            r[1]
+            for r in conn.execute("PRAGMA table_info(ontology_evolution_proposals)")
+        }
         if "name_source" not in cols:
             return jsonify({"available": False, "reason": "v3 migration"})
         auto_count = conn.execute(
@@ -1639,12 +1794,14 @@ def log_discovery_llm_rename_status():
         ).fetchone()[0]
     finally:
         conn.close()
-    return jsonify({
-        "available": True,
-        "provider":  provider.name if provider else "none",
-        "auto_pending": int(auto_count),
-        "llm_named":    int(llm_count),
-    })
+    return jsonify(
+        {
+            "available": True,
+            "provider": provider.name if provider else "none",
+            "auto_pending": int(auto_count),
+            "llm_named": int(llm_count),
+        }
+    )
 
 
 @app.route("/api/log-discovery/rate-anomalies", methods=["POST"])
@@ -1661,11 +1818,12 @@ def log_discovery_rate_anomalies():
         return jsonify({"error": "no enterprise.db — run --phase mine first"}), 400
     try:
         import sys as _sys
+
         _src = os.path.join(ROOT, "src")
         if _src not in _sys.path:
             _sys.path.insert(0, _src)
-        from log_rate_anomalies import mine_rate_anomalies          # noqa: E402
-    except Exception as exc:                                        # noqa: BLE001
+        from log_rate_anomalies import mine_rate_anomalies
+    except Exception as exc:  # noqa: BLE001
         return jsonify({"error": f"module unavailable: {exc}"}), 500
 
     body = request.get_json(silent=True) or {}
@@ -1673,27 +1831,42 @@ def log_discovery_rate_anomalies():
     extractions = []
     if log_path:
         try:
-            from log_corpus import LogCorpus                        # noqa: E402
-            from log_templates import LogTemplateMiner              # noqa: E402
+            from log_corpus import LogCorpus
+            from log_templates import LogTemplateMiner
+
             miner = LogTemplateMiner(_log_review_conn())
             for rec in LogCorpus(log_path).iter():
-                miner.consume(rec.message, timestamp=rec.timestamp,
-                              severity=rec.severity,
-                              service=rec.fields.get("service") if rec.fields else None,
-                              trace_id=rec.fields.get("trace_id") if rec.fields else None)
+                miner.consume(
+                    rec.message,
+                    timestamp=rec.timestamp,
+                    severity=rec.severity,
+                    service=rec.fields.get("service") if rec.fields else None,
+                    trace_id=rec.fields.get("trace_id") if rec.fields else None,
+                )
             miner.flush()
             extractions = list(miner.extractions or [])
-        except Exception:                                           # noqa: BLE001
+        except Exception:  # noqa: BLE001
             extractions = []
 
     conn = _log_review_conn()
     try:
-        report = mine_rate_anomalies(extractions, conn) if extractions \
-                 else type("R", (), {"as_dict": lambda self: {
-                     "templates_examined": 0, "templates_fit": 0,
-                     "anomalies": 0, "proposals_persisted": 0,
-                     "duration_s": 0.0,
-                 }})()
+        report = (
+            mine_rate_anomalies(extractions, conn)
+            if extractions
+            else type(
+                "R",
+                (),
+                {
+                    "as_dict": lambda self: {
+                        "templates_examined": 0,
+                        "templates_fit": 0,
+                        "anomalies": 0,
+                        "proposals_persisted": 0,
+                        "duration_s": 0.0,
+                    }
+                },
+            )()
+        )
     finally:
         conn.close()
     return jsonify({"ok": True, "report": report.as_dict()})
@@ -1710,15 +1883,17 @@ def log_discovery_template_embedding():
     sklearn missing) returns ``{'available': False, 'reason': '...'}``
     so the UI degrades gracefully — no scatter, no merge list."""
     if not os.path.isfile(_ENTERPRISE_DB):
-        return jsonify({"available": False,
-                        "reason": "no enterprise.db — run --phase mine first"})
+        return jsonify(
+            {"available": False, "reason": "no enterprise.db — run --phase mine first"}
+        )
     try:
         import sys as _sys
+
         _src = os.path.join(ROOT, "src")
         if _src not in _sys.path:
             _sys.path.insert(0, _src)
-        from log_templates_embed import TemplateEmbedder         # noqa: E402
-    except Exception as exc:                                     # noqa: BLE001
+        from log_templates_embed import TemplateEmbedder
+    except Exception as exc:  # noqa: BLE001
         return jsonify({"available": False, "reason": f"import: {exc}"})
     conn = _log_review_conn()
     try:
@@ -1743,7 +1918,7 @@ def log_discovery_rerank():
         return jsonify({"error": "no enterprise.db — run --phase mine first"}), 400
     try:
         from wizard.review_ranker import fit_from_conn
-    except Exception as exc:                               # noqa: BLE001
+    except Exception as exc:  # noqa: BLE001
         return jsonify({"error": f"ranker module unavailable: {exc}"}), 500
     conn = _log_review_conn()
     try:
@@ -1761,7 +1936,7 @@ def log_discovery_ranker_status():
         return jsonify({"fitted": False, "reason": "no enterprise.db"})
     try:
         from wizard.review_ranker import latest_meta
-    except Exception:                                      # noqa: BLE001
+    except Exception:  # noqa: BLE001
         return jsonify({"fitted": False, "reason": "ranker module unavailable"})
     conn = _log_review_conn()
     try:
@@ -1775,15 +1950,18 @@ def log_discovery_ranker_status():
 
 @app.route("/api/pipeline/status", methods=["GET"])
 def pipeline_status():
-    return jsonify({
-        "running": _pipeline_running,
-        "log_lines": len(_pipeline_log),
-        "last_lines": _pipeline_log[-50:] if _pipeline_log else [],
-    })
+    return jsonify(
+        {
+            "running": _pipeline_running,
+            "log_lines": len(_pipeline_log),
+            "last_lines": _pipeline_log[-50:] if _pipeline_log else [],
+        }
+    )
 
 
 # ── Saved Ontologies (Library + Viewer) ───────────────────────────────────
 
+
 @app.route("/api/ontologies", methods=["GET"])
 def list_saved_ontologies():
     return jsonify({"ontologies": _store.list_ontologies(ONTOLOGIES_DB)})
@@ -1792,9 +1970,9 @@ def list_saved_ontologies():
 @app.route("/api/ontologies", methods=["POST"])
 def save_saved_ontology():
     body = request.get_json(force=True) or {}
-    domain  = (body.get("domain")  or "").strip()
+    domain = (body.get("domain") or "").strip()
     product = (body.get("product") or "").strip()
-    label   = (body.get("label")   or "").strip()
+    label = (body.get("label") or "").strip()
     if not (domain and product and label):
         return jsonify({"error": "domain, product, and label are required"}), 400
 
@@ -1810,8 +1988,11 @@ def save_saved_ontology():
     try:
         result = _store.save_ontology(
             ONTOLOGIES_DB,
-            domain=domain, product=product, label=label,
-            session=session_payload, generated=generated,
+            domain=domain,
+            product=product,
+            label=label,
+            session=session_payload,
+            generated=generated,
             overwrite=overwrite,
         )
     except FileExistsError as exc:
@@ -1858,6 +2039,7 @@ def load_saved_ontology(slug: str):
 
 # ── Preferences (domain visibility, etc.) ─────────────────────────────────
 
+
 @app.route("/api/preferences", methods=["GET"])
 def get_preferences():
     return jsonify(_store.get_preferences(ONTOLOGIES_DB))
@@ -1875,7 +2057,15 @@ def put_preferences():
 def list_output():
     out_dir = os.path.join(ROOT, "output")
     result: dict[str, list[str]] = {}
-    for sub in ("ontology", "shapes", "vocab", "jsonld", "mapping", "reports", "security"):
+    for sub in (
+        "ontology",
+        "shapes",
+        "vocab",
+        "jsonld",
+        "mapping",
+        "reports",
+        "security",
+    ):
         d = os.path.join(out_dir, sub)
         if os.path.isdir(d):
             result[sub] = sorted(os.listdir(d))
@@ -1904,6 +2094,7 @@ def evolve_list_proposals():
 @app.route("/api/evolve/proposals/<proposal_id>", methods=["GET"])
 def evolve_get_proposal(proposal_id: str):
     from evolution_reviewer import get_proposal
+
     p = get_proposal(_DB_PATH, proposal_id)
     if not p:
         return jsonify({"error": "not found"}), 404
@@ -1913,6 +2104,7 @@ def evolve_get_proposal(proposal_id: str):
 @app.route("/api/evolve/proposals/<proposal_id>/decision", methods=["POST"])
 def evolve_record_decision(proposal_id: str):
     from evolution_reviewer import record_decision
+
     body = request.get_json(force=True) or {}
     action = body.get("action", "").upper()
     if action not in ("APPROVE", "REJECT", "DEFER"):
@@ -1932,6 +2124,7 @@ def evolve_record_decision(proposal_id: str):
 @app.route("/api/evolve/proposals/<proposal_id>/apply", methods=["POST"])
 def evolve_apply(proposal_id: str):
     from evolution_reviewer import apply_approved
+
     body = request.get_json(silent=True) or {}
     result = apply_approved(
         db_path=_DB_PATH,
@@ -1948,7 +2141,8 @@ def evolve_run_monitor():
     """Kick the monitor + scorer.  Non-blocking for large runs is not
     required yet — the monitor is quick against local SQLite."""
     from evolution_monitor import run_evolution_monitor
-    from evolution_scorer  import score_pending
+    from evolution_scorer import score_pending
+
     body = request.get_json(silent=True) or {}
     _ = run_evolution_monitor(
         db_path=_DB_PATH,
@@ -1962,6 +2156,7 @@ def evolve_run_monitor():
 
 # ── Workstream 4 — Regulatory AI Compliance Evidence Engine ────────────────
 
+
 @app.route("/api/comply/regulations", methods=["GET"])
 def comply_list_regulations():
     try:
@@ -1977,6 +2172,7 @@ def comply_get_regulation(regulation_id: str):
     """Return the full raw regulation JSON for the viewer link."""
     sys.path.insert(0, ROOT)
     from compliance import registry as reg_mod
+
     try:
         return jsonify(reg_mod.load_regulation(regulation_id))
     except ValueError as exc:
@@ -1987,16 +2183,20 @@ def comply_get_regulation(regulation_id: str):
 def comply_coverage():
     sys.path.insert(0, ROOT)
     from compliance import mapping as map_mod
-    return jsonify(map_mod.coverage_score(
-        out_path=_OUT_DIR,
-        db_path=_DB_PATH,
-    ))
+
+    return jsonify(
+        map_mod.coverage_score(
+            out_path=_OUT_DIR,
+            db_path=_DB_PATH,
+        )
+    )
 
 
 @app.route("/api/comply/gap", methods=["GET"])
 def comply_gap():
     sys.path.insert(0, ROOT)
     from compliance import mapping as map_mod
+
     return jsonify(map_mod.gap_analysis(out_path=_OUT_DIR))
 
 
@@ -2004,13 +2204,16 @@ def comply_gap():
 def comply_bundles():
     sys.path.insert(0, ROOT)
     from compliance import bundle as bun_mod
+
     return jsonify({"bundles": bun_mod.list_bundles(_DB_PATH)})
 
 
 @app.route("/api/comply/assemble", methods=["POST"])
 def comply_assemble():
     sys.path.insert(0, ROOT)
-    from compliance import assembler as asm_mod, bundle as bun_mod
+    from compliance import assembler as asm_mod
+    from compliance import bundle as bun_mod
+
     body = request.get_json(force=True) or {}
     regulation_id = body.get("regulation_id")
     if not regulation_id:
@@ -2037,6 +2240,7 @@ def comply_assemble():
 def comply_verify():
     sys.path.insert(0, ROOT)
     from compliance import bundle as bun_mod
+
     body = request.get_json(force=True) or {}
     path = body.get("bundle_path")
     if not path:
@@ -2046,11 +2250,13 @@ def comply_verify():
 
 # ── Workstream 5 — Ontology-Bounded Vector Retrieval ──────────────────────
 
+
 @app.route("/api/retrieve/indexes", methods=["GET"])
 def retrieve_list_indexes():
     sys.path.insert(0, ROOT)
     sys.path.insert(0, os.path.join(ROOT, "runtime"))
     from runtime.embeddings import pipeline as pipe_mod
+
     return jsonify({"indexes": pipe_mod.list_indexes(_DB_PATH)})
 
 
@@ -2059,14 +2265,17 @@ def retrieve_index_flavor(flavor: str):
     sys.path.insert(0, ROOT)
     sys.path.insert(0, os.path.join(ROOT, "runtime"))
     from runtime.embeddings import pipeline as pipe_mod
+
     body = request.get_json(silent=True) or {}
-    return jsonify(pipe_mod.index_flavor(
-        flavor,
-        db_path=_DB_PATH,
-        connection_string=body.get("vector_store"),
-        model_id=body.get("model"),
-        force=bool(body.get("force", False)),
-    ))
+    return jsonify(
+        pipe_mod.index_flavor(
+            flavor,
+            db_path=_DB_PATH,
+            connection_string=body.get("vector_store"),
+            model_id=body.get("model"),
+            force=bool(body.get("force", False)),
+        )
+    )
 
 
 @app.route("/api/retrieve/query", methods=["POST"])
@@ -2074,18 +2283,21 @@ def retrieve_query():
     sys.path.insert(0, ROOT)
     sys.path.insert(0, os.path.join(ROOT, "runtime"))
     from runtime.hybrid_retriever import HybridRetriever
+
     body = request.get_json(force=True) or {}
     flavor = body.get("flavor")
     question = body.get("question")
     if not (flavor and question):
         return jsonify({"error": "flavor and question are required"}), 400
     retriever = HybridRetriever(flavor=flavor, db_path=_DB_PATH)
-    return jsonify(retriever.retrieve(
-        question,
-        class_expression=body.get("class_expression"),
-        k=int(body.get("k", 5)),
-        strategy=body.get("strategy", "ONTOLOGY_BOUNDED"),
-    ))
+    return jsonify(
+        retriever.retrieve(
+            question,
+            class_expression=body.get("class_expression"),
+            k=int(body.get("k", 5)),
+            strategy=body.get("strategy", "ONTOLOGY_BOUNDED"),
+        )
+    )
 
 
 @app.route("/api/retrieve/benchmark", methods=["POST"])
@@ -2093,6 +2305,7 @@ def retrieve_benchmark():
     sys.path.insert(0, ROOT)
     sys.path.insert(0, os.path.join(ROOT, "runtime"))
     from runtime.embeddings import benchmark as bench_mod
+
     return jsonify(bench_mod.run_benchmark(db_path=_DB_PATH, out_path=_OUT_DIR))
 
 
@@ -2101,6 +2314,7 @@ def retrieve_benchmark_latest():
     sys.path.insert(0, ROOT)
     sys.path.insert(0, os.path.join(ROOT, "runtime"))
     from runtime.embeddings import benchmark as bench_mod
+
     return jsonify({"strategies": bench_mod.read_latest_benchmark(_DB_PATH)})
 
 
@@ -2116,7 +2330,12 @@ def serve_output(subdir: str, filename: str):
 
 # ── Reasoning search (Ontoforge) — flag-gated; ships dark until GA ───────────
 # Enable with ONTOFORGE_SEARCH=1. db defaults to ONTOFORGE_DB or db/demo.db.
-ONTOFORGE_SEARCH = os.environ.get("ONTOFORGE_SEARCH", "").lower() in ("1", "true", "yes", "on")
+ONTOFORGE_SEARCH = os.environ.get("ONTOFORGE_SEARCH", "").lower() in (
+    "1",
+    "true",
+    "yes",
+    "on",
+)
 SEARCH_DB = os.environ.get("ONTOFORGE_DB", os.path.join(ROOT, "db", "demo.db"))
 # Phase 4: TTL response cache for /api/search (seconds; 0 disables).
 SEARCH_CACHE_TTL = float(os.environ.get("ONTOFORGE_CACHE_TTL", "60"))
@@ -2131,6 +2350,7 @@ def _build_memory():
     """
     try:
         import sys as _sys
+
         if ROOT not in _sys.path:
             _sys.path.insert(0, ROOT)
         from runtime.reasoning_search.memory import SearchMemory
@@ -2146,6 +2366,7 @@ def ask_console():
     if not ONTOFORGE_SEARCH:
         return jsonify({"error": "reasoning search is not enabled"}), 404
     from flask import render_template
+
     return render_template("ask.html")
 
 
@@ -2167,16 +2388,19 @@ def api_search():
 
     import sys as _sys
     import time as _time
+
     if ROOT not in _sys.path:
         _sys.path.insert(0, ROOT)
     from dataclasses import asdict
 
     from runtime.reasoning_search import search
+    from runtime.reasoning_search._loaders import load_rules
 
     try:
         from wizard.metrics_exporter import observe_search as _observe
-    except Exception:                                                # noqa: BLE001
-        def _observe(**_kw):                                          # type: ignore
+    except Exception:  # noqa: BLE001
+
+        def _observe(**_kw):  # type: ignore
             return None
 
     db = body.get("db") or SEARCH_DB
@@ -2184,7 +2408,8 @@ def api_search():
     tier = body.get("max_tier") or "Internal"
     k = int(body.get("k", 5))
     materialize = bool(body.get("materialize"))
-    cache_key = (question, flavor, db, provider, tier, k, materialize)
+    rules = load_rules(flavor, stored_rules=_load_session().get("rules") or [])
+    cache_key = (question, flavor, db, provider, tier, k, materialize, tuple(rules))
 
     if SEARCH_CACHE_TTL > 0:
         hit = _SEARCH_CACHE.get(cache_key)
@@ -2194,17 +2419,33 @@ def api_search():
 
     started = _time.monotonic()
     try:
-        ans = search(question, flavor=flavor, db_path=db, providers=provider,
-                     max_tier=tier, k=k, memory=_build_memory(), materialize=materialize)
-    except Exception as exc:                                          # noqa: BLE001
-        _observe(status="error", provider=provider,
-                 latency_seconds=_time.monotonic() - started)
+        ans = search(
+            question,
+            flavor=flavor,
+            db_path=db,
+            providers=provider,
+            max_tier=tier,
+            k=k,
+            memory=_build_memory(),
+            materialize=materialize,
+            rules=rules,
+        )
+    except Exception as exc:  # noqa: BLE001
+        _observe(
+            status="error",
+            provider=provider,
+            latency_seconds=_time.monotonic() - started,
+        )
         return jsonify({"error": f"search failed: {exc}"}), 500
 
-    _observe(status=ans.status, provider=provider,
-             latency_seconds=_time.monotonic() - started,
-             rows=len(ans.results), derived=len(ans.inferred),
-             triples=(ans.subgraph or {}).get("count", 0))
+    _observe(
+        status=ans.status,
+        provider=provider,
+        latency_seconds=_time.monotonic() - started,
+        rows=len(ans.results),
+        derived=len(ans.inferred),
+        triples=(ans.subgraph or {}).get("count", 0),
+    )
 
     result = asdict(ans)
     if SEARCH_CACHE_TTL > 0:
@@ -2228,9 +2469,11 @@ def api_sparql():
         return jsonify({"error": "field 'query' is required"}), 400
 
     import sys as _sys
+
     if ROOT not in _sys.path:
         _sys.path.insert(0, ROOT)
     from runtime.reasoning_search import Subgraph, Triple, search, sparql
+    from runtime.reasoning_search._loaders import load_rules
 
     triples = body.get("triples")
     if triples is None:
@@ -2239,16 +2482,28 @@ def api_sparql():
         if not question or not flavor:
             return jsonify({"error": "provide 'triples', or 'question'+'flavor'"}), 400
         try:
-            ans = search(question, flavor=flavor, db_path=body.get("db") or SEARCH_DB,
-                         providers=body.get("provider") or "ollama",
-                         max_tier=body.get("max_tier") or "Internal",
-                         k=int(body.get("k", 5)), materialize=True)
-        except Exception as exc:                                      # noqa: BLE001
+            ans = search(
+                question,
+                flavor=flavor,
+                db_path=body.get("db") or SEARCH_DB,
+                providers=body.get("provider") or "ollama",
+                max_tier=body.get("max_tier") or "Internal",
+                k=int(body.get("k", 5)),
+                materialize=True,
+                rules=load_rules(
+                    flavor, stored_rules=_load_session().get("rules") or []
+                ),
+            )
+        except Exception as exc:  # noqa: BLE001
             return jsonify({"error": f"search failed: {exc}"}), 500
         triples = (ans.subgraph or {}).get("triples", [])
 
-    graph = Subgraph(triples=[Triple(t[0], t[1], t[2], bool(t[3]) if len(t) > 3 else False)
-                              for t in triples])
+    graph = Subgraph(
+        triples=[
+            Triple(t[0], t[1], t[2], bool(t[3]) if len(t) > 3 else False)
+            for t in triples
+        ]
+    )
     try:
         return jsonify(sparql(graph, query))
     except ValueError as exc:
@@ -2281,22 +2536,28 @@ def api_search_stream():
     if ROOT not in _sys.path:
         _sys.path.insert(0, ROOT)
     from runtime.reasoning_search import search
+    from runtime.reasoning_search._loaders import load_rules
 
     q: _queue.Queue = _queue.Queue()
 
     def _run():
         try:
             ans = search(
-                question, flavor=flavor, db_path=body.get("db") or SEARCH_DB,
+                question,
+                flavor=flavor,
+                db_path=body.get("db") or SEARCH_DB,
                 providers=body.get("provider") or "ollama",
                 max_tier=body.get("max_tier") or "Internal",
                 k=int(body.get("k", 5)),
                 materialize=bool(body.get("materialize")),
+                rules=load_rules(
+                    flavor, stored_rules=_load_session().get("rules") or []
+                ),
                 on_event=lambda e: q.put(("stage", e)),
                 memory=_build_memory(),
             )
             q.put(("answer", asdict(ans)))
-        except Exception as exc:                                      # noqa: BLE001
+        except Exception as exc:  # noqa: BLE001
             q.put(("error", {"error": str(exc)}))
         finally:
             q.put(None)
@@ -2316,6 +2577,7 @@ def api_search_stream():
 
 # ── Main ───────────────────────────────────────────────────────────────────
 
+
 def main():
     # Read version + branding from the canonical source (ontomesh
     # package) so the boot banner can't drift from pyproject.toml again.
@@ -2323,7 +2585,7 @@ def main():
         if HERE not in sys.path:
             sys.path.insert(0, HERE)
         from ontoforge import __version__ as _version
-    except Exception:                                                 # noqa: BLE001
+    except Exception:  # noqa: BLE001
         _version = "unknown"
 
     parser = argparse.ArgumentParser(
@@ -2335,8 +2597,10 @@ def main():
     args = parser.parse_args()
 
     print()
-    print(f"  Ontomesh — the semantic system of record for your enterprise  ·  v{_version}")
-    print(f"  ──────────────────────────────────────────────────────────────")
+    print(
+        f"  Ontomesh — the semantic system of record for your enterprise  ·  v{_version}"
+    )
+    print("  ──────────────────────────────────────────────────────────────")
     print(f"  Landing:     http://{args.host}:{args.port}/")
     print(f"  Wizard:      http://{args.host}:{args.port}/wizard")
     print(f"  Projects:    http://{args.host}:{args.port}/projects")

```
